/**
 * Cloudflare Worker — API de trades + Auditoria automática
 *
 * Endpoints (manuais, via HTTP):
 *   GET    /trades          → lista trades atuais
 *   POST   /trades          → adiciona novo trade
 *   PUT    /trades/:id      → edita trade existente
 *   DELETE /trades/:id      → remove trade
 *   POST   /auditar         → roda auditoria manualmente (útil pra debug)
 *
 * Cron Trigger (automático):
 *   Roda a cada hora — busca placares e atualiza trades pendentes.
 *
 * Secrets/Variáveis no painel do Cloudflare:
 *   GITHUB_TOKEN        - token GitHub (Contents: Read+Write)
 *   GITHUB_OWNER        - usuário GitHub (ex: "jose-trader")
 *   GITHUB_REPO         - "analises-trader"
 *   GITHUB_BRANCH       - "main"
 *   ALLOWED_ORIGIN      - URL do site (ex: "https://analises-trader.pages.dev")
 *   API_FOOTBALL_KEY    - chave da api-sports.io
 *   TELEGRAM_BOT_TOKEN  - token do bot (opcional, pra notificações)
 *   TELEGRAM_CHAT_ID    - chat id do destinatário (opcional)
 */

const TRADES_PATH = 'relatorios/trades.json';
const ENTRADAS_PATH_PREFIX = 'relatorios/relatorio_'; // relatorio_2026-05-17.json
const FINALIZADOS_PATH = 'relatorios/finalizados.json'; // jogos marcados como finalizados manualmente

// =============================================================
// Roteamento HTTP
// =============================================================
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // CORS tolerante: normaliza a barra final e compara com a origem da requisição.
    // Se ALLOWED_ORIGIN bater (com ou sem "/"), devolve a origem exata do request.
    const reqOrigin = request.headers.get('Origin') || '';
    const norm = (s) => (s || '').replace(/\/+$/, ''); // remove barras finais
    const allowedEnv = norm(env.ALLOWED_ORIGIN);
    let allowOrigin = env.ALLOWED_ORIGIN || '*';
    if (allowedEnv && reqOrigin && norm(reqOrigin) === allowedEnv) {
      allowOrigin = reqOrigin; // devolve exatamente a origem que o navegador enviou
    } else if (!env.ALLOWED_ORIGIN) {
      allowOrigin = '*';
    }

    const corsHeaders = {
      'Access-Control-Allow-Origin': allowOrigin,
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, CF-Access-Jwt-Assertion',
      'Access-Control-Allow-Credentials': 'true',
      'Vary': 'Origin',
    };

    if (method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    const userEmail =
      request.headers.get('Cf-Access-Authenticated-User-Email') ||
      request.headers.get('CF-Access-Authenticated-User-Email') ||
      'desconhecido';

    try {
      if (path === '/trades' && method === 'GET') {
        return await listarTrades(env, corsHeaders);
      }
      if (path === '/trades' && method === 'POST') {
        const body = await request.json();
        return await criarTrade(env, body, userEmail, corsHeaders);
      }
      if (path.startsWith('/trades/') && method === 'PUT') {
        const id = decodeURIComponent(path.split('/trades/')[1]);
        const body = await request.json();
        return await editarTrade(env, id, body, userEmail, corsHeaders);
      }
      if (path.startsWith('/trades/') && method === 'DELETE') {
        const id = decodeURIComponent(path.split('/trades/')[1]);
        return await deletarTrade(env, id, userEmail, corsHeaders);
      }
      if (path === '/auditar' && method === 'POST') {
        const resultado = await rodarAuditoria(env);
        return resposta(resultado, 200, corsHeaders);
      }
      if (path === '/reauditar' && method === 'POST') {
        // Re-audita TODOS os relatórios do GitHub que já têm placar gravado,
        // recalculando os vereditos green/red (sem depender da API-Football).
        const resultado = await reauditarHistorico(env);
        return resposta(resultado, 200, corsHeaders);
      }
      if (path === '/finalizar' && method === 'POST') {
        // Finalização manual: o usuário marca o placar e o minuto de um jogo
        // direto pelo site, sem depender da API-Football.
        // Body esperado: { data, jogo, placar_casa, placar_fora, minuto_gol, observacao }
        let body;
        try { body = await request.json(); } catch { return resposta({ erro: 'body inválido' }, 400, corsHeaders); }
        const resultado = await finalizarManualmente(env, body);
        const status = resultado.erro ? 400 : 200;
        return resposta(resultado, status, corsHeaders);
      }
      if (path === '/placares' && method === 'GET') {
        // Retorna placares do dia (usado pelo site pra mostrar jogos encerrados).
        // Cache de 10min via Cloudflare Cache API pra economizar cota da API-Football.
        const data = url.searchParams.get('data') || new Date().toISOString().slice(0, 10);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) {
          return resposta({ erro: 'data invalida (use AAAA-MM-DD)' }, 400, corsHeaders);
        }

        // Tenta servir do cache primeiro
        const cacheKey = new Request(`https://cache.local/placares?data=${data}`);
        const cache = caches.default;
        let cached = await cache.match(cacheKey);
        if (cached) {
          const corpo = await cached.json();
          return resposta({ ...corpo, cache: true }, 200, corsHeaders);
        }

        // Busca da API
        const placares = await buscarPlacaresDoDia(env, data);
        // Simplifica: só o necessário pro site
        const simples = placares.map((p) => ({
          casa: p.casa,
          fora: p.fora,
          gols_casa: p.gols_casa,
          gols_fora: p.gols_fora,
          status: p.status, // 'finalizado' | 'em_andamento' | 'agendado'
        }));
        const corpo = { data, placares: simples, cache: false };

        // Salva no cache por 10 minutos
        const respCache = new Response(JSON.stringify(corpo), {
          headers: { 'Content-Type': 'application/json', 'Cache-Control': 'max-age=600' },
        });
        await cache.put(cacheKey, respCache.clone());

        return resposta(corpo, 200, corsHeaders);
      }
      if (path === '/finalizados' && method === 'GET') {
        // Lista os IDs de jogos marcados como finalizados manualmente
        const { dados } = await lerFinalizados(env);
        return resposta({ finalizados: dados }, 200, corsHeaders);
      }
      if (path === '/finalizados' && method === 'POST') {
        // Marca ou desmarca um jogo como finalizado.
        // Body: { id: "slug-do-jogo", relatorio: "2026-05-23", acao: "marcar" | "desmarcar" }
        let body;
        try { body = await request.json(); } catch { body = {}; }
        const { id, relatorio, acao } = body;
        if (!id || !acao) {
          return resposta({ erro: 'informe id e acao' }, 400, corsHeaders);
        }
        const { dados, sha } = await lerFinalizados(env);
        let lista = Array.isArray(dados) ? dados : [];

        if (acao === 'marcar') {
          if (!lista.some((x) => x.id === id)) {
            lista.push({ id, relatorio: relatorio || '', marcado_em: new Date().toISOString() });
          }
        } else if (acao === 'desmarcar') {
          lista = lista.filter((x) => x.id !== id);
        } else {
          return resposta({ erro: 'acao deve ser marcar ou desmarcar' }, 400, corsHeaders);
        }

        try {
          await salvarArquivoGithubGenerico(
            env, FINALIZADOS_PATH, JSON.stringify(lista, null, 2), sha,
            `[finalizados] ${acao}: ${id}`
          );
        } catch (errSave) {
          // Retorna o erro detalhado (ajuda a diagnosticar: token, permissão, etc.)
          return resposta(
            { erro: 'falha ao gravar no GitHub', detalhe: errSave.message },
            502, corsHeaders
          );
        }
        return resposta({ ok: true, finalizados: lista }, 200, corsHeaders);
      }
      if (path === '/' && method === 'GET') {
        return new Response(
          JSON.stringify({ status: 'ok', usuario: userEmail }),
          { headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
      }
      return new Response('Not found', { status: 404, headers: corsHeaders });
    } catch (err) {
      return new Response(
        JSON.stringify({ erro: err.message, stack: err.stack }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }
  },

  // Cron trigger — roda na frequência definida em wrangler.toml (a cada hora)
  async scheduled(event, env, ctx) {
    console.log('Cron triggered:', event.cron);
    try {
      const resultado = await rodarAuditoria(env);
      console.log('Auditoria concluída:', JSON.stringify(resultado));
    } catch (err) {
      console.error('Erro na auditoria:', err.message);
    }
  },
};

// =============================================================
// CRUD de trades
// =============================================================
async function listarTrades(env, corsHeaders) {
  const { trades } = await lerArquivoGithub(env, TRADES_PATH);
  return resposta(trades, 200, corsHeaders);
}

async function criarTrade(env, novoTrade, userEmail, corsHeaders) {
  validarTrade(novoTrade);
  const { trades, sha } = await lerArquivoGithub(env, TRADES_PATH);

  if (!novoTrade.id) {
    const data = novoTrade.data || new Date().toISOString().slice(0, 10);
    const seq = String(
      trades.filter((t) => t.id?.startsWith(data)).length + 1
    ).padStart(3, '0');
    novoTrade.id = `${data}-${seq}`;
  }

  if (trades.some((t) => t.id === novoTrade.id)) {
    return resposta({ erro: `ID já existe: ${novoTrade.id}` }, 409, corsHeaders);
  }

  trades.push(novoTrade);
  await salvarArquivoGithub(env, TRADES_PATH, trades, sha,
    `Trade: ${novoTrade.jogo} (${novoTrade.resultado}) por ${userEmail}`);
  return resposta({ ok: true, trade: novoTrade }, 201, corsHeaders);
}

async function editarTrade(env, id, dadosAtualizados, userEmail, corsHeaders) {
  const { trades, sha } = await lerArquivoGithub(env, TRADES_PATH);
  const idx = trades.findIndex((t) => t.id === id);
  if (idx === -1) {
    return resposta({ erro: `Trade não encontrado: ${id}` }, 404, corsHeaders);
  }
  const tradeAtualizado = { ...trades[idx], ...dadosAtualizados, id };
  validarTrade(tradeAtualizado);
  trades[idx] = tradeAtualizado;
  await salvarArquivoGithub(env, TRADES_PATH, trades, sha,
    `Edição de trade: ${id} por ${userEmail}`);
  return resposta({ ok: true, trade: tradeAtualizado }, 200, corsHeaders);
}

async function deletarTrade(env, id, userEmail, corsHeaders) {
  const { trades, sha } = await lerArquivoGithub(env, TRADES_PATH);
  const idx = trades.findIndex((t) => t.id === id);
  if (idx === -1) {
    return resposta({ erro: `Trade não encontrado: ${id}` }, 404, corsHeaders);
  }
  const removido = trades.splice(idx, 1)[0];
  await salvarArquivoGithub(env, TRADES_PATH, trades, sha,
    `Remoção de trade: ${id} por ${userEmail}`);
  return resposta({ ok: true, removido }, 200, corsHeaders);
}

function validarTrade(t) {
  const obrigatorios = ['data','jogo','metodo','mercado','odd_entrada','stake_pct','resultado','criterios_atendidos'];
  for (const c of obrigatorios) {
    if (t[c] === undefined || t[c] === null || t[c] === '') {
      throw new Error(`Campo obrigatório ausente: ${c}`);
    }
  }
  if (!['green','red','pendente'].includes(t.resultado)) {
    throw new Error(`resultado deve ser 'green', 'red' ou 'pendente'`);
  }
  if (typeof t.criterios_atendidos !== 'boolean') {
    throw new Error(`criterios_atendidos deve ser boolean`);
  }
  if (typeof t.odd_entrada !== 'number' || t.odd_entrada <= 1) {
    throw new Error(`odd_entrada deve ser número maior que 1`);
  }
  if (typeof t.stake_pct !== 'number' || t.stake_pct <= 0) {
    throw new Error(`stake_pct deve ser número maior que 0`);
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t.data)) {
    throw new Error(`data deve estar no formato YYYY-MM-DD`);
  }
}

// =============================================================
// AUDITORIA AUTOMÁTICA
// =============================================================

/**
 * Lê as entradas sugeridas dos relatórios + os trades existentes,
 * busca placares na API-Football, decide Green/Red, atualiza trades.json.
 */
async function rodarAuditoria(env) {
  if (!env.API_FOOTBALL_KEY) {
    return { erro: 'API_FOOTBALL_KEY não configurada' };
  }

  // 1. Carrega trades atuais
  const { trades, sha: tradesSha } = await lerArquivoGithub(env, TRADES_PATH);

  // 2. Detecta datas dos trades pendentes (sem resultado)
  const tradesPendentes = trades.filter(t => t.resultado === 'pendente' || !t.resultado);
  if (tradesPendentes.length === 0) {
    // Mesmo sem trades pendentes, grava os placares e vereditos nos relatorios
    // (pro site mostrar jogos encerrados + green/red por método).
    let diag = null;
    try {
      diag = await gravarPlacaresNosRelatorios(env);
    } catch (err) {
      console.error('Erro gravando placares:', err.message);
      return { status: 'erro_placares', erro: err.message };
    }
    return { status: 'sem_pendentes', total_trades: trades.length, diagnostico: diag };
  }

  const datasUnicas = [...new Set(tradesPendentes.map(t => t.data))];

  // 3. Pra cada data, busca placares na API-Football
  let placaresPorData = {};
  for (const data of datasUnicas) {
    try {
      placaresPorData[data] = await buscarPlacaresDoDia(env, data);
    } catch (err) {
      console.error(`Erro buscando ${data}:`, err.message);
      placaresPorData[data] = [];
    }
  }

  // 4. Cruza cada trade com placar
  let atualizados = 0;
  let inconclusivos = 0;
  const detalhes = [];

  for (let i = 0; i < trades.length; i++) {
    const t = trades[i];
    if (t.resultado !== 'pendente' && t.resultado !== undefined && t.resultado !== '') continue;

    const placares = placaresPorData[t.data] || [];
    const placar = encontrarPlacar(t.jogo, placares);

    if (!placar) {
      detalhes.push({ id: t.id, status: 'sem_placar', jogo: t.jogo });
      inconclusivos++;
      continue;
    }

    if (placar.status !== 'finalizado') {
      detalhes.push({ id: t.id, status: 'jogo_em_andamento', jogo: t.jogo });
      continue;
    }

    // Aplica regra de auditoria do método
    const veredito = auditarPorMetodo(t, placar);
    if (veredito.resultado === 'inconclusivo') {
      inconclusivos++;
      detalhes.push({ id: t.id, status: 'inconclusivo', jogo: t.jogo, motivo: veredito.motivo });
      continue;
    }

    trades[i] = {
      ...t,
      resultado: veredito.resultado,
      placar_final: `${placar.gols_casa}x${placar.gols_fora}`,
      placar_ht: `${placar.gols_casa_ht}x${placar.gols_fora_ht}`,
      auditado_em: new Date().toISOString(),
      auditoria_motivo: veredito.motivo,
    };
    atualizados++;
    detalhes.push({
      id: t.id,
      status: 'atualizado',
      jogo: t.jogo,
      resultado: veredito.resultado,
      placar: `${placar.gols_casa}x${placar.gols_fora}`,
    });

    // Notificação Telegram (não bloqueia em caso de erro)
    const emoji = veredito.resultado === 'green' ? '✅' : '❌';
    const label = veredito.resultado === 'green' ? 'GREEN' : 'RED';
    const msg = (
      `${emoji} <b>${label}</b>: ${t.jogo}\n` +
      `🎯 ${t.metodo} · ${placar.gols_casa}x${placar.gols_fora}\n` +
      `<i>${veredito.motivo}</i>`
    );
    try { await enviarTelegram(env, msg); } catch {}
  }

  // 5. Salva trades no GitHub se teve mudança
  if (atualizados > 0) {
    await salvarArquivoGithub(
      env, TRADES_PATH, trades, tradesSha,
      `Auditoria automática: ${atualizados} trades atualizados`
    );
  }

  // 6. Grava placares e vereditos nos relatórios do dia.
  let diag = null;
  try {
    diag = await gravarPlacaresNosRelatorios(env);
  } catch (err) {
    console.error('Erro gravando placares nos relatorios:', err.message);
  }

  return {
    status: 'ok',
    total_pendentes_antes: tradesPendentes.length,
    atualizados,
    inconclusivos,
    diagnostico: diag,
    detalhes,
  };
}

// =============================================================
// =============================================================
// FINALIZAÇÃO MANUAL DE PARTIDAS
// O usuário marca placar + minuto direto pelo site. Útil pra
// jogos que a API-Football não cobre ou pra registrar antes do
// cron pegar.
// =============================================================
async function finalizarManualmente(env, body) {
  if (!body) return { erro: 'body vazio' };
  const { data, jogo, placar_casa, placar_fora, placar_entrada_casa, placar_entrada_fora, minuto_gol, observacao } = body;

  // Validações
  if (!data || !/^\d{4}-\d{2}-\d{2}$/.test(data)) {
    return { erro: 'campo "data" inválido (use AAAA-MM-DD)' };
  }
  if (!jogo || typeof jogo !== 'string') {
    return { erro: 'campo "jogo" obrigatório (ex: "Time A x Time B")' };
  }
  const pc = parseInt(placar_casa, 10);
  const pf = parseInt(placar_fora, 10);
  if (isNaN(pc) || pc < 0 || pc > 20) return { erro: 'placar_casa inválido (0-20)' };
  if (isNaN(pf) || pf < 0 || pf > 20) return { erro: 'placar_fora inválido (0-20)' };

  // Placar de entrada (opcional — usado pra auditoria correta do Over Limite +1)
  let pec = null, pef = null;
  if (placar_entrada_casa !== null && placar_entrada_casa !== undefined && placar_entrada_casa !== '') {
    pec = parseInt(placar_entrada_casa, 10);
    if (isNaN(pec) || pec < 0 || pec > 20) return { erro: 'placar_entrada_casa inválido' };
  }
  if (placar_entrada_fora !== null && placar_entrada_fora !== undefined && placar_entrada_fora !== '') {
    pef = parseInt(placar_entrada_fora, 10);
    if (isNaN(pef) || pef < 0 || pef > 20) return { erro: 'placar_entrada_fora inválido' };
  }

  const minuto = (minuto_gol || '').toString().trim().slice(0, 20);

  // Lê o relatório do dia
  const path = `relatorios/relatorio_${data}.json`;
  let conteudo, sha;
  try {
    const r = await lerArquivoGithubGenerico(env, path);
    conteudo = r.conteudo; sha = r.sha;
  } catch (e) {
    return { erro: 'falha ao ler relatorio do GitHub: ' + e.message };
  }
  if (!conteudo) return { erro: `relatorio ${data} não encontrado no GitHub` };

  let relatorio;
  try { relatorio = JSON.parse(conteudo); }
  catch { return { erro: 'json do relatorio inválido' }; }
  if (!Array.isArray(relatorio.entradas)) return { erro: 'relatorio sem campo "entradas"' };

  // Acha a entrada pelo nome do jogo (matching tolerante)
  const jogoNorm = jogo.toLowerCase().trim();
  const entrada = relatorio.entradas.find(e =>
    (e.jogo || '').toLowerCase().trim() === jogoNorm
  );
  if (!entrada) {
    return { erro: `jogo "${jogo}" não encontrado em ${data}` };
  }

  // Grava placar, minuto e re-audita os métodos
  entrada._placar = `${pc}x${pf}`;
  entrada._status = 'finalizado';
  entrada._minuto_gol = minuto;
  entrada._finalizado_manualmente = true;
  entrada._finalizado_em = new Date().toISOString();
  if (observacao) entrada._observacao = String(observacao).slice(0, 300);
  if (pec !== null && pef !== null) {
    entrada._placar_entrada = `${pec}x${pef}`;
  }

  // Re-audita vereditos com base no placar
  const placar = {
    gols_casa: pc, gols_fora: pf, status: 'finalizado',
    // Inclui placar de entrada (usado pelo case 'over_limite_70')
    gols_casa_entrada: pec, gols_fora_entrada: pef,
  };
  const metodos = detectarMetodosEntrada(entrada);
  const vereditos = {};
  for (const m of metodos) {
    vereditos[m] = auditarMetodoDireto(m, entrada, placar);
  }
  entrada._vereditos = vereditos;
  const principal = metodos[0];
  entrada._veredito = principal && vereditos[principal]
    ? vereditos[principal].resultado : 'inconclusivo';

  // Salva de volta no GitHub
  try {
    await salvarArquivoGithubGenerico(
      env, path, JSON.stringify(relatorio, null, 2), sha,
      `[manual] finalizada: ${jogo} ${pc}x${pf}`
    );
  } catch (e) {
    return { erro: 'falha ao gravar no GitHub: ' + e.message };
  }

  return {
    status: 'finalizado com sucesso',
    jogo,
    placar: `${pc}x${pf}`,
    minuto_gol: minuto,
    veredito: entrada._veredito,
    vereditos,
  };
}


// =============================================================
// RE-AUDITORIA DO HISTÓRICO COMPLETO
// Varre todos os relatorios do GitHub e recalcula os vereditos
// green/red dos jogos que JÁ TÊM placar gravado (_placar).
// Não depende da API-Football (usa o placar já salvo), então
// funciona pro histórico inteiro mesmo no plano grátis.
// =============================================================
async function reauditarHistorico(env) {
  const diag = { relatorios_processados: 0, relatorios_atualizados: 0, jogos_reauditados: 0, datas: {} };

  // 1. Lista os arquivos da pasta relatorios/ no GitHub
  const listaUrl = `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/contents/relatorios?ref=${env.GITHUB_BRANCH || 'main'}`;
  let arquivos;
  try {
    const r = await fetch(listaUrl, {
      headers: {
        Authorization: `Bearer ${env.GITHUB_TOKEN}`,
        Accept: 'application/vnd.github+json',
        'User-Agent': 'analises-trader-worker',
      },
    });
    if (!r.ok) return { erro: `falha ao listar relatorios: ${r.status}` };
    arquivos = await r.json();
  } catch (e) {
    return { erro: 'falha ao listar relatorios: ' + e.message };
  }

  // 2. Filtra só os relatorio_AAAA-MM-DD.json
  const relatorios = (Array.isArray(arquivos) ? arquivos : [])
    .filter(a => /^relatorio_\d{4}-\d{2}-\d{2}\.json$/.test(a.name));

  // 3. Para cada relatório, re-audita os jogos que têm placar
  for (const arq of relatorios) {
    const data = arq.name.replace(/^relatorio_/, '').replace(/\.json$/, '');
    const path = `relatorios/${arq.name}`;
    diag.relatorios_processados++;

    let conteudo, sha;
    try {
      const res = await lerArquivoGithubGenerico(env, path);
      conteudo = res.conteudo; sha = res.sha;
    } catch {
      diag.datas[data] = { erro: 'falha ao ler' };
      continue;
    }
    if (!conteudo) { diag.datas[data] = { erro: 'vazio' }; continue; }

    let relatorio;
    try { relatorio = JSON.parse(conteudo); } catch {
      diag.datas[data] = { erro: 'json invalido' }; continue;
    }
    if (!relatorio.entradas || !Array.isArray(relatorio.entradas)) {
      diag.datas[data] = { erro: 'sem entradas' }; continue;
    }

    let mudou = false;
    let reauditados = 0;
    for (const entrada of relatorio.entradas) {
      // Só re-audita quem tem placar gravado e status finalizado
      if (!entrada._placar || entrada._status !== 'finalizado') continue;
      const m = /^(\d+)x(\d+)$/.exec(entrada._placar);
      if (!m) continue;
      const placar = {
        gols_casa: parseInt(m[1], 10),
        gols_fora: parseInt(m[2], 10),
        status: 'finalizado',
      };
      const metodos = detectarMetodosEntrada(entrada);
      const resultados = {};
      for (const mKey of metodos) {
        resultados[mKey] = auditarMetodoDireto(mKey, entrada, placar);
      }
      const principal = metodos[0];
      const veredito = principal && resultados[principal]
        ? resultados[principal].resultado : 'inconclusivo';
      if (JSON.stringify(entrada._vereditos) !== JSON.stringify(resultados) ||
          entrada._veredito !== veredito) {
        entrada._vereditos = resultados;
        entrada._veredito = veredito;
        mudou = true;
      }
      reauditados++;
    }

    diag.jogos_reauditados += reauditados;
    diag.datas[data] = { jogos_com_placar: reauditados, atualizado: mudou };

    if (mudou) {
      try {
        await salvarArquivoGithubGenerico(
          env, path, JSON.stringify(relatorio, null, 2), sha,
          `[reauditoria] vereditos recalculados em ${data}`
        );
        diag.relatorios_atualizados++;
      } catch (e) {
        diag.datas[data].erro_gravacao = e.message;
      }
    }
  }

  return { status: 'reauditoria concluida', ...diag };
}

// Grava placares nos relatorios do dia (hoje + ontem)
// Isso permite o site mostrar "Encerrado 2x1" sem depender da API
// (que no plano free nao retorna datas passadas).
// =============================================================
async function gravarPlacaresNosRelatorios(env) {
  // Datas em horário de Brasília (UTC-3). new Date() puro usa UTC e pode pegar o dia errado.
  function dataBR(offsetDias = 0) {
    const agora = new Date();
    const local = new Date(agora.getTime() - 3 * 60 * 60 * 1000 + offsetDias * 24 * 60 * 60 * 1000);
    return local.toISOString().slice(0, 10);
  }
  const datas = [dataBR(0), dataBR(-1)]; // hoje e ontem (BR)

  const diag = { datas: {}, total_atualizados: 0 };

  for (const data of datas) {
    const info = { relatorio_existe: false, placares_encontrados: 0, jogos_casados: 0, finalizados: 0 };
    const path = `${ENTRADAS_PATH_PREFIX}${data}.json`;
    let relatorioRaw, sha;
    try {
      const res = await lerArquivoGithubGenerico(env, path);
      relatorioRaw = res.conteudo;
      sha = res.sha;
    } catch {
      diag.datas[data] = { ...info, erro: 'falha ao ler relatorio' };
      continue;
    }
    if (!relatorioRaw || !sha) {
      diag.datas[data] = { ...info, erro: 'relatorio nao existe' };
      continue;
    }
    info.relatorio_existe = true;

    let relatorio;
    try { relatorio = JSON.parse(relatorioRaw); } catch {
      diag.datas[data] = { ...info, erro: 'json invalido' };
      continue;
    }
    if (!relatorio.entradas || !Array.isArray(relatorio.entradas)) {
      diag.datas[data] = { ...info, erro: 'sem entradas' };
      continue;
    }

    let placares;
    try {
      placares = await buscarPlacaresDoDia(env, data);
    } catch (e) {
      diag.datas[data] = { ...info, erro: 'falha API: ' + e.message };
      continue;
    }
    info.placares_encontrados = placares ? placares.length : 0;
    if (!placares || placares.length === 0) {
      diag.datas[data] = { ...info, erro: 'API nao retornou placares' };
      continue;
    }

    let mudou = false;
    for (const entrada of relatorio.entradas) {
      const placar = encontrarPlacar(entrada.jogo, placares);
      if (!placar) continue;
      info.jogos_casados++;

      const novoStatus = placar.status;
      const novoPlacar = (placar.gols_casa !== null && placar.gols_fora !== null)
        ? `${placar.gols_casa}x${placar.gols_fora}`
        : null;

      // Grava placar e status
      if (entrada._placar !== novoPlacar || entrada._status !== novoStatus) {
        entrada._placar = novoPlacar;
        entrada._status = novoStatus;
        entrada._placar_atualizado_em = new Date().toISOString();
        mudou = true;
      }

      // Se o jogo terminou, grava o VEREDITO green/red de cada método aplicado
      if (novoStatus === 'finalizado') {
        info.finalizados++;
        const metodos = detectarMetodosEntrada(entrada);
        const resultados = {};
        for (const mKey of metodos) {
          const ver = auditarMetodoDireto(mKey, entrada, placar);
          resultados[mKey] = ver; // { resultado: 'green'|'red'|'inconclusivo', motivo }
        }
        // Veredito geral: green se o método PRINCIPAL (1o da lista) for green
        const principal = metodos[0];
        const veredito = principal && resultados[principal]
          ? resultados[principal].resultado
          : 'inconclusivo';
        if (JSON.stringify(entrada._vereditos) !== JSON.stringify(resultados) ||
            entrada._veredito !== veredito) {
          entrada._vereditos = resultados;
          entrada._veredito = veredito;
          mudou = true;
        }
      }
    }

    if (mudou) {
      await salvarArquivoGithubGenerico(
        env, path, JSON.stringify(relatorio, null, 2), sha,
        `[auto] Placares e vereditos atualizados em ${data}`
      );
      diag.total_atualizados++;
    }
    diag.datas[data] = info;
  }

  return diag;
}

// Detecta os métodos aplicados numa entrada do RELATÓRIO (objetos, não trade)
function detectarMetodosEntrada(entrada) {
  const chaves = ['back_favorito','lay_zebra','over_limite_70','back_2x2','back_goleada','lay_1x0','lay_0x1'];
  const out = [];
  for (const k of chaves) {
    const obj = entrada[k];
    if (obj && (obj.aplicavel === true || obj.elegivel === true)) out.push(k);
  }
  return out;
}

// Audita um método direto da entrada do relatório (usa os campos do objeto do método)
function auditarMetodoDireto(metodoKey, entrada, placar) {
  const gc = placar.gols_casa, gf = placar.gols_fora;
  if (gc === null || gf === null) return { resultado: 'inconclusivo', motivo: 'sem placar' };
  const total = gc + gf;
  const obj = entrada[metodoKey] || {};

  // Identifica casa/fora pelo nome do jogo
  const partes = normalizarTxt(entrada.jogo).split(/ x | vs | - /);
  const casaJogo = partes[0] ? partes[0].trim() : '';
  const foraJogo = partes[1] ? partes[1].trim() : '';

  const contem = (timeReal, nomeBusca) => {
    if (!timeReal || !nomeBusca) return false;
    const real = normalizarTxt(timeReal);
    const busca = normalizarTxt(nomeBusca);
    // Pega palavras significativas (4+ letras), ignorando "de", "do", "da", "fc" etc.
    const palavras = busca.split(' ').filter(p => p.length >= 4);
    if (palavras.length === 0) {
      // Nome curto (ex: "PSG", "Roma") — exige match exato como palavra
      return real.split(' ').includes(busca);
    }
    // EXIGE QUE TODAS as palavras significativas estejam no time real
    // (antes era .some() — bug que fazia "Vila Nova" casar com qualquer time
    // que tivesse "vila" ou "nova" no nome)
    return palavras.every(p => real.includes(p));
  };

  switch (metodoKey) {
    case 'back_favorito': {
      const fav = obj.favorito || '';
      if (!fav) {
        return { resultado: 'inconclusivo', motivo: 'campo "favorito" não preenchido na entrada' };
      }
      const favEhCasa = contem(casaJogo, fav) || contem(placar.casa, fav);
      const favEhFora = contem(foraJogo, fav) || contem(placar.fora, fav);
      if (!favEhCasa && !favEhFora) {
        return { resultado: 'inconclusivo', motivo: `favorito "${fav}" não bateu com nenhum time do jogo` };
      }
      if (favEhCasa && favEhFora) {
        return { resultado: 'inconclusivo', motivo: `favorito "${fav}" bateu com ambos os times (ambíguo)` };
      }
      if (favEhCasa) {
        return gc > gf
          ? { resultado: 'green', motivo: `Favorito (casa) venceu ${gc}x${gf}` }
          : { resultado: 'red', motivo: `Favorito (casa) não venceu (${gc}x${gf})` };
      }
      // favorito é fora
      return gf > gc
        ? { resultado: 'green', motivo: `Favorito (fora) venceu ${gc}x${gf}` }
        : { resultado: 'red', motivo: `Favorito (fora) não venceu (${gc}x${gf})` };
    }
    case 'lay_zebra': {
      const zebra = obj.zebra || '';
      if (!zebra) {
        return { resultado: 'inconclusivo', motivo: 'campo "zebra" não preenchido na entrada' };
      }
      const zebraEhCasa = contem(casaJogo, zebra) || contem(placar.casa, zebra);
      const zebraEhFora = contem(foraJogo, zebra) || contem(placar.fora, zebra);
      // Se não conseguir identificar OU casar com ambos (ambíguo), inconclusivo
      if (!zebraEhCasa && !zebraEhFora) {
        return { resultado: 'inconclusivo', motivo: `zebra "${zebra}" não bateu com nenhum time do jogo` };
      }
      if (zebraEhCasa && zebraEhFora) {
        return { resultado: 'inconclusivo', motivo: `zebra "${zebra}" bateu com ambos os times (ambíguo)` };
      }
      // Lay Zebra ganha (GREEN) se a zebra NÃO venceu (perdeu OU empatou)
      if (zebraEhCasa) {
        return gc > gf
          ? { resultado: 'red', motivo: `Zebra (casa) venceu ${gc}x${gf}` }
          : { resultado: 'green', motivo: `Zebra (casa) não venceu (${gc}x${gf})` };
      }
      // zebra é fora
      return gf > gc
        ? { resultado: 'red', motivo: `Zebra (fora) venceu ${gc}x${gf}` }
        : { resultado: 'green', motivo: `Zebra (fora) não venceu (${gc}x${gf})` };
    }
    case 'over_limite_70': {
      // Calcula a linha REAL apostada:
      // 1) Se placar de entrada foi fornecido (auditoria manual): linha = placar_entrada_total + 0.5
      //    Ex: entrou em 1x0 → linha = 1.5; entrou em 2x1 → linha = 3.5.
      // 2) Senão: tenta extrair do campo "mercado_sugerido" do objeto da entrada.
      // 3) Senão: assume linha 2.5 (fallback antigo — pode estar errado).
      let linha;
      let origem;
      const pec = placar.gols_casa_entrada, pef = placar.gols_fora_entrada;
      if (pec !== null && pec !== undefined && pef !== null && pef !== undefined) {
        const totalEntrada = pec + pef;
        linha = totalEntrada + 0.5;
        origem = `entrada ${pec}x${pef}`;
      } else {
        const m = (obj.mercado_sugerido || '').toLowerCase().match(/(\d+)[.,]5/);
        if (m) {
          linha = parseFloat(m[1] + '.5');
          origem = `mercado_sugerido`;
        } else {
          linha = 2.5;
          origem = `default — sem placar de entrada`;
        }
      }
      return total > linha
        ? { resultado: 'green', motivo: `${total} gols > Over ${linha} (${origem})` }
        : { resultado: 'red', motivo: `${total} gols não passou Over ${linha} (${origem})` };
    }
    case 'back_2x2': {
      if (gc === 2 && gf === 2) return { resultado: 'green', motivo: 'Placar 2x2 (alvo)' };
      if (gc >= 1 && gf >= 1) return { resultado: 'green', motivo: `Passou por 1x1 (final ${gc}x${gf}) — cash-out` };
      return { resultado: 'red', motivo: `Não passou por 1x1 (${gc}x${gf})` };
    }
    case 'back_goleada': {
      const venceu4 = (gc >= 4 && gc > gf) || (gf >= 4 && gf > gc);
      return venceu4
        ? { resultado: 'green', motivo: `Goleada (${gc}x${gf})` }
        : { resultado: 'red', motivo: `Sem goleada (${gc}x${gf})` };
    }
    case 'lay_1x0': {
      // GREEN se placar NÃO foi exatamente 1x0; RED se foi 1x0
      return (gc === 1 && gf === 0)
        ? { resultado: 'red', motivo: `Placar foi exatamente 1x0 — Lay perdeu` }
        : { resultado: 'green', motivo: `Placar foi ${gc}x${gf} (≠ 1x0) — Lay ganhou` };
    }
    case 'lay_0x1': {
      // GREEN se placar NÃO foi exatamente 0x1; RED se foi 0x1
      return (gc === 0 && gf === 1)
        ? { resultado: 'red', motivo: `Placar foi exatamente 0x1 — Lay perdeu` }
        : { resultado: 'green', motivo: `Placar foi ${gc}x${gf} (≠ 0x1) — Lay ganhou` };
    }
    default:
      return { resultado: 'inconclusivo', motivo: 'método não auditável' };
  }
}

function normalizarTxt(s) {
  return (s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Leitura/escrita genérica de arquivo no GitHub (retorna conteúdo como string)
async function lerFinalizados(env) {
  try {
    const { conteudo, sha } = await lerArquivoGithubGenerico(env, FINALIZADOS_PATH);
    if (!conteudo) return { dados: [], sha: null };
    let dados;
    try { dados = JSON.parse(conteudo); } catch { dados = []; }
    return { dados: Array.isArray(dados) ? dados : [], sha };
  } catch {
    return { dados: [], sha: null };
  }
}

async function lerArquivoGithubGenerico(env, path) {
  const url = `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/contents/${path}?ref=${env.GITHUB_BRANCH || 'main'}`;
  const r = await fetch(url, {
    headers: {
      Authorization: `Bearer ${env.GITHUB_TOKEN}`,
      Accept: 'application/vnd.github+json',
      'User-Agent': 'analises-trader-worker',
    },
  });
  if (r.status === 404) return { conteudo: null, sha: null };
  if (!r.ok) throw new Error(`GitHub leitura: ${r.status}`);
  const dados = await r.json();
  const conteudo = atob(dados.content.replace(/\s/g, ''));
  // Decodifica UTF-8 corretamente
  const bytes = Uint8Array.from(conteudo, (c) => c.charCodeAt(0));
  const texto = new TextDecoder('utf-8').decode(bytes);
  return { conteudo: texto, sha: dados.sha };
}

async function salvarArquivoGithubGenerico(env, path, conteudoStr, sha, mensagem) {
  const url = `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/contents/${path}`;
  // Codifica UTF-8 -> base64
  const bytes = new TextEncoder().encode(conteudoStr);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  const b64 = btoa(bin);
  const body = { message: mensagem, content: b64, branch: env.GITHUB_BRANCH || 'main' };
  if (sha) body.sha = sha;
  const r = await fetch(url, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${env.GITHUB_TOKEN}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
      'User-Agent': 'analises-trader-worker',
    },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`GitHub escrita: ${r.status}: ${await r.text()}`);
  return await r.json();
}

// =============================================================
// Busca placares na API-Football
// =============================================================
async function buscarPlacaresDoDia(env, data) {
  // Endpoint: /fixtures?date=YYYY-MM-DD
  // Doc: https://www.api-football.com/documentation-v3#tag/Fixtures
  const url = `https://v3.football.api-sports.io/fixtures?date=${data}`;
  const r = await fetch(url, {
    headers: {
      'x-apisports-key': env.API_FOOTBALL_KEY,
    },
  });
  if (!r.ok) {
    throw new Error(`API-Football retornou ${r.status}: ${await r.text()}`);
  }
  const dados = await r.json();
  const placares = [];
  for (const item of dados.response || []) {
    const status = item.fixture?.status?.short; // FT, AET, PEN, NS, 1H, HT, 2H...
    const isFinal = ['FT', 'AET', 'PEN'].includes(status);
    const isAgendado = ['NS', 'TBD', 'PST', 'CANC', 'SUSP'].includes(status);

    placares.push({
      casa: item.teams?.home?.name || '',
      fora: item.teams?.away?.name || '',
      gols_casa: item.goals?.home ?? null,
      gols_fora: item.goals?.away ?? null,
      gols_casa_ht: item.score?.halftime?.home ?? null,
      gols_fora_ht: item.score?.halftime?.away ?? null,
      status: isFinal ? 'finalizado' : (isAgendado ? 'agendado' : 'em_andamento'),
      liga: item.league?.name || '',
    });
  }
  return placares;
}

// Tenta encontrar placar de um jogo pelo nome (matching flexível)
function encontrarPlacar(jogoStr, placares) {
  // Normaliza: minúsculas, sem acentos
  const norm = (s) => (s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const jogoNorm = norm(jogoStr);
  // Tenta extrair os 2 times
  const sepRegex = / x | vs | - /;
  const partes = jogoNorm.split(sepRegex);
  if (partes.length !== 2) return null;
  const [timeCasaBusca, timeForaBusca] = partes.map(s => s.trim());

  // Função: o nome do time tá contido na string (parcial)?
  const match = (timeBusca, timeReal) => {
    const a = norm(timeReal);
    if (!a || !timeBusca) return false;
    // Match se uma palavra grande do nome de busca está contida
    const palavras = timeBusca.split(' ').filter(p => p.length >= 4);
    if (palavras.length === 0) return a.includes(timeBusca);
    return palavras.some(p => a.includes(p));
  };

  // Procura placar onde os 2 times batem
  for (const p of placares) {
    if (match(timeCasaBusca, p.casa) && match(timeForaBusca, p.fora)) return p;
    // Tenta invertido também (caso o usuário tenha invertido casa/fora)
    if (match(timeCasaBusca, p.fora) && match(timeForaBusca, p.casa)) {
      return { ...p, _invertido: true };
    }
  }
  return null;
}

// =============================================================
// LÓGICA DE AUDITORIA POR MÉTODO
// =============================================================
function auditarPorMetodo(trade, placar) {
  const metodo = (trade.metodo || '').toLowerCase();
  const gc = placar.gols_casa;
  const gf = placar.gols_fora;
  const gcHt = placar.gols_casa_ht ?? 0;
  const gfHt = placar.gols_fora_ht ?? 0;

  if (gc === null || gf === null) {
    return { resultado: 'inconclusivo', motivo: 'sem placar finalizado' };
  }

  // BACK FAVORITO — green se o favorito venceu
  if (metodo.includes('back favorito')) {
    // Por padrão: assumimos que a "casa" é favorita, exceto se mercado disser claro
    // O mais seguro é checar o mercado. Aqui usamos uma heurística simples:
    // Se mercado mencionar nome do time, comparamos com placar.
    const merc = (trade.mercado || '').toLowerCase();
    const venceuCasa = gc > gf;
    const venceuFora = gf > gc;
    if (merc.includes(placar.casa.toLowerCase().split(' ')[0])) {
      return venceuCasa
        ? { resultado: 'green', motivo: `Casa venceu ${gc}x${gf}` }
        : { resultado: 'red', motivo: `Casa não venceu (${gc}x${gf})` };
    }
    if (merc.includes(placar.fora.toLowerCase().split(' ')[0])) {
      return venceuFora
        ? { resultado: 'green', motivo: `Fora venceu ${gc}x${gf}` }
        : { resultado: 'red', motivo: `Fora não venceu (${gc}x${gf})` };
    }
    // Sem identificação clara: usa odd como pista (favorito tem odd menor)
    return { resultado: 'inconclusivo', motivo: 'Mercado não identifica claramente o favorito' };
  }

  // LAY ZEBRA — green se a zebra NÃO venceu (i.e., favorito venceu ou empatou)
  if (metodo.includes('lay zebra')) {
    const merc = (trade.mercado || '').toLowerCase();
    // Se mercado menciona a zebra, lay nela = green se ela não venceu
    if (merc.includes(placar.casa.toLowerCase().split(' ')[0])) {
      return gc > gf
        ? { resultado: 'red', motivo: `Casa (zebra) venceu ${gc}x${gf}` }
        : { resultado: 'green', motivo: `Casa não venceu (${gc}x${gf})` };
    }
    if (merc.includes(placar.fora.toLowerCase().split(' ')[0])) {
      return gf > gc
        ? { resultado: 'red', motivo: `Fora (zebra) venceu ${gc}x${gf}` }
        : { resultado: 'green', motivo: `Fora não venceu (${gc}x${gf})` };
    }
    return { resultado: 'inconclusivo', motivo: 'Mercado não identifica claramente a zebra' };
  }

  // OVER LIMITE 70+ — green se a linha "Mais X.5" foi atingida
  // Como o método é ao vivo e a linha varia, fazemos checagem flexível:
  // se mercado for "Mais 2.5" e total gols >= 3, green; "Mais 3.5" e >= 4, etc
  if (metodo.includes('over limite') || metodo.includes('over 70')) {
    const merc = (trade.mercado || '').toLowerCase();
    const m = merc.match(/mais\s*(\d+)[.,]?5/);
    if (!m) return { resultado: 'inconclusivo', motivo: 'Mercado sem linha clara' };
    const linha = parseInt(m[1]);
    const totalGols = gc + gf;
    return totalGols > linha
      ? { resultado: 'green', motivo: `${totalGols} gols (linha Mais ${linha}.5)` }
      : { resultado: 'red', motivo: `${totalGols} gols (linha Mais ${linha}.5)` };
  }

  // BACK 2x2 — green se o método foi seguido à risca (cash-out em 1x1)
  // Regra: passou por 1x1 OU 2x1/1x2 OU placar final foi 2x2 → green
  if (metodo.includes('2x2') || metodo.includes('back 2x2')) {
    // Sabemos placar final mas não a sequência. Aproximação:
    // - Se placar final 2x2 → green (alvo bateu)
    // - Se placar final passou por 1x1 (i.e. gc>=1 e gf>=1 e total>=2): provavelmente passou por 1x1 → green
    // - Se placar final tem mais gols mas chegou a 2x2 ou foi por 1x1: green
    // - Se placar foi tipo 3x0, 0x0, 0x1: não passou por 1x1 → red
    if (gc === 2 && gf === 2) {
      return { resultado: 'green', motivo: 'Placar final 2x2 (alvo)' };
    }
    // Heurística: se ambos marcaram pelo menos 1 e o jogo teve 2+ gols totais, é altamente provável ter passado por 1x1
    if (gc >= 1 && gf >= 1) {
      return { resultado: 'green', motivo: `Passou por 1x1 (final ${gc}x${gf}) — cash-out aplicado` };
    }
    return { resultado: 'red', motivo: `Não passou por 1x1 (final ${gc}x${gf})` };
  }

  // BACK GOLEADA — green se algum time marcou 4+ E venceu
  if (metodo.includes('goleada')) {
    const venceuCom4 = (gc >= 4 && gc > gf) || (gf >= 4 && gf > gc);
    return venceuCom4
      ? { resultado: 'green', motivo: `Goleada confirmada (${gc}x${gf})` }
      : { resultado: 'red', motivo: `Sem goleada (${gc}x${gf})` };
  }

  // OVER GOLS PRÉ/LIVE — green se a linha indicada bater
  // Tenta extrair a linha do campo mercado/metodo do trade.
  if (metodo.includes('over gols') || metodo.includes('over golos') ||
      metodo.includes('over 1.5') || metodo.includes('over 2.5') ||
      metodo.includes('ambas marcam') || metodo.includes('over ht') ||
      metodo.includes('over 0.5 ht')) {
    const total = gc + gf;
    const mercadoTxt = `${metodo} ${(trade.mercado || '').toLowerCase()}`;

    // Ambas Marcam
    if (mercadoTxt.includes('ambas')) {
      return (gc >= 1 && gf >= 1)
        ? { resultado: 'green', motivo: `Ambas marcaram (${gc}x${gf})` }
        : { resultado: 'red', motivo: `Nem ambas marcaram (${gc}x${gf})` };
    }
    // Over HT (0.5 no primeiro tempo)
    if (mercadoTxt.includes('ht') || mercadoTxt.includes('1o tempo') || mercadoTxt.includes('primeiro tempo')) {
      const totalHt = (placar.gols_casa_ht ?? 0) + (placar.gols_fora_ht ?? 0);
      return totalHt >= 1
        ? { resultado: 'green', motivo: `Over 0.5 HT batido (HT ${placar.gols_casa_ht ?? 0}x${placar.gols_fora_ht ?? 0})` }
        : { resultado: 'red', motivo: `Sem gol no 1o tempo (HT 0x0)` };
    }
    // Over com linha numérica (busca "1.5", "2.5", "3.5"...)
    const mLinha = mercadoTxt.match(/(\d+)[.,]5/);
    const linha = mLinha ? parseFloat(mLinha[1] + '.5') : 1.5; // default Over 1.5
    return total > linha
      ? { resultado: 'green', motivo: `${total} gols (Over ${linha} batido)` }
      : { resultado: 'red', motivo: `${total} gols (Over ${linha} não batido)` };
  }

  // CONFIRMAÇÃO VISUAL — depende do mercado real apostado, então deixamos inconclusivo
  if (metodo.includes('confirmação visual') || metodo.includes('confirmacao visual')) {
    return { resultado: 'inconclusivo', motivo: 'Confirmação Visual: marcar manualmente (depende do mercado escolhido na hora)' };
  }

  return { resultado: 'inconclusivo', motivo: `Método '${trade.metodo}' sem regra automática` };
}

// =============================================================
// GitHub API
// =============================================================
async function lerArquivoGithub(env, path) {
  const url = `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/contents/${path}?ref=${env.GITHUB_BRANCH || 'main'}`;
  const r = await fetch(url, {
    headers: {
      Authorization: `Bearer ${env.GITHUB_TOKEN}`,
      Accept: 'application/vnd.github+json',
      'User-Agent': 'analises-trader-worker',
    },
  });
  if (r.status === 404) return { trades: [], sha: null };
  if (!r.ok) throw new Error(`GitHub leitura: ${r.status} ${await r.text()}`);
  const dados = await r.json();
  const conteudo = atob(dados.content.replace(/\s/g, ''));
  let trades = [];
  try {
    const parsed = JSON.parse(conteudo);
    trades = Array.isArray(parsed) ? parsed : parsed.trades || [];
  } catch { trades = []; }
  return { trades, sha: dados.sha };
}

async function salvarArquivoGithub(env, path, trades, sha, mensagem) {
  const url = `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/contents/${path}`;
  const conteudo = JSON.stringify(trades, null, 2);
  const conteudoBase64 = btoa(unescape(encodeURIComponent(conteudo)));
  const body = { message: mensagem, content: conteudoBase64, branch: env.GITHUB_BRANCH || 'main' };
  if (sha) body.sha = sha;
  const r = await fetch(url, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${env.GITHUB_TOKEN}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
      'User-Agent': 'analises-trader-worker',
    },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`GitHub escrita: ${r.status} ${await r.text()}`);
  return await r.json();
}

function resposta(corpo, status, corsHeaders) {
  return new Response(JSON.stringify(corpo), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders },
  });
}

// =============================================================
// Telegram (notificações)
// =============================================================
async function enviarTelegram(env, mensagem) {
  if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return false;
  try {
    const url = `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`;
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: env.TELEGRAM_CHAT_ID,
        text: mensagem,
        parse_mode: 'HTML',
        disable_web_page_preview: true,
      }),
    });
    return r.ok;
  } catch (err) {
    console.error('Erro Telegram:', err.message);
    return false;
  }
}
