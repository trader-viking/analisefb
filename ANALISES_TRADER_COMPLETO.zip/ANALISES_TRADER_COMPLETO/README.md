# Análises Trader Viking — Sistema Completo

Sistema de sports trading que: baixa PDFs de partidas do clube.theoborges.com,
analisa com Gemini, publica relatórios num site público e audita placares
automaticamente. Tudo orquestrado em 3 componentes que conversam entre si.

## Arquitetura

```
                      ┌─────────────────────────┐
                      │  PC LOCAL (main.py)     │
                      │  - Login no clube        │
                      │  - Baixa PDFs do dia     │
                      │  - Analisa com Gemini    │
                      │  - Publica no GitHub     │
                      │  - Manda Telegram        │
                      └────────────┬────────────┘
                                   │ git push
                                   ▼
                      ┌─────────────────────────┐
                      │  GITHUB (analisefb)      │
                      │  - JSONs em relatorios/  │
                      └────┬───────────────────┬─┘
                           │                   │
                  Cloudflare lê               Worker lê/escreve
                  no build                      via API GitHub
                           ▼                   ▼
              ┌──────────────────────┐  ┌──────────────────────┐
              │  CLOUDFLARE PAGES    │  │  CLOUDFLARE WORKER   │
              │  analisefb.pages.dev │←─│  /auditar /placares  │
              │  - Site Next.js      │  │  - cron 10min        │
              │  - Lê JSONs no build │  │  - API-Football      │
              └──────────────────────┘  └──────────────────────┘
                           ▲                          │
                           └──────── fetch ───────────┘
                                  (placares ao vivo)
```

## Estrutura do pacote

```
ANALISES_TRADER_COMPLETO/
├── README.md                ← este arquivo
├── INSTALACAO_DO_ZERO.md    ← guia completo passo a passo
├── instalar.ps1             ← script automático (Windows)
│
├── python/                  ← roda no seu PC
│   ├── main.py              ← orquestrador principal
│   ├── analisar.py          ← reanálise (sem rescraping)
│   ├── publicar.py          ← publica no GitHub
│   ├── telegram_helper.py   ← notificações
│   ├── monitor_ao_vivo.py   ← (opcional) monitor ao vivo
│   ├── requirements.txt
│   ├── config.example.json  ← modelo de config (copiar para config.json)
│   └── COMANDOS.md
│
├── site/                    ← deploy em Cloudflare Pages
│   ├── app/                 ← rotas (home, /desempenho, /relatorio/[slug])
│   ├── components/          ← componentes React
│   ├── lib/                 ← lógica de relatórios e desempenho
│   ├── package.json
│   ├── relatorios/          ← JSONs (sincronizam via Git)
│   └── ...
│
└── worker/                  ← deploy em Cloudflare Workers
    ├── index.js             ← endpoints /auditar /placares /reauditar
    └── wrangler.toml
```

## Como usar (resumo)

**Primeira instalação numa máquina nova:**
1. Leia o `INSTALACAO_DO_ZERO.md`
2. Rode o `instalar.ps1` (Windows) — instala Python, Git, Node automaticamente
3. Siga os passos manuais (criar repo GitHub, deployar Worker, configurar Pages)

**Uso diário (depois de instalado):**
```powershell
cd C:\ANALISES_TRADER\python
python main.py          # analisa hoje
python main.py amanha   # analisa amanhã
```

O resto é automático: publica no GitHub, atualiza o site, manda Telegram,
auditoria a cada 10min.

## Componentes em detalhes

### 1. Python (PC local)

Roda manualmente (ou via Task Scheduler). Logado no clube, baixa os PDFs do
dia, extrai texto, manda pro Gemini com prompt rigoroso, recebe JSON com
entradas (5 métodos + Confirmação Visual) e jogos a evitar, salva relatório
JSON, faz `git push` pro repositório.

**Métodos suportados:**
- 🟢 Back Favorito (só 16 ligas grandes)
- 🔴 Lay Zebra (só 16 ligas grandes)
- 🟣 Over Limite 70+ (sempre ao vivo)
- 🔵 Back 2x2
- 🟡 Back Goleada
- 👁 Confirmação Visual (leitura tática opcional)

### 2. Site Next.js (Cloudflare Pages)

Lê os JSONs do GitHub no build, gera site estático com filtros, abas
(Ativos/Encerrados), badge de método, placar ao vivo, página `/desempenho`
com tracking completo. Atualiza sozinho a cada git push.

### 3. Worker (Cloudflare Workers)

API que: busca placares na API-Football, grava status (em_andamento/finalizado)
nos relatórios via API do GitHub, calcula vereditos GREEN/RED dos métodos.
Roda automaticamente via cron a cada 10min.

## Configuração necessária

**No PC (`config.json`):**
- Credenciais do clube (usuário/senha)
- Chave da API do Gemini
- Token de fallback do clube (link do YouTube)
- Token do Telegram (opcional)
- Listas de ligas permitidas

**No Cloudflare Worker (variáveis):**
- `GITHUB_TOKEN` — token classic com escopo `repo`
- `GITHUB_OWNER` — usuário/org do GitHub
- `GITHUB_REPO` — nome do repositório
- `GITHUB_BRANCH` — geralmente `main`
- `API_FOOTBALL_KEY` — chave da api-sports.io
- `ALLOWED_ORIGIN` — URL do site no Cloudflare Pages (sem barra no final!)
- `TELEGRAM_BOT_TOKEN` e `TELEGRAM_CHAT_ID` (opcionais)

**No Cloudflare Pages (variáveis):**
- `NODE_VERSION` = `20`
- `NEXT_PUBLIC_API_URL` = URL do Worker

## Documentação detalhada

- **Instalar do zero:** `INSTALACAO_DO_ZERO.md`
- **Comandos do dia a dia:** `python/COMANDOS.md`
- **Documentação do site:** `site/README.md`

## Suporte e diagnóstico

**Problemas comuns:**

| Sintoma | Causa provável | Solução |
|---------|----------------|---------|
| Análise vazia (0 entradas, 0 evitar) | Prompt quebrado ou Gemini falhando | Olhar terminal — agora mostra erro detalhado |
| PDFs caem no login no meio | Rate limit do clube | `main.py` já tem pausas adaptativas + relogin automático |
| Auditoria não atualiza placares | `GITHUB_TOKEN` sem permissão de escrita | Gerar token classic novo com escopo `repo` |
| Site não mostra dados | `ALLOWED_ORIGIN` com barra no final | Remover a barra `/` no Cloudflare |
| Botão "Rolando agora" sempre 0 | API-Football não cobre as ligas/horário | Limitação do plano grátis, não tem como contornar |

**Logs úteis:**
- `python/debug/` — screenshots e respostas quebradas do Gemini
- Worker: ver logs em tempo real no Cloudflare → Workers → Logs

## Stack técnica

- **Python 3.10+** com Playwright (Chromium), pdfplumber, google-genai
- **Next.js 14** com React, Tailwind, TypeScript
- **Cloudflare Workers** (JavaScript) + Cron Triggers
- **GitHub** como banco de dados (commits = histórico de relatórios)
- **Gemini** (modelo `gemini-2.5-flash-lite`) para análise
- **API-Football** (api-sports.io) para placares ao vivo
