"""
Análise de Partidas via RADAR ESPORTIVO
========================================
Alternativa ao main.py original (que usa clube.theoborges.com.br).
Login → coleta partidas → gera PDF de cada jogo (3 abas: Details + Standings + Recent)
→ Gemini → relatório JSON → publica no site.

REQUISITOS (config.json):
- radar_partidas_usuario: email do radaresportivo.com
- radar_partidas_senha: senha do radaresportivo.com
  (se não definir, cai pra usuario/senha do clube principal)
- Todo o resto igual ao main.py (gemini_api_key, site_path, etc.)

USO:
    python main_radar.py            # hoje
    python main_radar.py amanha     # amanhã
"""
import asyncio
import json
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta

# Força UTF-8 no stdout/stderr — evita UnicodeEncodeError em Windows com
# Python 3.14+ (cp1252) ao tentar imprimir emojis (📅, ✓, etc.)
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass
from pathlib import Path

from playwright.async_api import async_playwright

# Reaproveita funções comuns do main.py
from main import (
    load_config,
    slug,
    extrair_texto_pdf,
    chamar_gemini,
    _extrair_json,
    aplicar_trava_ligas,
    PROMPT_LOTE,
)

try:
    from telegram_helper import (
        enviar_relatorio_pronto,
        enviar_erro,
    )
except ImportError:
    enviar_relatorio_pronto = None
    enviar_erro = None

from google import genai
from google.genai import types as genai_types


BASE_DIR = Path(__file__).parent
PDF_DIR = BASE_DIR / "pdfs_radar"
OUTPUT_DIR = BASE_DIR / "relatorios"  # mesma pasta do main.py — publica no mesmo site
DEBUG_DIR = BASE_DIR / "debug"

RADAR_LOGIN_URL = "https://radaresportivo.com/auth/login"
RADAR_HOME_URL = "https://radaresportivo.com"

async def _salvar_debug(page, prefixo: str):
    """Salva screenshot + HTML pra debug quando algo dá errado."""
    try:
        DEBUG_DIR.mkdir(exist_ok=True)
        await page.screenshot(path=str(DEBUG_DIR / f"{prefixo}.png"), full_page=True)
        html = await page.content()
        (DEBUG_DIR / f"{prefixo}.html").write_text(html[:300000], encoding="utf-8")
        print(f"     💾 debug salvo: debug/{prefixo}.png + .html")
    except Exception:
        pass


# ============================================================
# Geração de PDF — em MOBILE, 1 página = todos os dados da partida
# ============================================================
async def _clicar_botao_se_existe(page, texto: str) -> bool:
    """
    Tenta clicar em um elemento (button, role=button, role=tab, div clicável)
    cujo texto BATE EXATAMENTE com 'texto'. Usa JavaScript direto pra evitar
    problemas com seletores CSS de Playwright (que falham com chars especiais
    como '/' em "Casa/Fora").

    Retorna True se conseguiu clicar. Em caso de falha, NÃO loga aqui — o
    caller decide. Para debug, use _listar_botoes_visiveis().
    """
    try:
        result = await page.evaluate(r"""
            (textoAlvo) => {
                // Seletores de elementos potencialmente clicáveis
                const sel = 'button, [role="button"], [role="tab"], a, label, div[class*="cursor-pointer"], div[onclick], span[onclick]';
                const els = document.querySelectorAll(sel);
                for (const el of els) {
                    // Visibilidade real
                    if (el.offsetParent === null) continue;
                    const rect = el.getBoundingClientRect();
                    if (rect.width === 0 || rect.height === 0) continue;
                    // Match por texto exato (trim, sem case-folding)
                    const txt = (el.textContent || '').replace(/\s+/g, ' ').trim();
                    if (txt === textoAlvo) {
                        // Scroll pra ficar no viewport
                        el.scrollIntoView({block: 'center', inline: 'center'});
                        // Click programático
                        el.click();
                        return true;
                    }
                }
                return false;
            }
        """, texto)
        if result:
            await page.wait_for_timeout(600)  # tempo pra UI atualizar
            return True
        return False
    except Exception:
        return False


async def _listar_botoes_visiveis(page) -> list:
    """
    Retorna lista de todos os botões/elementos clicáveis visíveis no momento.
    Útil pra debug quando um filtro não é encontrado.
    """
    try:
        return await page.evaluate(r"""
            () => {
                const sel = 'button, [role="button"], [role="tab"], a, label';
                const els = document.querySelectorAll(sel);
                const out = [];
                for (const el of els) {
                    if (el.offsetParent === null) continue;
                    const rect = el.getBoundingClientRect();
                    if (rect.width === 0 || rect.height === 0) continue;
                    const txt = (el.textContent || '').replace(/\s+/g, ' ').trim();
                    if (txt && txt.length < 50) out.push(txt);
                }
                return out;
            }
        """) or []
    except Exception:
        return []


async def _scroll_completo(page):
    """Faz scroll até o fim e volta pro topo pra forçar lazy-load."""
    for _ in range(3):
        await page.evaluate("() => window.scrollTo(0, document.body.scrollHeight)")
        await page.wait_for_timeout(350)
    await page.evaluate("() => window.scrollTo(0, 0)")
    await page.wait_for_timeout(300)


async def _capturar_pagina_partida(page, caminho_pdf, primeira_da_partida=False):
    """
    Captura a página da partida em PDF.

    - primeira_da_partida=True → PDF completo (com cabeçalho do jogo)
    - primeira_da_partida=False → captura SÓ o container do conteúdo
      (filtros + dados), excluindo o cabeçalho fixo da partida

    Estratégia (não-primeira):
      1. Marca o container do conteúdo no DOM (subindo do botão "Detalhes"
         até achar elemento com altura significativa)
      2. Tira screenshot SÓ desse elemento (element.screenshot)
      3. Converte PNG → PDF via PIL

    Fallback: se PIL ausente ou screenshot falhar, cai pra page.pdf() normal.
    """
    try:
        await _scroll_completo(page)

        if primeira_da_partida:
            await page.pdf(
                path=str(caminho_pdf),
                format="A4",
                print_background=True,
                margin={"top": "6mm", "right": "6mm", "bottom": "6mm", "left": "6mm"},
            )
            return True

        # Marca container do conteúdo (sobe do botão "Detalhes" até achar
        # elemento com altura >= 400px)
        marcou = await page.evaluate(r"""
            () => {
                document.querySelectorAll('[data-rd-content]').forEach(el => {
                    el.removeAttribute('data-rd-content');
                });
                const btns = document.querySelectorAll('button');
                let btn = null;
                for (const b of btns) {
                    if (b.offsetParent === null) continue;
                    if ((b.textContent || '').trim() === 'Detalhes') {
                        btn = b; break;
                    }
                }
                if (!btn) return false;
                let el = btn;
                let candidato = btn;
                while (el && el.parentElement) {
                    const rect = el.getBoundingClientRect();
                    if (rect.height >= 400 && rect.width >= 250) {
                        candidato = el;
                    }
                    if (rect.height > 2000) break;
                    el = el.parentElement;
                }
                candidato.setAttribute('data-rd-content', '1');
                return true;
            }
        """)

        if not marcou:
            await page.pdf(
                path=str(caminho_pdf), format="A4", print_background=True,
                margin={"top": "6mm", "right": "6mm", "bottom": "6mm", "left": "6mm"},
            )
            return True

        # Element screenshot — só pega o container marcado
        container = page.locator('[data-rd-content="1"]').first
        try:
            img_bytes = await container.screenshot(type="png", timeout=10000)
        except Exception:
            await page.pdf(
                path=str(caminho_pdf), format="A4", print_background=True,
                margin={"top": "6mm", "right": "6mm", "bottom": "6mm", "left": "6mm"},
            )
            return True

        # PNG → PDF via PIL
        try:
            from PIL import Image
            import io
            img = Image.open(io.BytesIO(img_bytes))
            if img.mode in ("RGBA", "LA", "P"):
                bg = Image.new("RGB", img.size, (255, 255, 255))
                if img.mode == "RGBA":
                    bg.paste(img, mask=img.split()[-1])
                else:
                    bg.paste(img)
                img = bg
            img.save(str(caminho_pdf), "PDF", resolution=100.0)
            return True
        except ImportError:
            await page.pdf(
                path=str(caminho_pdf), format="A4", print_background=True,
                margin={"top": "6mm", "right": "6mm", "bottom": "6mm", "left": "6mm"},
            )
            return True
    except Exception as e:
        print(f"     ⚠ captura falhou: {e}")
        return False


async def gerar_pdf_partida(page, partida, indice, pasta_dia):
    """
    Pra UMA partida, navega pelas 3 URLs (goals, goals/standings, goals/recent)
    e em cada uma clica em TODAS as combinações de sub-filtros, gerando PDFs.
    Depois mergeia tudo num ÚNICO PDF final.

    Total esperado por partida: ~10 capturas (4 + 3 + 3).
    """
    # Extrai a URL base sem o /goals[...] no fim
    url_base_raw = partida.get("url") or ""
    m_base = re.match(r"(https?://[^/]+/\d+)", url_base_raw)
    if not m_base:
        # Fallback: monta a partir do ID
        url_partida_base = f"https://radaresportivo.com/{partida.get('id', '')}"
    else:
        url_partida_base = m_base.group(1)

    # Pasta temp pra PDFs parciais (1 por combinação de filtros)
    pasta_temp = pasta_dia / f"_temp_{indice:03d}"
    pasta_temp.mkdir(exist_ok=True)
    pdfs_parciais = []

    # Rotas a visitar: cada rota tem URL + lista de combinações de filtros a aplicar
    rotas = [
        {
            "label": "details",
            "url": f"{url_partida_base}/goals",
            # Detalhes tem 2 eixos: amostra (10 jogos/Campeonato) × mando (Global/Casa-Fora) = 4 combos
            "combos": [
                ["10 jogos", "Global"],
                ["10 jogos", "Casa/Fora"],
                ["Campeonato", "Global"],
                ["Campeonato", "Casa/Fora"],
            ],
        },
        {
            "label": "standings",
            "url": f"{url_partida_base}/goals/standings",
            # Classificação: 3 botões mutuamente exclusivos
            "combos": [["Casa"], ["Global"], ["Fora"]],
        },
        {
            "label": "recent",
            "url": f"{url_partida_base}/goals/recent",
            # Últimos jogos: 3 botões mutuamente exclusivos
            "combos": [["Casa"], ["Confronto direto"], ["Fora"]],
        },
    ]

    try:
        primeira_captura = True
        for rota in rotas:
            try:
                await page.goto(rota["url"], wait_until="domcontentloaded", timeout=30000)
                await page.wait_for_timeout(2500)  # aguarda JS renderizar dados
            except Exception as e:
                print(f"     ⚠ aba {rota['label']} falhou ao carregar: {e}")
                continue

            # Sessão expirou?
            if "/auth/login" in page.url:
                raise RuntimeError("sessão expirou — relogar")

            for combo in rota["combos"]:
                # Aplica cada filtro do combo (ordem importa).
                cliques_ok = []
                cliques_falhou = []
                for filtro in combo:
                    ok = await _clicar_botao_se_existe(page, filtro)
                    (cliques_ok if ok else cliques_falhou).append(filtro)
                if cliques_falhou:
                    print(f"     ⚠ {rota['label']}: filtros não clicados: {cliques_falhou}")
                    # Lista botões visíveis SÓ no primeiro fail dessa rota (debug)
                    if rota.get("_debug_listado") is not True:
                        rota["_debug_listado"] = True
                        btns_visiveis = await _listar_botoes_visiveis(page)
                        # Limita a 30 botões pra não inundar o log
                        amostra = btns_visiveis[:30]
                        print(f"        botões visíveis no momento ({len(btns_visiveis)} total): {amostra}")

                # Gera PDF parcial — só a 1ª captura inclui cabeçalho;
                # as demais cortam o cabeçalho pra evitar repetição
                combo_slug = "_".join(slug(f, 20) for f in combo)
                nome_parcial = f"{rota['label']}_{combo_slug}.pdf"
                caminho_parcial = pasta_temp / nome_parcial
                ok = await _capturar_pagina_partida(
                    page, caminho_parcial,
                    primeira_da_partida=primeira_captura,
                )
                if ok:
                    pdfs_parciais.append(caminho_parcial)
                    primeira_captura = False
                else:
                    print(f"     ⚠ falha {rota['label']}/{combo_slug}")

        if not pdfs_parciais:
            print(f"     ✗ nenhum PDF parcial gerado")
            return None

        # Mergeia tudo num PDF único
        nome_final = f"{indice:03d}_{slug(partida.get('nome') or partida.get('id', '?'), 50)}.pdf"
        caminho_final = pasta_dia / nome_final
        try:
            _merge_pdfs(pdfs_parciais, caminho_final)
        except Exception as e:
            print(f"     ⚠ merge falhou ({e}), usando primeiro PDF parcial")
            shutil.copy(pdfs_parciais[0], caminho_final)

        # Limpa arquivos temp
        for p in pdfs_parciais:
            try: p.unlink()
            except Exception: pass
        try: pasta_temp.rmdir()
        except Exception: pass

        return caminho_final
    except Exception as e:
        print(f"     ✗ falha geral: {e}")
        return None


def _merge_pdfs(lista_pdfs, destino):
    """
    Combina múltiplos PDFs em um único. Tenta pypdf primeiro, depois PyPDF2,
    e por último cai pra concatenação simples.
    """
    try:
        from pypdf import PdfWriter
        writer = PdfWriter()
        for p in lista_pdfs:
            writer.append(str(p))
        with open(destino, "wb") as f:
            writer.write(f)
        return
    except ImportError:
        pass
    try:
        from PyPDF2 import PdfMerger
        merger = PdfMerger()
        for p in lista_pdfs:
            merger.append(str(p))
        merger.write(str(destino))
        merger.close()
        return
    except ImportError:
        pass
    # Fallback final: apenas copia o primeiro (perde o resto)
    raise RuntimeError("Nenhuma biblioteca de merge PDF disponível (pypdf ou PyPDF2)")




# ============================================================
# Filtro de ligas (PRÉ-coleta de PDFs)
# ============================================================
# Palavras-chave de torneios internacionais que são considerados "amistosos
# importantes" e SEMPRE entram, mesmo se não estiverem nas 16 ligas principais.
LIGAS_AMISTOSOS_KEYWORDS = [
    "world cup", "copa do mundo", "fifa club world cup", "club world cup",
    "mundial de clubes", "euro", "eurocopa", "copa america", "copa américa",
    "uefa nations", "nations league", "friendly international", "international friendly",
    "amistoso internacional", "conmebol", "concacaf", "afcon", "africa cup",
    "asian cup", "qualification", "qualifier", "eliminatórias", "eliminatorias",
    "champions league", "europa league", "conference league", "libertadores",
    "sudamericana", "copa do brasil", "fa cup", "copa del rey", "dfb pokal",
    "coppa italia", "coupe de france",
]


def filtrar_ligas_permitidas(partidas, ligas_diretos):
    """
    Filtra partidas pra deixar SÓ jogos das 16 ligas principais + torneios
    internacionais importantes (amistosos de seleção, Champions, libertadores).

    Match usa palavra-limite (\b) — evita falsos positivos como
    "Premier League" da Inglaterra dar match em "Kazakhstan Premier League".

    EXEMPLOS:
      - permitida "Brazil Serie B" + liga "Brazil Serie B" → match ✓
      - permitida "Brazil Serie B" + liga "Brazil Serie A" → não ✓
      - permitida "La Liga" + liga "Spain La Liga" → match ✓ (word boundary)
      - permitida "Premier League" + liga "Kazakhstan Premier League" → match ⚠
        (pra evitar isso, use "England Premier League" no config)

    Se a partida NÃO tem informação de liga (string vazia), mantém por
    segurança — melhor analisar a mais do que perder uma oportunidade.

    Retorna (filtradas, descartadas).
    """
    ligas_norm = [l.lower().strip() for l in ligas_diretos if l]
    # Pré-compila os patterns de word-boundary
    patterns_diretos = [re.compile(r'\b' + re.escape(l) + r'\b') for l in ligas_norm]
    patterns_amistosos = [re.compile(r'\b' + re.escape(k) + r'\b') for k in LIGAS_AMISTOSOS_KEYWORDS]

    filtradas = []
    descartadas = []

    for p in partidas:
        liga = (p.get("liga") or "").lower().strip()

        # Sem info de liga → mantém por precaução
        if not liga:
            filtradas.append(p)
            continue

        # Match com word boundary nas 16 ligas
        match_direto = any(p_re.search(liga) for p_re in patterns_diretos)
        # Match com torneios internacionais
        match_amistoso = any(p_re.search(liga) for p_re in patterns_amistosos)

        if match_direto or match_amistoso:
            filtradas.append(p)
        else:
            descartadas.append(p)

    return filtradas, descartadas


# ============================================================
# Login
# ============================================================
async def fazer_login_radar(page, config):
    """Login no radaresportivo.com. Suporta sessão salva via browser_profile_radar_partidas."""
    print(f"→ Acessando {RADAR_LOGIN_URL}")
    try:
        await page.goto(RADAR_LOGIN_URL, wait_until="networkidle", timeout=30000)
    except Exception:
        await page.wait_for_load_state("domcontentloaded", timeout=10000)
    await page.wait_for_timeout(2000)

    # Já logado? Se a página redirecionou pra home ou painel, beleza
    url_atual = page.url
    if "/auth/login" not in url_atual:
        print(f"✓ Já estava logado (URL: {url_atual})")
        return

    usuario = (
        config.get("radar_partidas_usuario")
        or config.get("radar_usuario")
        or config.get("usuario")
        or ""
    ).strip()
    senha = (
        config.get("radar_partidas_senha")
        or config.get("radar_senha")
        or config.get("senha")
        or ""
    ).strip()

    if not usuario or not senha:
        print("")
        print("=" * 60)
        print("⚠ Credenciais 'radar_partidas_usuario'/'radar_partidas_senha' não definidas no config.")
        print("Faça login MANUAL no Chrome que abriu. Cookies serão salvos em")
        print("browser_profile_radar_partidas/ para próximas execuções.")
        print("=" * 60)
        print("Aguardando login manual... (timeout 5 min)")
        for _ in range(300):
            await page.wait_for_timeout(1000)
            if "/auth/login" not in page.url:
                print(f"✓ Login manual detectado (URL: {page.url})")
                return
        raise RuntimeError("Timeout aguardando login no Radar Esportivo")

    # Login automatizado
    # Tenta vários seletores comuns pra email
    sel_email = None
    for sel in ["input[type='email']", "input[name='email']", "#email",
                "input[placeholder*='mail' i]"]:
        try:
            await page.wait_for_selector(sel, timeout=3000)
            sel_email = sel
            break
        except Exception:
            continue
    if not sel_email:
        raise RuntimeError("Campo de email não encontrado no Radar Esportivo")

    # Senha
    sel_senha = None
    for sel in ["input[type='password']", "input[name='password']", "#password"]:
        elem = await page.query_selector(sel)
        if elem:
            sel_senha = sel
            break
    if not sel_senha:
        raise RuntimeError("Campo de senha não encontrado")

    print("→ Preenchendo credenciais")
    await page.fill(sel_email, usuario)
    await page.fill(sel_senha, senha)

    # Clica no botão "Entrar"
    try:
        async with page.expect_navigation(timeout=20000, wait_until="networkidle"):
            # Tenta pelo texto "Entrar" primeiro, depois por type=submit
            btn = await page.query_selector("button:has-text('Entrar')")
            if not btn:
                btn = await page.query_selector("button[type='submit']")
            if btn:
                await btn.click()
            else:
                await page.press(sel_senha, "Enter")
    except Exception:
        await page.wait_for_load_state("networkidle", timeout=10000)

    await page.wait_for_timeout(2000)
    if "/auth/login" in page.url:
        raise RuntimeError(f"Login falhou. Ainda em {page.url}")
    print(f"✓ Login OK ({page.url})")


# ============================================================
# Coletar partidas
# ============================================================
async def expandir_todas_ligas(page):
    """
    No Radar Esportivo, muitas ligas vêm COLAPSADAS por padrão (seta '>').
    Aqui expandimos todas. Funciona em desktop E mobile.

    Mede progresso pelo número de horários HH:MM visíveis (= jogos) em vez
    de pelo SVG do ícone, porque em mobile o SVG do "rádio" não existe.

    Pra evitar TOGGLE acidental (re-fechar uma liga já aberta), só clica em
    elementos com aria-expanded="false" (versão segura). Em mobile usa
    detecção alternativa por chevron-right APENAS se aria-expanded não
    detectou nada.

    Retorna o número total de cliques de expansão.
    """
    print("→ Expandindo ligas colapsadas...")
    total_expandido = 0

    # Função pra contar quantos JOGOS estão visíveis (= elementos com texto HH:MM)
    js_contar_jogos = r"""
        () => {
            let n = 0;
            const walker = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, null, false
            );
            let node;
            while (node = walker.nextNode()) {
                if (/^\d{1,2}:\d{2}$/.test((node.textContent || '').trim())) n++;
            }
            return n;
        }
    """

    for tentativa in range(4):
        antes = await page.evaluate(js_contar_jogos)

        # Estratégia 1: aria-expanded="false" (segura — só expande, não toggla)
        expandido_a = await page.evaluate(r"""
            () => {
                const candidatos = document.querySelectorAll('[aria-expanded="false"]');
                let n = 0;
                for (const el of candidatos) {
                    try { el.click(); n++; } catch(e) {}
                }
                return n;
            }
        """)
        await page.wait_for_timeout(800)

        # Estratégia 2: SVG chevron-right só se a 1 não pegou nada
        # (Evita toggle acidental se as ligas já estão abertas)
        expandido_b = 0
        if expandido_a == 0:
            expandido_b = await page.evaluate(r"""
                () => {
                    let n = 0;
                    const svgs = document.querySelectorAll('svg');
                    for (const svg of svgs) {
                        const cls = (svg.className.baseVal || svg.getAttribute('class') || '');
                        const ehChevron = /chevron-?right/i.test(cls);
                        if (!ehChevron) continue;
                        let el = svg;
                        for (let i = 0; i < 6 && el; i++) {
                            if (el.onclick || el.tagName === 'BUTTON' || el.getAttribute('role') === 'button') {
                                try { el.click(); n++; break; } catch(e) {}
                            }
                            el = el.parentElement;
                        }
                    }
                    return n;
                }
            """)
            await page.wait_for_timeout(1500)

        depois = await page.evaluate(js_contar_jogos)
        delta = depois - antes
        total_expandido += (expandido_a + expandido_b)
        print(f"  → tentativa {tentativa + 1}: cliques={expandido_a + expandido_b}, " +
              f"horários visíveis: {antes} → {depois} (+{delta})")

        if delta == 0 and (expandido_a + expandido_b) == 0:
            break

    # Scroll até o fim pra forçar lazy-loading
    print("  → fazendo scroll final pra garantir lazy-load...")
    for _ in range(5):
        await page.evaluate("() => window.scrollTo(0, document.body.scrollHeight)")
        await page.wait_for_timeout(500)
    await page.evaluate("() => window.scrollTo(0, 0)")
    await page.wait_for_timeout(800)

    final = await page.evaluate(js_contar_jogos)
    print(f"  ✓ {total_expandido} clique(s) de expansão. Total final de horários: {final}")
    return total_expandido


async def coletar_partidas_radar(page, context, data_alvo: str = None):
    """
    Vai pra home e coleta todos os jogos do dia.

    Estratégias em cascata (cada uma é uma tentativa):
      1. Links <a href="/liveRadar/...">         (jeito tradicional)
      2. Inspeção massiva de atributos+onclick   (Svelte às vezes embute IDs)
      3. Clica nos ícones e captura URL da nova aba (último recurso, mais lento)

    Salva HTML da home em debug/home_radar.html sempre que NENHUMA estratégia
    encontrar algo (pro Claude analisar).
    """
    print(f"→ Indo para home do Radar Esportivo")
    try:
        await page.goto(RADAR_HOME_URL, wait_until="networkidle", timeout=30000)
    except Exception:
        await page.wait_for_load_state("domcontentloaded")
    await page.wait_for_timeout(3000)

    # Se data_alvo é informada, tenta clicar no dia do calendário
    if data_alvo:
        try:
            dt = datetime.strptime(data_alvo, "%Y-%m-%d")
            dia_str = dt.strftime("%d/%m")
            await page.evaluate(f"""
                () => {{
                    const targets = Array.from(document.querySelectorAll('*'))
                        .filter(el => el.children.length === 0 && el.textContent.trim() === '{dia_str}');
                    if (targets.length > 0) {{
                        let node = targets[0];
                        for (let i = 0; i < 5 && node; i++) {{
                            if (node.tagName === 'A' || node.tagName === 'BUTTON' || node.onclick) {{
                                node.click(); return true;
                            }}
                            node = node.parentElement;
                        }}
                        targets[0].click();
                        return true;
                    }}
                    return false;
                }}
            """)
            await page.wait_for_timeout(3000)
        except Exception as e:
            print(f"  ⚠ Não foi possível selecionar a data {data_alvo}: {e}")

    # === EXPANDE TODAS AS LIGAS COLAPSADAS ===
    # No Radar Esportivo, ligas como "Noruega", "Suécia", etc. vêm fechadas.
    # Sem expandir, a coleta pega só Favoritos + ligas já abertas.
    await expandir_todas_ligas(page)

    # ============ Estratégia 1: a[href*="/liveRadar/"] ============
    partidas = await page.evaluate(r"""
        () => {
            const out = [];
            const vistos = new Set();
            const links = document.querySelectorAll('a[href*="/liveRadar/"]');
            for (const a of links) {
                const m = a.href.match(/\/liveRadar\/(\d+)/);
                if (!m || vistos.has(m[1])) continue;
                vistos.add(m[1]);
                out.push({ id: m[1], _origem: 'href' });
            }
            return out;
        }
    """)
    if partidas:
        print(f"  ✓ Estratégia 1 (a[href]): {len(partidas)} ID(s)")
    else:
        # ============ Estratégia 2: varredura massiva de atributos ============
        print("  → Estratégia 1 (a[href]) sem resultado. Tentando estratégia 2 (varredura de atributos)...")
        partidas = await page.evaluate(r"""
            () => {
                const ids = new Set();
                // Procura padrão /liveRadar/(\d+) em QUALQUER atributo de QUALQUER elemento
                const todos = document.querySelectorAll('*');
                for (const el of todos) {
                    for (const attr of el.attributes) {
                        const m = (attr.value || '').match(/\/liveRadar\/(\d+)/);
                        if (m) ids.add(m[1]);
                    }
                    // Inspeciona onclick string-serializado (Svelte compila assim às vezes)
                    if (el.onclick) {
                        const fn = el.onclick.toString();
                        const m = fn.match(/\/liveRadar\/(\d+)/);
                        if (m) ids.add(m[1]);
                    }
                }
                return Array.from(ids).map(id => ({ id, _origem: 'attr-scan' }));
            }
        """)
        if partidas:
            print(f"  ✓ Estratégia 2 (varredura de atributos): {len(partidas)} ID(s)")

    # ============ Estratégia 3: MOBILE — clica → URL muda → captura ID real ============
    # No modo mobile, clicar no card navega pra URL real (ex: /liveRadar/440098).
    # Marcamos os cards, clicamos um a um, capturamos a URL e voltamos com go_back.
    if not partidas:
        print("  → Estratégias 1 e 2 sem resultado. Tentando estratégia 3 (clique mobile)...")
        # Salva HTML pra debug
        try:
            html = await page.content()
            (DEBUG_DIR / "home_radar.html").write_text(html[:300000], encoding="utf-8")
            print(f"  💾 HTML salvo em debug/home_radar.html ({len(html):,} chars)")
        except Exception:
            pass

        # JavaScript para marcar TODOS os cards de partida na home,
        # extraindo info de cada (horário, nomes, liga) e deduplicando
        JS_MARCAR_CARDS = r"""
            () => {
                document.querySelectorAll('[data-radar-game-idx]').forEach(el => {
                    el.removeAttribute('data-radar-game-idx');
                });
                const horarios = [];
                const walker = document.createTreeWalker(
                    document.body, NodeFilter.SHOW_TEXT, null, false
                );
                let node;
                while (node = walker.nextNode()) {
                    const txt = (node.textContent || '').trim();
                    if (/^\d{1,2}:\d{2}$/.test(txt)) {
                        horarios.push(node.parentElement);
                    }
                }
                const assinaturas_vistas = new Set();
                const cards_resultado = [];
                let idx = 0;
                for (const horaEl of horarios) {
                    let card = horaEl;
                    for (let i = 0; i < 10 && card; i++) {
                        const txt_full = (card.textContent || '').replace(/\s+/g, ' ').trim();
                        const semHora = txt_full.replace(/\d{1,2}:\d{2}/g, '').trim();
                        if (semHora.length > 6 && semHora.length < 200) {
                            if (card.hasAttribute('data-radar-game-idx')) break;
                            if (card.querySelector('[data-radar-game-idx]')) break;
                            const assinatura = txt_full.toLowerCase()
                                .replace(/[^\w\s:]/g, '').replace(/\s+/g, ' ').trim();
                            if (assinaturas_vistas.has(assinatura)) break;
                            assinaturas_vistas.add(assinatura);
                            card.setAttribute('data-radar-game-idx', String(idx));
                            const mh = txt_full.match(/(\d{1,2}:\d{2})/);
                            const horario = mh ? mh[1] : '';
                            let liga = '';
                            let up = card;
                            for (let j = 0; j < 12 && up; j++) {
                                const h = up.querySelector('h1,h2,h3,h4,strong,.font-bold,.font-semibold');
                                if (h) {
                                    const t = (h.textContent || '').trim();
                                    if (t && t.length < 60 && !/\d{1,2}:\d{2}/.test(t)) {
                                        liga = t; break;
                                    }
                                }
                                up = up.parentElement;
                            }
                            cards_resultado.push({
                                idx: idx, nome: semHora.slice(0, 80),
                                horario: horario, liga: liga,
                            });
                            idx++;
                            break;
                        }
                        card = card.parentElement;
                    }
                }
                return cards_resultado;
            }
        """

        # 1) Marca cards iniciais (vamos guardar essa lista — ID estável)
        cards_info = await page.evaluate(JS_MARCAR_CARDS)
        if not cards_info:
            print("  ✗ Nenhum card de partida identificado. Verifique debug/home_radar.html")
            return []
        print(f"  → {len(cards_info)} cards de partida identificados (após dedup)")

        # 2) Pra cada card, clica → captura URL → volta com go_back
        # ATENÇÃO: em mobile, page.tap() funciona melhor que page.click() porque
        # o site usa touch events. Se tap falhar, click vai como fallback.
        partidas_capturadas = []
        falhas = 0
        for i_card, info in enumerate(cards_info):
            seletor = f'[data-radar-game-idx="{info["idx"]}"]'
            try:
                # Garante que o card existe (re-marca se DOM foi resetado)
                count = await page.locator(seletor).count()
                if count == 0:
                    print(f"     ⟲ remarcando cards (idx={info['idx']} sumiu)...")
                    await expandir_todas_ligas(page)
                    await page.evaluate(JS_MARCAR_CARDS)
                    count = await page.locator(seletor).count()
                    if count == 0:
                        falhas += 1
                        continue

                # Salva URL antes (pra detectar mudança)
                url_antes = page.url

                # MOBILE: tap() primeiro (dispara touch events), click() como fallback
                tap_ok = False
                try:
                    await page.tap(seletor, timeout=4000)
                    tap_ok = True
                except Exception:
                    try:
                        await page.click(seletor, timeout=4000)
                        tap_ok = True
                    except Exception:
                        pass

                if not tap_ok:
                    falhas += 1
                    if i_card == 0:
                        print(f"     ⚠ DEBUG: tap+click ambos falharam no primeiro card")
                        await _salvar_debug(page, "tap_falhou")
                    continue

                # Aguarda URL mudar (ou redirecionamento JS)
                await page.wait_for_timeout(1500)
                url_destino = page.url

                # Debug do primeiro clique pra entender o comportamento
                if i_card == 0:
                    print(f"     [DEBUG primeiro clique] {url_antes} → {url_destino}")
                    if url_antes == url_destino:
                        print(f"     ⚠ URL não mudou após tap. Salvando debug.")
                        await _salvar_debug(page, "url_nao_mudou")

                m = re.search(r'/(\d{4,})(/goals)?', url_destino)
                if m:
                    partidas_capturadas.append({
                        "id": m.group(1),
                        "url": url_destino,
                        "nome": info.get("nome", ""),
                        "horario": info.get("horario", ""),
                        "liga": info.get("liga", ""),
                        "_origem": "click-mobile",
                    })
                else:
                    falhas += 1

                # Volta pra home
                try:
                    if url_destino != url_antes:
                        await page.go_back(wait_until="domcontentloaded", timeout=8000)
                        await page.wait_for_timeout(400)
                except Exception:
                    await page.goto(RADAR_HOME_URL, wait_until="domcontentloaded", timeout=15000)
                    await expandir_todas_ligas(page)
                    await page.evaluate(JS_MARCAR_CARDS)
            except Exception as e:
                falhas += 1
                if i_card == 0:
                    print(f"     ⚠ DEBUG erro no primeiro card: {e}")
                # Tenta recuperar voltando pra home
                try:
                    await page.goto(RADAR_HOME_URL, wait_until="domcontentloaded", timeout=10000)
                    await expandir_todas_ligas(page)
                    await page.evaluate(JS_MARCAR_CARDS)
                except Exception:
                    pass

        partidas = partidas_capturadas
        if partidas:
            print(f"  ✓ Estratégia 3 mobile: {len(partidas)} IDs capturados" +
                  (f" — {falhas} falha(s)" if falhas else ""))
        else:
            print(f"  ✗ Estratégia 3 não capturou IDs (todas {falhas} falhas)")
            print(f"    Veja debug/ para entender o que aconteceu no primeiro clique.")

    if not partidas:
        print("⚠ Nenhuma partida encontrada na home — todas as 3 estratégias falharam")
        print("  HTML salvo em debug/home_radar.html — mande pro Claude analisar")
        return []

    # Se vier da Estratégia 1 ou 2 (lista só com id), enriquece com nome/horário/liga.
    # Se vier da Estratégia 3, já está completo (id sintético + info).
    precisa_enriquecer = any(
        not p.get("nome") or not p.get("horario") for p in partidas
    )
    if precisa_enriquecer:
        print(f"→ Enriquecendo {len(partidas)} jogos com nome/horário/liga...")
        partidas = await page.evaluate(r"""
            (ids) => {
                const out = [];
                for (const item of ids) {
                    const id = item.id;
                    // Procura container que mencione esse ID em algum atributo
                    let card = null;
                    const candidatos = document.querySelectorAll('*');
                    for (const el of candidatos) {
                        for (const attr of el.attributes) {
                            if ((attr.value || '').includes('/liveRadar/' + id)) {
                                let node = el;
                                for (let i = 0; i < 6 && node; i++) {
                                    const txt = (node.textContent || '').replace(/\s+/g, ' ').trim();
                                    if (txt.length > 12 && txt.length < 200) { card = node; break; }
                                    node = node.parentElement;
                                }
                                if (card) break;
                            }
                        }
                        if (card) break;
                    }
                    let nome = `jogo_${id}`;
                    let horario = '';
                    let liga = '';
                    if (card) {
                        const txt = (card.textContent || '').replace(/\s+/g, ' ').trim();
                        const mh = txt.match(/(\d{1,2}:\d{2})/);
                        if (mh) horario = mh[1];
                        nome = txt.replace(/\d{1,2}:\d{2}/g, '').trim().slice(0, 80) || nome;
                        let up = card;
                        for (let i = 0; i < 10 && up; i++) {
                            const h = up.querySelector('h1,h2,h3,h4,strong,.font-bold,.font-semibold');
                            if (h) {
                                const ligaTxt = (h.textContent || '').trim();
                                if (ligaTxt && ligaTxt.length < 60 && !/\d{1,2}:\d{2}/.test(ligaTxt)) {
                                    liga = ligaTxt; break;
                                }
                            }
                            up = up.parentElement;
                        }
                    }
                    out.push({ id, nome, horario, liga });
                }
                return out;
            }
        """, partidas)

    print(f"✓ {len(partidas)} partida(s) coletada(s)")
    return partidas


# ============================================================
# ============================================================
# (FUNÇÃO REMOVIDA — gerar_pdfs_partida não é mais usada)
# A captura agora é feita pela função capturar_texto_partida acima,
# que clica no card da partida e captura texto do painel lateral.
# ============================================================


# ============================================================
# Fluxo principal — coleta
# ============================================================
async def fluxo_coleta(config, dia: str = "hoje", data_referencia: str = None):
    DEBUG_DIR.mkdir(exist_ok=True)
    PDF_DIR.mkdir(exist_ok=True)
    if not data_referencia:
        data_referencia = datetime.now().strftime("%Y-%m-%d")
    pasta_dia = PDF_DIR / data_referencia
    pasta_dia.mkdir(exist_ok=True)

    async with async_playwright() as p:
        perfil_dir = BASE_DIR / "browser_profile_radar_partidas"
        perfil_dir.mkdir(exist_ok=True)
        # MODO MOBILE: emula iPhone 13. Em mobile o site navega entre
        # URLs reais ao invés de usar painel lateral, simplificando a coleta.
        user_agent = (
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
            "Mobile/15E148 Safari/604.1"
        )
        context = await p.chromium.launch_persistent_context(
            str(perfil_dir),
            headless=False,
            user_agent=user_agent,
            viewport={"width": 390, "height": 844},  # iPhone 13
            device_scale_factor=3,
            is_mobile=True,
            has_touch=True,
            locale="pt-BR",
            timezone_id="America/Sao_Paulo",
            args=["--disable-blink-features=AutomationControlled", "--no-sandbox"],
        )
        page = context.pages[0] if context.pages else await context.new_page()

        # Login
        await fazer_login_radar(page, config)

        # Coleta partidas (selecionando a data alvo)
        partidas = await coletar_partidas_radar(page, context, data_alvo=data_referencia)
        if not partidas:
            await context.close()
            return [], []

        # ===== FILTRO DE LIGAS — PRÉ PDFs =====
        # Só baixa PDFs das 16 ligas principais + amistosos importantes
        ligas_diretos_lista = config.get("ligas_metodos_diretos", [])
        if ligas_diretos_lista:
            antes = len(partidas)
            partidas, descartadas = filtrar_ligas_permitidas(partidas, ligas_diretos_lista)
            print(f"\n→ Filtro de ligas: mantidas {len(partidas)} de {antes} partidas")
            if descartadas:
                print(f"  → {len(descartadas)} descartadas (não estão nas 16 ligas + amistosos):")
                # Mostra até 10 exemplos do que foi cortado, pra usuário validar
                exemplos = descartadas[:10]
                for d in exemplos:
                    nome_curto = (d.get("nome") or f"jogo_{d['id']}")[:50]
                    liga = d.get("liga") or "?"
                    print(f"     ✗ {nome_curto} — {liga}")
                if len(descartadas) > 10:
                    print(f"     ... e mais {len(descartadas) - 10}")
            if not partidas:
                print("⚠ Nenhuma partida sobrou após filtro de ligas.")
                await context.close()
                return [], []
        else:
            print("⚠ 'ligas_metodos_diretos' vazio no config — processando TODAS as partidas")

        print(f"\n→ Gerando PDF de cada partida (1 PDF por jogo em modo mobile)")
        resultado = []  # lista de (partida, pdf_path)
        for i, partida in enumerate(partidas, 1):
            print(f"  [{i}/{len(partidas)}] {partida.get('nome','?')[:60]} ({partida.get('liga','')})")
            try:
                pdf = await gerar_pdf_partida(page, partida, i, pasta_dia)
                if pdf:
                    resultado.append((partida, pdf))
                    print(f"     ✓ PDF: {pdf.name}")
            except Exception as e:
                print(f"     ✗ {e}")
            await asyncio.sleep(0.5)

        await context.close()
        return partidas, resultado


# ============================================================
# Combinar 3 PDFs de uma partida num só texto pra mandar pro Gemini
# ============================================================
def combinar_textos_partida(partida, pdf):
    """
    Extrai texto do PDF gerado e formata como bloco do jogo pro Gemini.
    """
    partes = [f"=== JOGO: {partida.get('nome', 'jogo_' + partida.get('id', '?'))} ==="]
    if partida.get("liga"):
        partes.append(f"Liga: {partida['liga']}")
    if partida.get("horario"):
        partes.append(f"Horário: {partida['horario']}")
    partes.append("")
    try:
        texto = extrair_texto_pdf(pdf)
        partes.append(texto.strip())
    except Exception as e:
        partes.append(f"(erro ao extrair texto: {e})")
    return "\n".join(partes)


# ============================================================
# main()
# ============================================================
def main():
    config = load_config()

    dia = "hoje"
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower().strip()
        if arg in ("amanha", "amanhã"):
            dia = "amanha"

    if dia == "amanha":
        data_ref = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        print(f"📅 Modo: AMANHÃ ({data_ref})\n")
    else:
        data_ref = datetime.now().strftime("%Y-%m-%d")
        print(f"📅 Modo: HOJE ({data_ref})\n")

    print("=" * 60)
    print("RADAR ESPORTIVO — coleta de partidas")
    print("=" * 60)

    partidas, resultado = asyncio.run(
        fluxo_coleta(config, dia=dia, data_referencia=data_ref)
    )

    if not resultado:
        print("\nNenhum PDF gerado. Encerrando.")
        return

    print(f"\n✓ {len(resultado)} jogo(s) com PDFs gerados")

    # Análise com Gemini (mesmo prompt do main.py)
    print("\n" + "=" * 60)
    print("ETAPA: Análise consolidada com Gemini")
    print("=" * 60)

    client = genai.Client(api_key=config["gemini_api_key"])
    modelo = config.get("modelo", "gemini-2.5-flash")

    # Monta um texto único combinando TODOS os jogos (igual ao main.py).
    # Cada jogo já tem seu texto consolidado (todas as abas + sub-filtros).
    print(f"→ Lendo textos coletados de {len(resultado)} jogos...")
    blocos_jogos = []
    for partida, pdf in resultado:
        bloco = combinar_textos_partida(partida, pdf)
        blocos_jogos.append(bloco)

    # Estatística
    total_chars = sum(len(b) for b in blocos_jogos)
    print(f"  → {len(blocos_jogos)} jogos, {total_chars:,} caracteres")

    # Manda em lotes de 10 jogos (mesmo padrão do main.py)
    tamanho_lote = config.get("tamanho_lote", 10)
    lotes = [blocos_jogos[i:i+tamanho_lote] for i in range(0, len(blocos_jogos), tamanho_lote)]
    print(f"→ Dividindo em {len(lotes)} lote(s) de até {tamanho_lote} partidas")

    # Lista de ligas permitidas (trava de pós-processamento)
    ligas_diretos_lista = config.get("ligas_metodos_diretos", [])
    ligas_diretos_str = ", ".join(ligas_diretos_lista) if ligas_diretos_lista else "(nenhuma)"

    todas_entradas = []
    todos_evitar = []
    for i, lote in enumerate(lotes, 1):
        print(f"\n  [Lote {i}/{len(lotes)}] Analisando {len(lote)} partidas...")
        conteudo_lote = "\n\n".join(lote)
        prompt = PROMPT_LOTE.format(
            conteudo=conteudo_lote,
            ligas_metodos_diretos=ligas_diretos_str,
        )
        try:
            resposta = chamar_gemini(client, modelo, prompt)
            dados = _extrair_json(resposta)
            entradas = dados.get("entradas", [])
            evitar = dados.get("evitar", [])
            print(f"     ✓ lote {i}: {len(entradas)} entrada(s), {len(evitar)} evitar")
            todas_entradas.extend(entradas)
            todos_evitar.extend(evitar)
        except Exception as e:
            print(f"     ✗ lote {i} falhou: {e}")

        if i < len(lotes):
            time.sleep(6)

    # Aplica trava de ligas (mesma do main.py)
    if ligas_diretos_lista:
        todas_entradas, n_rem = aplicar_trava_ligas(todas_entradas, ligas_diretos_lista)
        if n_rem:
            print(f"\n🔒 Trava de ligas removeu {n_rem} entrada(s) de Back Favorito/Lay Zebra")

    # Salva o relatório (mesma pasta do main.py!)
    OUTPUT_DIR.mkdir(exist_ok=True)
    arq_relatorio = OUTPUT_DIR / f"relatorio_{data_ref}.json"
    dados_relatorio = {
        "data": data_ref,
        "dia_consultado": dia,
        "gerado_em": datetime.now().isoformat(),
        "fonte": "radaresportivo.com",
        "total_jogos_analisados": len(resultado),
        "entradas": todas_entradas,
        "evitar": todos_evitar,
    }
    with open(arq_relatorio, "w", encoding="utf-8") as f:
        json.dump(dados_relatorio, f, ensure_ascii=False, indent=2)

    print(f"\n✓ Relatório salvo em: {arq_relatorio}")
    print(f"  • {len(todas_entradas)} entradas com valor")
    print(f"  • {len(todos_evitar)} jogos a evitar")

    # Publica no site (mesma lógica do main.py)
    site_path = config.get("site_path")
    if site_path and config.get("publicar_automaticamente", True):
        try:
            print("\n" + "=" * 60)
            print("PUBLICAÇÃO NO SITE")
            print("=" * 60)
            destino_dir = Path(site_path) / "relatorios"
            destino_dir.mkdir(exist_ok=True)
            destino = destino_dir / f"relatorio_{data_ref}.json"
            shutil.copy(arq_relatorio, destino)
            print(f"→ Copiado para site: {destino.name}")

            cwd = str(site_path)
            arquivo_relatorio = destino  # Path do relatório que acabamos de copiar
            data_str = data_ref

            # PROTEÇÃO 1: rebase pendente de execução anterior
            rebase_dir = Path(site_path) / ".git" / "rebase-merge"
            if rebase_dir.exists():
                print(f"⚠ Rebase pendente detectado — abortando...")
                subprocess.run(["git", "rebase", "--abort"], cwd=cwd, check=False)
            rebase_apply = Path(site_path) / ".git" / "rebase-apply"
            if rebase_apply.exists():
                subprocess.run(["git", "am", "--abort"], cwd=cwd, check=False)

            # PROTEÇÃO 2: merge pendente
            merge_head = Path(site_path) / ".git" / "MERGE_HEAD"
            if merge_head.exists():
                print(f"⚠ Merge pendente detectado — abortando...")
                subprocess.run(["git", "merge", "--abort"], cwd=cwd, check=False)

            # PROTEÇÃO 3: garante estar na branch main
            res_branch = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=cwd, capture_output=True, text=True,
            )
            branch_atual = (res_branch.stdout or "").strip()
            if branch_atual == "HEAD" or not branch_atual:
                print(f"⚠ Repositório em detached HEAD — fazendo checkout main...")
                subprocess.run(["git", "checkout", "main"], cwd=cwd, check=False)

            # ESTRATÉGIA ROBUSTA contra divergência local x remoto:
            # 1. Salva o arquivo de relatório num temp
            # 2. Faz fetch + reset --hard origin/main (sincroniza local com remoto)
            # 3. Re-aplica o arquivo do relatório por cima
            # 4. Commita e dá push (sempre funciona porque não há divergência)
            import tempfile
            temp_dir = Path(tempfile.mkdtemp(prefix="radar_git_"))
            try:
                temp_arquivo = temp_dir / arquivo_relatorio.name
                shutil.copy(arquivo_relatorio, temp_arquivo)

                print("→ Sincronizando com GitHub (fetch + reset)...")
                subprocess.run(["git", "fetch", "origin", "main"], cwd=cwd, check=False)
                # Descarta qualquer commit local pendente — vamos re-fazer
                subprocess.run(
                    ["git", "reset", "--hard", "origin/main"],
                    cwd=cwd, capture_output=True, text=True,
                )

                # Re-aplica o relatório por cima do estado limpo
                arquivo_relatorio.parent.mkdir(exist_ok=True, parents=True)
                shutil.copy(temp_arquivo, arquivo_relatorio)

                subprocess.run(["git", "add", "."], cwd=cwd, check=False)
                # Só commita se houver mudança
                res_status = subprocess.run(
                    ["git", "status", "--porcelain"],
                    cwd=cwd, capture_output=True, text=True,
                )
                if (res_status.stdout or "").strip():
                    subprocess.run(
                        ["git", "commit", "-m", f"Relatório (Radar): {data_str}"],
                        cwd=cwd, check=False,
                    )
                else:
                    print("  (sem mudanças no relatório — pulando commit)")

                print("→ Enviando para o GitHub (pode demorar ~10s)...")
                res = subprocess.run(
                    ["git", "push", "origin", "main"],
                    cwd=cwd, capture_output=True, text=True,
                )
            finally:
                # Limpa temp
                try:
                    import shutil as _sh
                    _sh.rmtree(temp_dir, ignore_errors=True)
                except Exception:
                    pass
            if res.returncode == 0:
                print("✓ Publicado! Cloudflare Pages vai atualizar em 1-2 minutos.")
            else:
                print(f"⚠ Falha no push: {res.stderr[:300]}")
        except Exception as e:
            print(f"⚠ Falha na publicação: {e}")

    # Notificação Telegram
    if enviar_relatorio_pronto:
        try:
            metodos_count = {
                "back_favorito": 0, "lay_zebra": 0, "over_limite_70": 0,
                "back_2x2": 0, "back_goleada": 0,
                "lay_1x0": 0, "lay_0x1": 0,
                "confirmacao_visual": 0,
            }
            for e in todas_entradas:
                for m_key in metodos_count:
                    # Trata caso em que o objeto venha como None (não dict)
                    obj_metodo = e.get(m_key) or {}
                    if isinstance(obj_metodo, dict) and obj_metodo.get("aplicavel"):
                        metodos_count[m_key] += 1
            enviar_relatorio_pronto(
                config=config,
                data=data_ref,
                total_entradas=len(todas_entradas),
                total_evitar=len(todos_evitar),
                metodos_count=metodos_count,
                url_site=config.get("site_publico_url", ""),
            )
        except Exception as e:
            print(f"⚠ Notificação Telegram falhou: {e}")


if __name__ == "__main__":
    main()
