"""
Automação Clube Theo Borges
Loga no site, abre cada partida do dia, gera PDF de cada uma
e produz relatório consolidado no formato Quadro Operacional.
Usa a API gratuita do Google Gemini.
"""
import json
import re
import sys
import time
import asyncio
from pathlib import Path
from datetime import datetime
from urllib.parse import urlparse, urljoin

# Força UTF-8 no stdout/stderr — evita UnicodeEncodeError em Windows com
# Python 3.14+ (cp1252) ao tentar imprimir emojis (📅, ✓, etc.)
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

import pdfplumber
from playwright.async_api import async_playwright

# Notificações Telegram (opcional — funciona sem)
try:
    from telegram_helper import (
        enviar_relatorio_pronto,
        enviar_erro,
    )
except ImportError:
    enviar_relatorio_pronto = None
    enviar_erro = None
from google import genai
from google.genai import types as genai_types

BASE_DIR = Path(__file__).parent
CONFIG_PATH = BASE_DIR / "config.json"
PDF_DIR = BASE_DIR / "pdfs"
OUTPUT_DIR = BASE_DIR / "relatorios"
DEBUG_DIR = BASE_DIR / "debug"

LOGIN_URL = "https://clube.theoborges.com/login"
LISTA_URL_BASE = "https://clube.theoborges.com/matches?dia={dia}"

SEL_EMAIL = "#email"
SEL_SENHA = "#password"
# Seletores alternativos caso o site mude o HTML
SELETORES_EMAIL_ALT = [
    "#email",
    "input[name='email']",
    "input[type='email']",
    "input[placeholder*='mail' i]",
    "input[id*='email' i]",
    "form input[type='text']:first-of-type",
]
SELETORES_SENHA_ALT = [
    "#password",
    "input[name='password']",
    "input[type='password']",
    "input[id*='password' i]",
    "input[id*='senha' i]",
]
SEL_BOTAO = 'button[type="submit"]'


# ============================================================
# Configuração
# ============================================================
def load_config():
    if not CONFIG_PATH.exists():
        print("ERRO: config.json não encontrado.")
        sys.exit(1)
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def slug(texto: str, max_len: int = 80) -> str:
    """Converte texto em nome de arquivo seguro."""
    t = re.sub(r"[^\w\s-]", "", texto or "").strip()
    t = re.sub(r"\s+", "_", t)
    return t[:max_len] or "sem_nome"


# ============================================================
# Etapa 1 — Login
# ============================================================
async def fazer_login(page, config):
    print(f"→ Acessando {LOGIN_URL}")
    await page.goto(LOGIN_URL)

    # Espera anti-bot terminar (a página mostra "Aguarde enquanto sua solicitação é verificada")
    # Pode levar 5-20 segundos.
    print("→ Aguardando verificação anti-bot...")
    for tentativa in range(30):  # até 30 segundos
        try:
            texto = await page.evaluate("() => document.body ? document.body.innerText : ''")
            texto_lower = (texto or "").lower()
            ainda_verificando = (
                "verificando" in texto_lower or
                "verificada" in texto_lower or
                "aguarde" in texto_lower or
                "checking your browser" in texto_lower
            )
            if not ainda_verificando:
                break
        except Exception:
            pass
        await page.wait_for_timeout(1000)

    await page.wait_for_load_state("networkidle", timeout=15000)
    await page.wait_for_timeout(1500)

    # Já está logado? (Se sessão anterior ainda válida, o site redireciona pra /matches)
    if "/matches" in page.url or "/dashboard" in page.url or "/painel" in page.url:
        print(f"✓ Já estava logado ({page.url})")
        return

    # Detecta a mensagem específica de "Token inválido/expirado"
    try:
        texto_pagina = await page.evaluate(
            "() => document.body ? document.body.innerText : ''"
        )
        texto_lower = (texto_pagina or "").lower()
        if "token inválido" in texto_lower or "token invalido" in texto_lower:
            print("⚠ Mensagem 'Token inválido/expirado' detectada na tela de login.")
            print("  Continuando com login normal de e-mail/senha…")
    except Exception:
        pass

    # Tenta múltiplos seletores até achar o campo de email
    sel_email_usado = None
    for sel in SELETORES_EMAIL_ALT:
        try:
            await page.wait_for_selector(sel, timeout=3000)
            sel_email_usado = sel
            break
        except Exception:
            continue

    if not sel_email_usado:
        # PRIMEIRA EXECUÇÃO ou anti-bot ainda não passou: PEDIR LOGIN MANUAL
        print("")
        print("=" * 60)
        print("⚠ FORMULÁRIO DE LOGIN NÃO APARECEU AUTOMATICAMENTE")
        print("=" * 60)
        print("Possível causa:")
        print("  • Primeira vez usando perfil persistente, OU")
        print("  • Proteção anti-bot ainda não liberou")
        print("")
        print("👉 NA JANELA DO CHROME QUE ABRIU:")
        print("   1. Aguarde a verificação anti-bot terminar (se ainda estiver)")
        print("   2. Faça login MANUALMENTE no navegador:")
        print("      - Pode usar 'YouTube membro' (botão vermelho)")
        print("      - Ou e-mail/senha normal")
        print("   3. Espere a tela carregar /matches ou similar")
        print("")
        print("Aguardando você logar... (timeout: 5 minutos)")
        print("=" * 60)

        # Aguarda até 5 minutos pra você fazer login manual
        for i in range(300):
            await page.wait_for_timeout(1000)
            url_atual = page.url
            if "/matches" in url_atual or "/dashboard" in url_atual or "/painel" in url_atual:
                print(f"\n✓ Login manual detectado! URL: {url_atual}")
                print("  Cookies salvos. Próximas execuções não precisarão de login manual.")
                return
            # Mostra progresso a cada 30s
            if i > 0 and i % 30 == 0:
                print(f"  ...aguardando ({i}s) — URL atual: {url_atual}")

        # Se chegou aqui, deu timeout
        screenshot = DEBUG_DIR / f"login_timeout_{datetime.now().strftime('%H%M%S')}.png"
        DEBUG_DIR.mkdir(exist_ok=True, parents=True)
        try:
            await page.screenshot(path=str(screenshot), full_page=True)
        except Exception:
            pass
        raise RuntimeError(
            f"Timeout (5min) aguardando login manual. URL final: {page.url}\n"
            f"Screenshot: {screenshot}"
        )

    # Acha o seletor de senha equivalente
    sel_senha_usado = None
    for sel in SELETORES_SENHA_ALT:
        try:
            elem = await page.query_selector(sel)
            if elem:
                sel_senha_usado = sel
                break
        except Exception:
            continue

    if not sel_senha_usado:
        raise RuntimeError("Campo de senha não encontrado.")

    usuario = config.get("usuario", "").strip()
    senha = config.get("senha", "").strip()
    if not usuario or not senha:
        raise RuntimeError("Usuário ou senha vazios no config.json.")

    print(f"→ Preenchendo credenciais")
    await page.fill(sel_email_usado, usuario)
    await page.fill(sel_senha_usado, senha)

    print("→ Clicando em Entrar")
    selectores_botao = [
        SEL_BOTAO,
        "button[type='submit']",
        "form button:has-text('Entrar')",
        "form button:has-text('ENTRAR')",
        "button:has-text('Entrar')",
        "input[type='submit']",
    ]
    clicou = False
    try:
        async with page.expect_navigation(timeout=20000, wait_until="networkidle"):
            for sel_btn in selectores_botao:
                try:
                    elem = await page.query_selector(sel_btn)
                    if elem:
                        await elem.click()
                        clicou = True
                        break
                except Exception:
                    continue
            if not clicou:
                await page.press(sel_senha_usado, "Enter")
    except Exception:
        await page.wait_for_load_state("networkidle", timeout=10000)

    if "/login" in page.url:
        screenshot = DEBUG_DIR / f"login_falhou_{datetime.now().strftime('%H%M%S')}.png"
        DEBUG_DIR.mkdir(exist_ok=True, parents=True)
        await page.screenshot(path=str(screenshot), full_page=True)
        raise RuntimeError(
            f"Login falhou. URL: {page.url}\nScreenshot: {screenshot}"
        )

    print(f"✓ Login OK ({page.url})")


# URL alternativa de fallback (usada quando o site redireciona pra /planos)
# O token vem do config.json — chave "token_fallback".
# Se expirar, pegar novo no YouTube do Theo Borges.
def montar_url_fallback(config: dict, dia: str = "hoje") -> str:
    token = (config.get("token_fallback") or "").strip()
    if not token:
        return ""
    return f"https://clube.theoborges.com/matches?t={token}&dia={dia}"


# ============================================================
# Etapa 2 — Coletar partidas do dia
# ============================================================
async def coletar_partidas(page, dia: str = "hoje", config: dict = None):
    """Vai pra lista do dia e retorna lista de partidas com liga."""
    config = config or {}
    lista_url = LISTA_URL_BASE.format(dia=dia)
    print(f"→ Indo para lista do dia ({dia}): {lista_url}")
    await page.goto(lista_url)
    await page.wait_for_load_state("networkidle")
    await page.wait_for_timeout(2000)

    # Detecta erro de token expirado
    async def _detectar_token_expirado():
        try:
            texto = await page.evaluate(
                "() => document.body ? document.body.innerText : ''"
            )
            texto = (texto or "").lower()
            return ("token inválido" in texto or "token invalido" in texto
                    or "expirado" in texto and "youtube" in texto)
        except Exception:
            return False

    # Se o site redirecionou pra /planos ou /login, tenta a URL alternativa
    precisa_fallback = (
        "/planos" in page.url or "/plano" in page.url or
        "/login" in page.url or "/signin" in page.url
    )

    if precisa_fallback:
        print(f"⚠ Redirecionado para {page.url}. Tentando URL alternativa...")
        url_fallback = montar_url_fallback(config, dia)

        if not url_fallback:
            mensagem = (
                "❌ TOKEN DE FALLBACK NÃO CONFIGURADO\n\n"
                "Sua assinatura está expirada e não há token de fallback no config.json.\n"
                "Pegue o link atualizado no YouTube do Theo Borges e adicione no config.json:\n"
                '  "token_fallback": "SEU_TOKEN_AQUI"\n'
            )
            print(mensagem)
            try:
                from telegram_helper import enviar_erro
                enviar_erro(config, "Token de fallback ausente", mensagem)
            except Exception:
                pass
            raise RuntimeError("Sem acesso ao site: configure 'token_fallback' no config.json")

        await page.goto(url_fallback)
        await page.wait_for_load_state("networkidle")
        await page.wait_for_timeout(2000)
        print(f"→ Agora em: {page.url}")

        # Se ainda caiu no login/planos OU mostra erro de token
        token_expirado = await _detectar_token_expirado()
        ainda_bloqueado = ("/login" in page.url or "/planos" in page.url
                          or "/signin" in page.url or token_expirado)

        if ainda_bloqueado:
            mensagem = (
                "❌ TOKEN DE FALLBACK EXPIRADO\n\n"
                f"O token '{config.get('token_fallback', '')}' não funciona mais.\n\n"
                "📌 COMO RESOLVER:\n"
                "1. Abra o YouTube do Theo Borges\n"
                "2. Procure nos vídeos MAIS RECENTES (descrição ou comentário fixado)\n"
                "3. Copie o link tipo: clube.theoborges.com/matches?t=NOVO_TOKEN\n"
                "4. Pegue só a parte após 't='\n"
                "5. Atualize no config.json:\n"
                '   "token_fallback": "NOVO_TOKEN_AQUI"\n'
                "6. Rode novamente.\n"
            )
            print(mensagem)
            try:
                from telegram_helper import enviar_erro
                enviar_erro(config, "Token expirado - precisa de novo link do YouTube", mensagem)
            except Exception:
                pass
            raise RuntimeError("Token de fallback expirado. Pegue novo no YouTube do Theo Borges.")

        # Se a URL alternativa não trouxer o dia pedido, ajusta via JS na própria página
        # (o site geralmente tem links pra alternar entre hoje/amanha)
        if dia != "hoje":
            try:
                await page.evaluate(f"""
                    () => {{
                        const link = document.querySelector('a[href*="dia={dia}"]');
                        if (link) link.click();
                    }}
                """)
                await page.wait_for_load_state("networkidle")
                await page.wait_for_timeout(2000)
            except Exception:
                pass

    # Expandir TODAS as ligas que estiverem fechadas (accordion)
    print("→ Expandindo ligas fechadas (accordion)...")
    expansao = await page.evaluate("""
        async () => {
            // Procura todos os blocos de liga
            const blocos = document.querySelectorAll('.bloco-liga');
            let totalBlocos = blocos.length;
            let abertosInicial = 0;
            let cliques = 0;

            // Conta quantos já estão abertos
            for (const b of blocos) {
                if (b.getAttribute('data-loaded') === '1') abertosInicial++;
            }

            // Clica em cada botão de toggle/cabeçalho que pareça fechado
            for (const b of blocos) {
                const loaded = b.getAttribute('data-loaded');
                if (loaded === '1') continue;  // já está aberto

                // Procura o botão de expandir
                const btn = b.querySelector('.toggle-partidas, .toggle, .liga-header, .titulo-liga');
                if (btn) {
                    btn.click();
                    cliques++;
                    // Pequena pausa entre cliques pra não sobrecarregar
                    await new Promise(r => setTimeout(r, 80));
                }
            }
            return { totalBlocos, abertosInicial, cliques };
        }
    """)
    print(f"   {expansao['totalBlocos']} ligas no total | {expansao['abertosInicial']} já abertas | {expansao['cliques']} cliques de expansão")

    # Espera o conteúdo carregar via AJAX (cada clique pode disparar fetch)
    if expansao["cliques"] > 0:
        # Tempo proporcional ao número de cliques, com limite máximo
        espera_ms = min(expansao["cliques"] * 250, 8000)
        await page.wait_for_timeout(espera_ms)
        await page.wait_for_load_state("networkidle")
        await page.wait_for_timeout(1500)

    # Segunda passada: garante que tudo abriu (algumas vezes precisa clicar de novo)
    extra = await page.evaluate("""
        async () => {
            const blocos = document.querySelectorAll('.bloco-liga');
            let cliques = 0;
            for (const b of blocos) {
                const tem_conteudo = b.querySelector('.liga-conteudo a.jogo-detalhes, a[href*="/game/"]');
                if (!tem_conteudo) {
                    const btn = b.querySelector('.toggle-partidas, .toggle, .liga-header, .titulo-liga');
                    if (btn) {
                        btn.click();
                        cliques++;
                        await new Promise(r => setTimeout(r, 100));
                    }
                }
            }
            return cliques;
        }
    """)
    if extra > 0:
        print(f"   {extra} ligas reabertas na segunda passada")
        await page.wait_for_timeout(min(extra * 300, 5000))
        await page.wait_for_load_state("networkidle")
        await page.wait_for_timeout(1000)

    partidas = await page.evaluate("""
        () => {
            const out = [];
            const blocos = document.querySelectorAll('.bloco-liga');
            for (const bloco of blocos) {
                // Nome da liga: prioriza h3 dentro de .liga-nome
                let liga = '';
                const h3 = bloco.querySelector('.liga-nome h3, .titulo-liga h3, h3');
                if (h3) liga = (h3.textContent || '').trim();

                // País (fallback / metadado adicional)
                const pais = bloco.getAttribute('data-country') || '';

                // Partidas dentro do bloco
                const links = bloco.querySelectorAll('a.jogo-detalhes, a[href*="/game/"]');
                for (const a of links) {
                    const url = a.href;
                    let horario = '';
                    const elH = a.querySelector('.col-hora strong, .col-hora');
                    if (elH) horario = (elH.textContent || '').trim();

                    let timeCasa = '';
                    const elC = a.querySelector('.col-time.right');
                    if (elC) timeCasa = (elC.textContent || '').trim();

                    let timeFora = '';
                    const elF = a.querySelector('.col-time.left');
                    if (elF) timeFora = (elF.textContent || '').trim();

                    let nome = '';
                    if (timeCasa && timeFora) {
                        nome = `${timeCasa} x ${timeFora}`;
                    } else {
                        nome = (a.textContent || '').trim().replace(/\\s+/g, ' ').slice(0, 200);
                    }

                    out.push({ url, nome, liga, pais, horario, timeCasa, timeFora });
                }
            }

            // Fallback: se não achou nada via .bloco-liga, pega todos os /game/ soltos
            if (out.length === 0) {
                const links = document.querySelectorAll('a[href*="/game/"]');
                for (const a of links) {
                    out.push({
                        url: a.href,
                        nome: (a.textContent || '').trim().slice(0, 200),
                        liga: 'Sem_Liga',
                        pais: '',
                        horario: '',
                        timeCasa: '',
                        timeFora: '',
                    });
                }
            }

            return out;
        }
    """)

    print(f"→ {len(partidas)} partida(s) encontrada(s)")

    # Conta por liga e mostra um resumo
    contagem = {}
    for p in partidas:
        liga = p.get("liga") or "Sem_Liga"
        contagem[liga] = contagem.get(liga, 0) + 1
    if contagem:
        print(f"→ Distribuição por liga:")
        for liga, n in sorted(contagem.items(), key=lambda x: -x[1]):
            print(f"     • {liga}: {n}")

    # ------------------------------------------------------------
    # FILTRO DE LIGAS (config.json)
    # ------------------------------------------------------------
    # Duas formas de filtrar (use uma ou outra no config.json):
    #   "ligas_ignorar": ["Liga A", "Liga B"]  -> remove essas ligas
    #   "ligas_permitir": ["Premier", "La Liga"] -> mantém SÓ essas
    # O matching é parcial e ignora maiúsculas/acentos (ex: "serie a" pega "Brazil Serie A").
    def _norm(s):
        import unicodedata
        s = (s or "").lower()
        s = unicodedata.normalize("NFD", s)
        s = "".join(c for c in s if unicodedata.category(c) != "Mn")
        return s.strip()

    ligas_ignorar = [_norm(x) for x in config.get("ligas_ignorar", []) if x]
    ligas_permitir = [_norm(x) for x in config.get("ligas_permitir", []) if x]

    if ligas_ignorar or ligas_permitir:
        antes = len(partidas)
        filtradas = []
        removidas_por_liga = {}
        for p in partidas:
            liga_norm = _norm(p.get("liga"))
            # Modo "permitir": só mantém se casar com alguma da lista
            if ligas_permitir:
                manter = any(termo in liga_norm for termo in ligas_permitir)
                if not manter:
                    removidas_por_liga[p.get("liga")] = removidas_por_liga.get(p.get("liga"), 0) + 1
                    continue
            # Modo "ignorar": remove se casar com alguma da lista
            if ligas_ignorar:
                ignorar = any(termo in liga_norm for termo in ligas_ignorar)
                if ignorar:
                    removidas_por_liga[p.get("liga")] = removidas_por_liga.get(p.get("liga"), 0) + 1
                    continue
            filtradas.append(p)
        partidas = filtradas
        removidas = antes - len(partidas)
        if removidas > 0:
            print(f"→ Filtro de ligas: {removidas} partida(s) descartada(s), {len(partidas)} mantida(s)")
            for liga, n in sorted(removidas_por_liga.items(), key=lambda x: -x[1]):
                print(f"     ✗ {liga}: {n}")


    # Normaliza URLs para o modo detalhado
    token_fallback = (config.get("token_fallback") or "").strip()
    partidas_norm = []
    for p in partidas:
        url = p["url"]
        if "modo=detalhado" not in url:
            sep = "&" if "?" in url else "?"
            extras = []
            if "dia=" not in url:
                extras.append(f"dia={dia}")
            extras.append("modo=detalhado")
            url = url + sep + "&".join(extras)
        # Adiciona o token de acesso (caso o plano esteja expirado)
        if token_fallback and "t=" not in url:
            url += f"&t={token_fallback}"
        p["url"] = url
        if not p.get("liga"):
            p["liga"] = "Sem_Liga"
        partidas_norm.append(p)

    return partidas_norm


# ============================================================
# Etapa 3 — Gerar PDF de cada partida (em subpasta por liga)
# ============================================================
async def gerar_pdf_partida(context, partida, pasta_dia, indice, token_fallback: str = "", config: dict = None):
    """Abre a página da partida e salva como PDF dentro da subpasta da liga."""
    page = await context.new_page()
    try:
        await page.goto(partida["url"], wait_until="networkidle", timeout=60000)
        await page.wait_for_timeout(1500)

        # Detecta se caiu na tela de login (sessão expirou pelo rate limit)
        if "/login" in page.url or "/entrar" in page.url:
            print(f"     ⚠ sessão expirou nesta partida, tentando relogin...")
            if config and config.get("usuario") and config.get("senha"):
                try:
                    await fazer_login(page, config)
                    await page.wait_for_timeout(2000)
                    # Retenta abrir a partida após login
                    await page.goto(partida["url"], wait_until="networkidle", timeout=60000)
                    await page.wait_for_timeout(1500)
                    print(f"     ✓ relogin OK, retomando download")
                except Exception as e:
                    raise RuntimeError(f"falha no relogin: {e}")
            else:
                raise RuntimeError("sessão expirou e usuario/senha não estão no config para relogin automático")

        # Se foi redirecionado pra /planos, tenta de novo forçando o token
        if "/planos" in page.url or "/plano" in page.url:
            if not token_fallback:
                raise RuntimeError("Redirecionado para /planos e sem token_fallback configurado")
            url_com_token = partida["url"]
            if f"t={token_fallback}" not in url_com_token and "t=" not in url_com_token:
                sep = "&" if "?" in url_com_token else "?"
                url_com_token = url_com_token + sep + f"t={token_fallback}"
            print(f"     ⚠ redirect detectado, tentando com token: {url_com_token}")
            await page.goto(url_com_token, wait_until="networkidle", timeout=60000)
            await page.wait_for_timeout(1500)

            # Se ainda assim caiu no /planos, pula essa partida
            if "/planos" in page.url or "/plano" in page.url:
                raise RuntimeError("Redirecionado para /planos mesmo com token")

        # Cria subpasta da liga
        nome_liga = slug(partida.get("liga") or "Sem_Liga", 60)
        pasta_liga = pasta_dia / nome_liga
        pasta_liga.mkdir(exist_ok=True)

        # Nome do arquivo
        partes_nome = [f"{indice:03d}"]
        if partida.get("horario"):
            partes_nome.append(partida["horario"].replace(":", "h"))
        partes_nome.append(slug(partida["nome"], 60))
        nome_arq = "_".join(partes_nome) + ".pdf"
        caminho = pasta_liga / nome_arq

        await page.pdf(
            path=str(caminho),
            format="A4",
            print_background=True,
            margin={"top": "10mm", "right": "10mm", "bottom": "10mm", "left": "10mm"},
        )
        return caminho
    finally:
        await page.close()


# ============================================================
# Etapa 4 — Extrair texto do PDF
# ============================================================
def extrair_texto_pdf(caminho: Path) -> str:
    blocos = []
    try:
        with pdfplumber.open(caminho) as pdf:
            for pagina in pdf.pages:
                t = pagina.extract_text()
                if t:
                    blocos.append(t)
    except Exception as e:
        print(f"  ⚠ erro lendo PDF: {e}")
    return "\n\n".join(blocos)


# ============================================================
# ============================================================
# Etapa 5 — Análise em LOTES com Gemini (retorno em JSON)
# ============================================================
PROMPT_LOTE = """Você é um analista esportivo experiente operando sob o protocolo Arkeiro de sports trading profissional.

Analise CADA partida e retorne APENAS um JSON válido, sem texto antes ou depois, sem markdown, sem ```json. APENAS o JSON cru.

=====================================================================
PRINCÍPIO FUNDAMENTAL: FIDELIDADE AOS DADOS (ANTI-ALUCINAÇÃO)
=====================================================================
Esta é a regra MAIS IMPORTANTE de todas:
- Use EXCLUSIVAMENTE os dados presentes no material fornecido (PDFs/texto das
  partidas). NUNCA invente estatísticas, odds, posições na tabela, retrospectos,
  desfalques ou qualquer informação que não esteja explicitamente no material.
- Se uma informação NÃO está no material, deixe o campo vazio ("") ou omita —
  JAMAIS preencha com suposições, médias "típicas" ou conhecimento externo.
- NÃO use seu conhecimento prévio sobre os times. Baseie-se SÓ no que está escrito.
- Seja CONSISTENTE: a mesma partida com os mesmos dados deve sempre gerar a mesma
  análise. Aplique os critérios de cada método de forma objetiva e mecânica.
- Se os dados são insuficientes para aplicar qualquer método com segurança,
  mande a partida para "evitar" com o motivo "Dados insuficientes no material".
- Toda afirmação na sua análise deve ser rastreável a um dado concreto do material.

=====================================================================
CÁLCULO DE ODDS (PROBABILIDADE → FAIR ODD → ODD MÍNIMA)
=====================================================================
Os PDFs NÃO trazem odds de mercado. Você deve ESTIMAR odds de referência a
partir EXCLUSIVAMENTE das estatísticas do material, seguindo 3 passos:

1. PROBABILIDADE ESTIMADA ("probabilidade_estimada"):
   - Estime a chance do evento acontecer (0-100%), usando SÓ os dados do PDF
     (médias de gols, aproveitamento, retrospecto, mando, desfalques, posição).
   - Seja conservador e objetivo. Justifique mentalmente com os números do PDF.
   - Ex: favorito com 70% de vitórias em casa + adversário em má fase → ~65-68%.

2. FAIR ODD ("fair_odd"):
   - Calcule: fair_odd = 1 ÷ (probabilidade / 100).
   - Ex: 65% → 1 ÷ 0,65 = 1,54. Arredonde para 2 casas.
   - Esta é a odd "justa": apostar nela no longo prazo dá lucro zero.

3. ODD MÍNIMA DE ENTRADA ("odd_minima_entrada"):
   - É a fair odd + uma MARGEM DE SEGURANÇA, que cobre a incerteza da estimativa
     e garante valor (EV positivo). Use estas margens:
     * Probabilidade alta (>60%, favoritos): margem de +10% a +15% sobre a fair.
     * Probabilidade média (40-60%): margem de +15% a +20%.
     * Probabilidade baixa (<40%, zebras/over): margem de +20% a +30%.
   - Ex: fair 1,54 (prob 65%) → mínima ≈ 1,54 × 1,12 ≈ 1,72.
   - REGRA DE OURO: só vale entrar se a casa pagar IGUAL OU ACIMA da odd mínima.

IMPORTANTE: deixe claro que são ESTIMATIVAS derivadas das estatísticas, não
odds reais de mercado. Se os dados forem insuficientes para estimar a
probabilidade com o mínimo de segurança, deixe os campos de odd vazios ("").

=====================================================================
REGRA OBRIGATÓRIA SOBRE MODO (pre_jogo vs ao_vivo)
=====================================================================
Para CADA método aplicado (exceto Over Limite (+1 gol) que é sempre ao_vivo,
e Back 2x2 que é sempre pre_jogo), você DEVE preencher o campo "modo"
com base em critérios objetivos:

- NÃO use "pre_jogo" por padrão. Avalie genuinamente cada jogo.
- A maioria dos jogos com favoritismo MODERADO (odd 1.50-1.80) deve ser ao_vivo,
  porque o pré-jogo dá pouco valor e ao vivo dá margem pra confirmar tática.
- Apenas favoritismo EXTREMO (odd < 1.40-1.45) ou Back Goleada com cenário
  claro de massacre justifica pre_jogo.
- Lay Zebra ao vivo após gol da zebra é frequentemente MUITO mais lucrativo
  que pré-jogo.
- Se você está em dúvida → ao_vivo (mais seguro, dá tempo de confirmar).

=====================================================================
REGRA FUNDAMENTAL: EXATAMENTE 7 MÉTODOS SÃO PERMITIDOS
=====================================================================
NÃO sugira nenhum outro tipo de aposta além dos 7 métodos abaixo.
NÃO invente mercados fora desta lista.

=====================================================================
RESTRIÇÃO DE LIGAS PARA BACK FAVORITO E LAY ZEBRA
=====================================================================
Os métodos "Back Favorito" e "Lay Zebra" SÓ podem ser aplicados em jogos das
seguintes ligas (grandes ligas, alta liquidez):

{ligas_metodos_diretos}

REGRA OBRIGATÓRIA:
- Se o jogo NÃO pertence a uma dessas ligas, é PROIBIDO sugerir Back Favorito
  ou Lay Zebra para ele — nem que o favoritismo pareça claro.
- Para jogos fora dessas ligas, use APENAS os outros 3 métodos quando cabível:
  Over Limite (+1 gol), Back 2x2, Back Goleada.
- Esta restrição vale SOMENTE para Back Favorito e Lay Zebra. Os outros 3
  métodos podem ser aplicados em QUALQUER liga normalmente.

Os ÚNICOS 7 métodos que você pode aplicar são:

1. BACK FAVORITO
   - Apostar na vitória do favorito (mercado 1x2).
   - Aplicar quando: favorito claro nas odds (< 1.80) + boas condições (em casa,
     com elenco completo, contra adversário em má fase).
   - RESTRIÇÃO DE LIGA: só aplique se o jogo for de uma das ligas permitidas
     (ver "Restrição de Ligas" acima). Fora delas, NÃO use este método.

   CRITÉRIOS PARA ESCOLHER MODO (pre_jogo vs ao_vivo):
   - Use "pre_jogo" SE:
     * Odd pré-jogo já está atraente (≥ 1.50) com EV positivo claro
     * Favoritismo é extremo (odd < 1.40) — risco de "saltar" no ao vivo
     * Mercado pré-jogo tem boa liquidez (Premier, Bundesliga, La Liga, Champions)
   - Use "ao_vivo" SE:
     * Odd pré-jogo está muito esticada (1.20-1.40) — esperar ao vivo melhora odd
     * Liga menos líquida onde mercado abre injusto
     * Você quer entrar APÓS confirmação tática (ver o time dominar 15min)
     * Existe gatilho técnico claro (ex: "back após 1º escanteio do favorito")

2. LAY ZEBRA
   COMO FUNCIONA O LAY (importante entender antes de sugerir):
   "Lay Time X" = apostar CONTRA a vitória do Time X. Para a aposta ser
   vencedora, o adversário precisa GANHAR o jogo OU empatar. Se o Time X
   vencer, a aposta perde.
   Exemplo: "Flamengo x Palmeiras" → "Lay Palmeiras" = você ganha se o
   Flamengo vencer OU empatar; perde se o Palmeiras vencer.

   QUAL TIME COLOCAR NO LAY (regra OBRIGATÓRIA):
   Sempre coloque a ZEBRA (o time mais fraco / com odd alta para vitória)
   no Lay. NUNCA coloque o favorito no Lay — isso seria apostar contra o
   favorito, o que é o oposto do método.

   COMO IDENTIFICAR A ZEBRA CORRETAMENTE:
   - No nome do jogo, o primeiro time é o MANDANTE (casa) e o segundo é o
     VISITANTE (fora). Ex: "Flamengo x Palmeiras" → Flamengo é casa.
   - A ZEBRA é o time com PIOR contexto: pior aproveitamento recente, pior
     defesa, sem mando, longe da briga por algo importante.
   - O FAVORITO é o que tem melhor contexto. Lay vai SEMPRE no time pior.
   - Confira pelo PDF: posição na tabela, retrospecto, mando, desfalques.
     Não inverta. Se em dúvida, NÃO aplique o método.

   QUANDO APLICAR (critérios objetivos):
   - Apostar CONTRA a vitória do azarão (zebra). Lucra se vencer o favorito OU empatar.
   - Aplicar quando: zebra com odd 5.00 ou mais (>= 5.00) E desempenho ruim recente
     (sequência de derrotas, defesa vazada, fora de casa contra time forte).
   - AMBAS as condições devem estar presentes: a odd alta sozinha não basta —
     a zebra precisa também ter mau momento que justifique apostar contra ela.
   - RESTRIÇÃO DE LIGA: só aplique se o jogo for de uma das ligas permitidas
     (ver "Restrição de Ligas" acima). Fora delas, NÃO use este método.

   CRITÉRIOS PARA ESCOLHER MODO (pre_jogo vs ao_vivo):
   - Use "pre_jogo" SE:
     * Odd da zebra está muito inflada pré-jogo (> 6.00) — captura valor antes do mercado corrigir
     * Zebra tem padrão histórico de não competir nos jogos importantes
     * Histórico recente da zebra é catastrófico (4+ derrotas seguidas)
   - Use "ao_vivo" SE:
     * Cenário clássico: zebra abre o placar (sempre uma surpresa que infla a odd)
       → entrar lay zebra ao vivo após o gol da zebra para capturar odd muito melhor
     * Favorito é tecnicamente muito superior — alta probabilidade de virar
     * Tempo de jogo permite reação (idealmente antes dos 60min)

3. OVER LIMITE (+1 GOL)
   Método AO VIVO de "Mais X.5 gols", 1 linha acima do placar atual.
   - Apostar "Mais X.5 gols" AO VIVO após 65min, com X = placar total atual + 1.
     Ex: placar 1-0 (total 1) → Mais 1.5 gols. Placar 2-1 → Mais 3.5 gols.
   - Modo: SEMPRE ao_vivo. Gatilho: após 65min de jogo.
   - Pré-requisito OBRIGATÓRIO (pra marcar como aplicável):
     * Altos índices de gols na reta final, usando a tabela "MOMENTO DOS GOLS"
       do PDF — pelo menos UMA das 4 condições atende (ver critérios numéricos
       abaixo): % Marcado do favorito 61-75 OU 76-90, OU % Sofrido do adversário
       61-75 OU 76-90, todos com limiar >= 25%.
   - Pré-requisito DESEJÁVEL mas opcional:
     * Motivação clara (times brigando por algo importante OU desequilíbrio
       técnico evidente). Se houver, registre no campo "motivo_motivacao";
       se não houver, deixe vazio. Sem motivação ainda pode aplicar o método.
   - REGRA DE OURO: EVITAR entrar se o jogo estiver empatado (sem nenhum gol),
     ou em goleada já consolidada (3+ gols de diferença), ou após expulsão
     (o jogo trava). Essas três condições matam o método.

4. BACK 2x2
   - Apostar no placar exato 2x2.
   - CRITÉRIOS DE ELEGIBILIDADE (todos devem estar presentes):
     a) Alto índice de Over 2.5 gols nos jogos recentes de ambos os times
        (>= 65% dos últimos 10 jogos terminam com 3+ gols)
     b) Alto índice de Ambas Marcam (BTTS) nos jogos recentes de ambos
        (>= 65% dos últimos 10 jogos terminam com gols dos dois lados)
     c) Alto índice de Over HT (Mais 0.5 gols no 1º tempo)
        (>= 70% dos últimos 10 jogos têm gol antes do intervalo)
   - REGRAS DE SAÍDA (gestão de risco):
     * Entrar pré-jogo com odd alta (geralmente 10.00 a 15.00)
     * SAIR (cash-out) sempre que o placar passar por:
       - 1x1 (após o 2º gol — proteger lucro parcial)
       - 2x1 (favorável: a 1 gol do alvo, cash-out parcial)
       - 1x2 (favorável: a 1 gol do alvo, cash-out parcial)
     * NUNCA segurar até o final se chegar nesses placares intermediários
   - Aplicar quando:
     * Os 3 critérios estatísticos acima estão presentes
     * Ambos os times têm defesa frágil (sofrem 1.5+ gols por jogo)
     * Ambos têm ataque produtivo (marcam 1.5+ gols por jogo)
   - Modo: pré-jogo (preferencial, para captar odd alta)

5. BACK GOLEADA
   - Apostar que algum time vai marcar 4+ gols E vencer o jogo.
   - Aplicar quando: favoritismo EXTREMO (odd do favorito < 1.40)
     + adversário com defesa muito frágil + favorito em ótima fase ofensiva
     (3+ gols por jogo nos últimos 5).

   CRITÉRIOS PARA ESCOLHER MODO (pre_jogo vs ao_vivo):
   - Use "pre_jogo" SE:
     * Cenário pré-jogo já é claro de goleada (favorito devorador + zagueiros desfalcados)
     * Odd pré-jogo do mercado "marca 4+" está atrativa (≥ 4.00)
   - Use "ao_vivo" SE:
     * Favorito já está 2-0 ou 3-0 antes dos 60min e mantém pressão alta
     * Sinal de "derrocada" do adversário (cartões, lesão, time defendendo com 10)
     * Odd "marca 5+" ainda paga bem mesmo com placar parcial alto

6. LAY 1×0 (placar exato)
   - Apostar CONTRA o placar exato 1×0 (favorito mandante ganha por 1 a 0).
   - GANHA se o jogo terminar com qualquer placar DIFERENTE de 1×0 (ex: 0-0, 1-1,
     2-1, 2-0, 0-1, 3-0, etc). PERDE só se for exatamente 1×0.
   - Mercado: Correct Score — Lay 1×0. Modo: pre_jogo.
   - Stake sugerido: 2%. Odd ideal de entrada: ~10.50 (mín 9.00, máx 12.00).
   - Gatilho de saída: cash-out se 0-1, 1-1 ou após 60min sem gol.
   - Aplica quando o jogo tem perfil de muitos gols ou de visitante competitivo
     (improvável que termine no 1-0 raspado pro mandante).

7. LAY 0×1 (placar exato)
   - Apostar CONTRA o placar exato 0×1 (visitante ganha por 1 a 0).
   - GANHA se o jogo terminar com qualquer placar DIFERENTE de 0×1 (ex: 0-0, 1-1,
     2-1, 1-0, 1-2, 0-2, etc). PERDE só se for exatamente 0×1.
   - Mercado: Correct Score — Lay 0×1. Modo: pre_jogo.
   - Stake sugerido: 2%. Odd ideal de entrada: ~11.00 (mín 9.00, máx 13.00).
   - Gatilho de saída: cash-out se 1-0, 1-1 ou após 60min sem gol.
   - Aplica quando o jogo tem perfil de muitos gols ou de mandante produtivo
     (improvável que termine no 0-1 raspado pro visitante).

=====================================================================
CRITÉRIOS NUMÉRICOS OBJETIVOS (APLIQUE DE FORMA RÍGIDA E CONSISTENTE)
=====================================================================
Para garantir CONSISTÊNCIA entre análises, aplique estes limiares numéricos de
forma RÍGIDA. NÃO use julgamento subjetivo onde há um número definido. Se o dado
do PDF cruza o limiar, o método se aplica; se não cruza, NÃO se aplica.

BACK FAVORITO — aplica SE TODOS:
- Probabilidade estimada de vitória do favorito >= 65%
- Favorito jogando em casa OU claramente superior na tabela (mando/aproveitamento)
- Adversário com aproveitamento recente < 35% (má fase clara)
- Jogo numa liga permitida (lista de ligas)

LAY ZEBRA — aplica SE TODOS:
- Probabilidade estimada de vitória da zebra <= 20%
- Zebra com 3+ derrotas nos últimos 5 jogos OU média de gols sofridos >= 2.0
- Jogo numa liga permitida (lista de ligas)

OVER LIMITE (+1 GOL) — aplica SE:
- Use a tabela "MOMENTO DOS GOLS" do PDF (uma para cada time), que mostra
  % de gols Marcado e Sofrido por faixa de tempo. As faixas relevantes são
  as DUAS últimas: "61 - 75" e "76 - 90". Pelo menos UMA destas condições
  deve ser verdadeira:
  a) % Marcado do favorito na faixa "61 - 75" >= 25%, OU
  b) % Marcado do favorito na faixa "76 - 90" >= 25%, OU
  c) % Sofrido do adversário na faixa "61 - 75" >= 25%, OU
  d) % Sofrido do adversário na faixa "76 - 90" >= 25%.
  Basta UMA das 4 condições atender. Use o valor exato da tabela do PDF.
- Motivação é DESEJÁVEL mas NÃO obrigatória. Se houver motivação clara
  (times brigando por algo importante ou desequilíbrio técnico evidente),
  registre no campo "motivo_motivacao". Se não houver, deixe vazio — mas
  ainda aplica o método.
- Sempre ao_vivo: gatilho de entrada = após 65min, mercado = "Mais X.5 gols"
  onde X é 1 gol acima do placar atual (ex: 1-0 → Mais 1.5, 2-1 → Mais 3.5).

BACK 2x2 — aplica SE TODOS:
- Índice de Over 2.5 dos dois times >= 60% (média)
- Índice de Ambas Marcam >= 60% (média)
- Ambos com defesa que sofre >= 1.2 gols/jogo

BACK GOLEADA — aplica SE TODOS:
- Probabilidade estimada de vitória do favorito >= 70% (favoritismo extremo)
- Favorito com média ofensiva >= 2.5 gols/jogo nos últimos 5
- Adversário sofrendo >= 2.0 gols/jogo

LAY 1×0 — aplica SE TODOS (5 critérios OBRIGATÓRIOS, todos precisam atender):
- P(1-0) estimada < 12%. COMO ESTIMAR sem dados exatos de Poisson:
  * Se média de gols total >= 2.8 → P(1-0) ~ 8-11% (já considera baixa)
  * Se média 2.5-2.8 + visitante marca em >70% dos jogos → P(1-0) ~ 9-11%
  * Se média < 2.5 OU visitante quase não marca (<55%) → P(1-0) > 12% (NÃO aplica)
  Use a heurística acima como aproximação razoável. Não rejeite o método só
  porque o PDF não tem fórmula explícita.
- Visitante Over 0.5 > 65% (visitante marca pelo menos 1 gol em >65% dos jogos)
- Visitante marca em > 60% dos jogos (100 - failedToScore do visitante)
- Média de gols total entre os 2 times >= 2.5
- BTTS médio entre os 2 times > 50%. Se o PDF NÃO traz BTTS explícito,
  estime: (% mandante marca + % visitante marca) ÷ 2. Ex: 70% + 65% = 67%
  → considere BTTS ~67%.

⚠️ VERIFICAÇÃO CRÍTICA — LAY 1×0:
ANTES de marcar como aplicável, faça uma CHECAGEM FINAL:
- Se o visitante TEM DIFICULDADE de marcar (ex: < 1.0 gol/jogo ou texto
  como "dificuldade ofensiva"), 1×0 é JUSTAMENTE O PLACAR MAIS PROVÁVEL.
  Lay 1×0 NÃO se aplica — é o OPOSTO da operação.
- Se a média total de gols for descrita como "baixa" ou for < 2.5,
  jogos defensivos AUMENTAM a chance de 1×0. NÃO aplica Lay 1×0.
- Lay 1×0 só faz sentido em jogos com PERFIL OFENSIVO:
  visitante competitivo + média alta + ambas marcam frequente.
- Se você não está convicto que o placar 1×0 é IMPROVÁVEL,
  NÃO aplique este método.
- LEMBRE: você está apostando CONTRA o placar 1×0. Se 1×0 é provável,
  você PERDE a aposta. Tenha certeza antes de marcar como aplicável.

LAY 0×1 — aplica SE TODOS (5 critérios OBRIGATÓRIOS, todos precisam atender):
- P(0-1) estimada < 12%. COMO ESTIMAR sem dados exatos de Poisson:
  * Se média de gols total >= 2.8 → P(0-1) ~ 8-11%
  * Se média 2.5-2.8 + mandante marca em >70% dos jogos → P(0-1) ~ 9-11%
  * Se média < 2.5 OU mandante quase não marca (<55%) → P(0-1) > 12% (NÃO aplica)
- Mandante Over 0.5 > 65% (mandante marca pelo menos 1 gol em >65% dos jogos)
- Mandante marca em > 60% dos jogos (100 - failedToScore do mandante)
- Média de gols total entre os 2 times >= 2.5
- BTTS médio entre os 2 times > 50% (mesma estimativa do Lay 1×0 se faltar dado).

⚠️ VERIFICAÇÃO CRÍTICA — LAY 0×1:
- Se o mandante TEM DIFICULDADE de marcar, 0×1 é justamente provável.
  Lay 0×1 NÃO se aplica.
- Se a média total for "baixa" ou < 2.5, NÃO aplica.
- Lay 0×1 só faz sentido em jogos com mandante produtivo + média alta.
- LEMBRE: você está apostando CONTRA 0×1. Se 0×1 é provável, você PERDE.

REGRA DE DESEMPATE (ordem de prioridade quando vários se aplicam):
Back Favorito > Over Limite (+1 gol) > Back 2x2 > Lay Zebra > Lay 1×0 > Lay 0×1 > Back Goleada.
Use sempre esta ordem para definir o "mercado_principal" (o primeiro da lista
que se aplica vira o principal). Isso garante que a mesma partida sempre gere
o mesmo método principal.

Se um dado necessário NÃO estiver no PDF, considere o critério NÃO atendido
(não presuma valores). Prefira NÃO aplicar o método a chutar.

=====================================================================
CONFIANÇA NA ANÁLISE — REPORTE CRITÉRIOS ATENDIDOS POR MÉTODO
=====================================================================
Para CADA método APLICÁVEL OU EVITADO, preencha 2 campos no JSON:
- "criterios_atendidos": lista de strings curtas, cada uma é o nome de UM
  critério que o jogo ATENDE. Ex: ["prob_>=_65%", "adversario_<_35%", "em_casa"]
- "criterios_total": número inteiro com o TOTAL de critérios do método.

A % de confiança será calculada pelo site: atendidos / total × 100.

EXEMPLOS PRÁTICOS:
* Back Favorito (4 critérios totais: prob>=65%, em_casa, advers<35%, liga_permitida).
  Se o jogo atende 3: criterios_atendidos=["prob_>=_65%","em_casa","liga_permitida"],
  criterios_total=4 → 75% de confiança.
* Lay 1×0 (5 critérios totais). Se atende todos:
  criterios_atendidos=["p_1_0_<_12%","visit_over_0_5_>_65%","visit_marca_>_60%",
  "media_gols_>=_2.5","btts_>_50%"], criterios_total=5 → 100% de confiança.

ATENÇÃO: o nome em "criterios_atendidos" é um TEXTO LIVRE descrevendo o critério,
não precisa seguir formato fixo. Use nomes curtos e claros.

TOTAIS POR MÉTODO:
- back_favorito: 4 critérios (prob>=65%, em_casa_ou_aproveitamento, adversario<35%, liga_permitida)
- lay_zebra: 3 critérios (odd_zebra>=5.00, desempenho_ruim, liga_permitida)
- over_limite_70: 4 critérios (% Marcado favorito 61-75 OU 76-90, % Sofrido adversário 61-75 OU 76-90 — qualquer das 4 atende)
- back_2x2: 3 critérios (prob_empate_alta, ambas_marcam>=60%, media_gols_2.0-3.0)
- back_goleada: 3 critérios (prob_favorito>=70%, ofensiva_favorito>=2.5, defesa_adv>=2.0)
- lay_1x0: 5 critérios (P(1-0)<12%, visit_over_0.5>65%, visit_marca>60%, media>=2.5, btts>50%)
- lay_0x1: 5 critérios (P(0-1)<12%, mand_over_0.5>65%, mand_marca>60%, media>=2.5, btts>50%)

=====================================================================
🟢 EXCEÇÃO IMPORTANTE — TORNEIOS DE SELEÇÕES E AMISTOSOS
=====================================================================
SE a liga do jogo contém alguma destas palavras (case-insensitive):
"world cup", "copa do mundo", "international", "internacional", "friendly",
"amistoso", "euro", "eurocopa", "copa america", "copa américa", "conmebol",
"uefa nations", "nations league", "qualification", "qualifier", "eliminatórias",
"eliminatorias", "concacaf", "afcon", "africa cup", "asian cup",

ENTÃO esse é um JOGO DE SELEÇÕES. Os times se enfrentam RARAMENTE.

SIGA ESTAS REGRAS NESSES JOGOS:

1. NUNCA use a justificativa "Dados insuficientes" ou "amostra insuficiente
   entre os times" pra descartar. É ESPERADO que seleções tenham poucos
   confrontos diretos. Não é motivo válido pra evitar.

2. USE O HISTÓRICO INDIVIDUAL de cada seleção. Cada seleção tem
   amistosos, eliminatórias, jogos de qualificação. Esse é o dado PRINCIPAL.
   Se o PDF traz "últimos 10 jogos do time X" — USE isso.

3. Aplique os critérios numéricos sobre as MÉDIAS INDIVIDUAIS de cada
   seleção, não sobre os confrontos diretos:
   - Aproveitamento próprio do time (ex: vitórias em 10 jogos)
   - Gols marcados/sofridos por jogo
   - % BTTS, % Over 2.5 dos JOGOS DA SELEÇÃO (não dos confrontos diretos)

4. Em jogos eliminatórios (oitavas, quartas, semis, final) a motivação
   é MÁXIMA por definição. Considere automaticamente como "alta motivação"
   para o critério do Over Limite e outros.

REGRA DE OURO: se o ÚNICO motivo pra descartar é falta de confrontos
diretos OU dados históricos limitados ENTRE OS TIMES, NÃO descarte.
Analise pelo perfil individual de cada seleção. Se mesmo assim os
critérios numéricos individuais não passarem, aí sim vai pra "evitar"
— mas com motivo específico (ex: "média ofensiva 0.8 — abaixo do
mínimo de 1.5"), não com "dados insuficientes".

=====================================================================
POSIÇÃO NA TABELA E MOTIVAÇÃO (CONTEXTO OBRIGATÓRIO)
=====================================================================
Ao analisar cada jogo, considere SEMPRE a posição dos times na tabela e a
motivação contextual de cada equipe — mas APENAS com base nos dados presentes
no PDF. NUNCA invente posições, pontos ou contexto que não estejam no material.

Se a informação de tabela/classificação ESTIVER no PDF, pondere:
- DISTÂNCIA NA TABELA: um time muito superior na classificação reforça
  favoritismo (Back Favorito, Back Goleada). Times próximos na tabela
  aumentam imprevisibilidade — favoreça métodos de gols ou evite.
- MOTIVAÇÃO REAL de cada time:
  * Briga por título / vaga continental / acesso → alta motivação, jogo intenso
  * Luta contra rebaixamento → jogo tenso, pode favorecer poucos gols (cuidado
    com Over) OU desespero ofensivo (favorece gols). Avalie o contexto.
  * Time já classificado / já rebaixado / meio de tabela sem objetivo →
    BAIXA motivação. Isso é um ALERTA: favoritismo na tabela pode NÃO se
    refletir em campo (time poupa, escala reservas, joga relaxado).
    Nestes casos, seja CONSERVADOR — prefira evitar ou reduzir stake.
- DESCOMPASSO MOTIVAÇÃO x ODDS: se o favorito nas odds está desmotivado
  (já garantiu objetivo) e o "fraco" está brigando por algo, isso REDUZ o
  valor do Back Favorito e pode até justificar Lay Favorito implícito (evitar).

Se a informação de tabela/motivação NÃO estiver no PDF, NÃO mencione e NÃO
invente — baseie-se apenas no retrospecto recente e odds disponíveis.

Quando a posição/motivação influenciar sua decisão, registre isso no campo
"motivacao_tecnica" da entrada (ex: "Mandante 2º colocado brigando por título
vs visitante 14º já sem objetivos — favoritismo reforçado").

PREENCHIMENTO DO CAMPO "contexto_times":
- O PDF traz a posição de cada time NO SEU MANDO: o mandante aparece com sua
  colocação no ranking de DESEMPENHO EM CASA, e o visitante com sua colocação
  no ranking de DESEMPENHO FORA. Isso mostra a força REAL no contexto do jogo.
- Preencha "posicao" com essa colocação SE estiver no PDF (ex: "3º", "12º").
  Trata-se da posição como mandante (para o time da casa) ou como visitante
  (para o time de fora). Se NÃO estiver no PDF, deixe "" (vazio). NUNCA invente.
- Preencha "objetivo" com UM destes valores (o mais adequado ao contexto):
  "titulo" (briga pelo título/liderança)
  "libertadores" (briga por vaga na Libertadores/Champions)
  "sul_americana" (briga por vaga continental secundária/Europa League)
  "acesso" (briga por promoção/acesso à divisão superior)
  "rebaixamento" (luta contra o rebaixamento)
  "meio_tabela" (zona neutra, ainda com algum objetivo menor)
  "sem_objetivo" (já garantiu ou já perdeu tudo — desmotivado)
  "" (vazio, se não houver dados suficientes pra inferir)
- Baseie o objetivo na POSIÇÃO + fase do campeonato presentes no PDF.
  Se o PDF não traz posição nem contexto, deixe ambos vazios.

=====================================================================
DECISÃO POR PARTIDA
=====================================================================
Para CADA partida, decida:
- Se ALGUM dos 7 métodos se aplica com confiança → vai para "entradas",
  e você marca quais métodos se aplicam (pode ser mais de 1).
- Se NENHUM dos 7 métodos se encaixa → vai para "evitar" com:
  * "motivo": resumo curto em 1 linha (ex: "Sem favoritismo claro nem padrão de gols").
  * "motivos_por_metodo": OBRIGATÓRIO — explique POR QUE CADA UM dos 7 métodos não se aplica.
    Seja ESPECÍFICO citando o critério numérico que não foi atendido.
    Ex (Back Favorito): "prob estimada 52% — precisa ≥60%".
    Ex (Lay Zebra): "zebra com odd estimada 3.80 — precisa ≥5.00".
    Ex (Back 2x2): "Over 2.5 média 48% — precisa ≥60%".
    Se o dado necessário NÃO está no PDF, escreva "dado X ausente no PDF".

NÃO force entradas. Se a partida não se encaixa em nenhum método, manda pra "evitar".

AVALIAÇÃO GENUÍNA DE TODOS OS MÉTODOS (importante):
Antes de decidir, considere HONESTAMENTE cada um dos 7 métodos para a partida.
NÃO se acomode em sempre sugerir Back Favorito por ser o mais "fácil".
Verifique ativamente:
- Há uma ZEBRA com odd 5.00+ e desempenho ruim? → considere Lay Zebra.
- Ambos os times têm padrão forte de Over 2.5 + Ambas Marcam? → considere Back 2x2.
- É um favorito extremo com defesa adversária frágil? → considere Back Goleada.
- Há altos índices de gols na reta final e motivação clara no jogo?
  → considere Over Limite (+1 gol).
Um bom analista usa o método CERTO para cada jogo, não o mais cômodo. Se vários
métodos se aplicam, liste todos em "metodos_aplicados" (não apenas 1 ou 2).
Dito isso, JAMAIS invente aplicabilidade onde ela não existe — qualidade acima
de variedade.

=====================================================================
FILOSOFIA (protocolo Arkeiro)
=====================================================================
- Profitabilidade = DELTA entre preço de mercado e realidade estatística.
- Fair Odd = 1 / Probabilidade. Entrar acima da Fair Odd gera +EV.
- Você é Estrategista de Performance, não apostador.

=====================================================================
SCHEMA DO JSON:
=====================================================================

{{
  "entradas": [
    {{
      "horario": "HH:MM",
      "liga": "Nome da liga",
      "jogo": "Time A x Time B",
      "metodos_aplicados": ["back_favorito", "back_goleada"],
      "mercado_principal": "Nome do mercado do método principal (ex: 'Vitória Bayern')",
      "probabilidade_estimada": "65% (probabilidade do evento, estimada SÓ pelas estatísticas do PDF)",
      "fair_odd": "1.54 (= 1 ÷ probabilidade; a odd justa para esse evento)",
      "odd_minima_entrada": "1.70 (odd MÍNIMA que vale o risco; só entrar se a casa pagar igual ou acima disso)",
      "media_gols_casa": "1.8 (OPCIONAL — pode ser null. Média de gols marcados pelo MANDANTE por jogo. Usado para calcular placares prováveis. Se o PDF não tem este dado claramente, use null e SIGA com a análise normalmente. Não recuse aplicar métodos por causa desse campo.)",
      "media_gols_fora": "1.2 (OPCIONAL — pode ser null. Média de gols marcados pelo VISITANTE por jogo. Mesma regra acima.)",
      "explicacao_curta": "OBRIGATÓRIO em todos os métodos. 1-2 frases curtas (até 200 caracteres) explicando POR QUE essa entrada faz sentido. É o resumo que aparece no card principal do site, antes dos detalhes. Ex: 'Bayern em casa com 75% de aproveitamento contra Augsburg que sofre 2.1 gols/jogo. Favoritismo claro e momento ofensivo.'",
      "alerta_geral": "SÓ preenchido em entradas com Over Limite (+1 gol). Para essas, use o texto fixo: 'Evitar jogos empatados, com goleada já consolidada (3+ gols de diferença) ou após expulsão.' Para outros métodos, use null.",
      "valor_esperado": "Explicação curta do racional (ex: 'Prob. 65% → fair 1.54; com margem de segurança, só entrar acima de 1.70')",
      "mercado_secundario": "Nome do mercado secundário (de outro método aplicável)",
      "odd_minima_secundaria": "Odd mínima de entrada do mercado secundário",
      "desempenho_1t": "Casa marca 1.8 no 1ºT",
      "desempenho_2t": "Visitante sofre 1.4 no 2ºT",
      "contexto_times": {{
        "casa": {{
          "posicao": "3º (posição como MANDANTE/em casa, se estiver no PDF)",
          "objetivo": "titulo | libertadores | sul_americana | acesso | rebaixamento | meio_tabela | sem_objetivo | (vazio se não souber)"
        }},
        "fora": {{
          "posicao": "12º (posição como VISITANTE/fora, se estiver no PDF)",
          "objetivo": "rebaixamento | (vazio se não souber)"
        }}
      }},
      "motivacao_tecnica": "Texto detalhado explicando por que esse jogo é entrada de valor. Inclua estatísticas, contexto, retrospecto recente.",
      "coeficiente_regularidade": "Casa: CV baixo / Visitante: CV moderado",
      "mando_de_campo": "Casa faz X% dos pontos em casa OU descrição do desempenho padrão",
      "condicoes_campo": "Pitch, clima, fadiga. Se irrelevante: 'sem fatores relevantes'",
      "desfalques_chave": "Decision-makers ausentes. Se completo: 'elenco completo'",
      "especificidades_gols": "Como cada time marca",
      "momento_gols": "Janelas de gols",
      "jogadores_chave": "Principais decisores",
      "placares_provaveis": "Ex: 2x1, 3x1",
      "momento_entrada": "Pré-jogo, após 1º gol, etc.",
      "situacao_saida": "Quando fazer cash-out",
      "stake_recomendada": "2%",
      "plano_execucao": {{
        "abordagem": "propor ou forçar",
        "justificativa_abordagem": "Por que propor/forçar",
        "gatilho_saida_parcial": "Eventos que justificam reduzir exposição",
        "hard_stop": "Regra robótica de saída total"
      }},
      "back_favorito": {{
        "aplicavel": true,
        "criterios_atendidos": ["nome_curto_critério_1","nome_curto_critério_2"],
        "criterios_total": 4,
        "modo": "pre_jogo ou ao_vivo",
        "favorito": "Nome do favorito",
        "odd_alvo": "1.45",
        "razao": "Por que esse jogo é Back Favorito (ex: 'Favoritismo claro em casa contra time em má fase')",
        "gatilho_ao_vivo": "Se modo='ao_vivo': qual confirmação tática esperar (ex: 'após 15min se dominância clara')",
        "stake_recomendada": "2%"
      }},
      "lay_zebra": {{
        "aplicavel": true,
        "criterios_atendidos": ["nome_curto_critério_1","nome_curto_critério_2"],
        "criterios_total": 3,
        "modo": "pre_jogo ou ao_vivo",
        "zebra": "Nome do time MAIS FRACO (zebra) — aquele que vai pro Lay. NUNCA coloque o favorito aqui. Ex: jogo 'Flamengo x Palmeiras' onde Palmeiras é zebra → escreva 'Palmeiras' (Lay Palmeiras = Flamengo precisa vencer ou empatar).",
        "favorito_do_jogo": "Nome do time MAIS FORTE (favorito) — confirme que NÃO é igual ao campo 'zebra'. Serve pra auditar a coerência da sugestão.",
        "odd_zebra_alvo": "5.50",
        "razao": "Por que essa zebra é boa pra Lay (justificativa de por que ela vai perder ou empatar)",
        "gatilho_ao_vivo": "Se modo='ao_vivo': condição (ex: 'lay após zebra marcar primeiro')",
        "stake_recomendada": "2%"
      }},
      "over_limite_70": {{
        "aplicavel": true,
        "criterios_atendidos": ["nome_curto_critério_1","nome_curto_critério_2"],
        "criterios_total": 4,
        "modo": "ao_vivo",
        "favorito_ou_motivacao": "Nome do favorito + descrição curta da motivação (ex: 'Real Madrid - brigando pelo título contra Barcelona em má fase')",
        "indices_gols_faixas": "Valores exatos das 4 condições do PDF (ex: 'Favorito Marcado 61-75: 28% | 76-90: 32% | Adversário Sofrido 61-75: 18% | 76-90: 27%')",
        "qual_condicao_atende": "Indique qual(is) das 4 condições atende (a, b, c ou d) e o valor que ultrapassa 25%",
        "motivo_motivacao": "Por que há motivação ou desequilíbrio técnico (ex: 'Lazio 4º brigando por vaga na Champions vs Empoli 18º em queda livre')",
        "condicao_entrada": "Entrar AO VIVO após 65min, mercado = Mais X.5 gols onde X = placar total + 1 (ex: 1-0 vira Mais 1.5)",
        "mercado_sugerido": "Mais X.5 gols (calcular X conforme placar atual + 1)",
        "odd_esperada": "1.60 a 2.20",
        "stake_recomendada": "1%",
        "alerta_armadilha": "EVITAR se: jogo empatado (0x0), goleada (3+ gols de diferença), ou expulsão em campo"
      }},
      "back_2x2": {{
        "aplicavel": true,
        "criterios_atendidos": ["nome_curto_critério_1","nome_curto_critério_2"],
        "criterios_total": 3,
        "razao": "Por que esse jogo tem padrão de 2x2 (alto Over 2.5 + Ambas Marcam + Over HT, defesas frágeis dos dois lados)",
        "indice_over_2_5": "% de jogos com Over 2.5 nos últimos 10 (ex: '75% — Time A 80%, Time B 70%')",
        "indice_ambas_marcam": "% de jogos com Ambas Marcam (ex: '70% — Time A 75%, Time B 65%')",
        "indice_over_ht": "% de jogos com Over 0.5 HT (ex: '80% — Time A 85%, Time B 75%')",
        "modo": "pre_jogo",
        "odd_alvo": "12.00",
        "regra_saida": "Cash-out total ao chegar em 1x1; cash-out parcial em 2x1 ou 1x2. NUNCA segurar nesses placares.",
        "stake_recomendada": "0.5%"
      }},
      "back_goleada": {{
        "aplicavel": true,
        "criterios_atendidos": ["nome_curto_critério_1","nome_curto_critério_2"],
        "criterios_total": 3,
        "candidato": "Nome do time candidato a marcar 4+",
        "razao": "Por que tem cenário de goleada (favoritismo extremo + defesa frágil)",
        "modo": "pre_jogo ou ao_vivo",
        "mercado_sugerido": "Time marca 4+ e vence (ou similar)",
        "odd_esperada": "3.50 a 7.00",
        "stake_recomendada": "1%"
      }},
      "lay_1x0": {{
        "aplicavel": true,
        "criterios_atendidos": ["nome_curto_critério_1","nome_curto_critério_2"],
        "criterios_total": 5,
        "modo": "pre_jogo",
        "prob_1_0_estimada": "8% (sua estimativa baseada nos dados do PDF; precisa ser < 12% para aplicar)",
        "visitante_over_0_5": "70% (% de jogos em que o visitante marcou ao menos 1 gol; precisa ser > 65%)",
        "visitante_marca_pct": "65% (% de jogos em que visitante marca; precisa ser > 60%)",
        "media_gols_total": "2.8 (média de gols total entre os 2 times; precisa ser >= 2.5)",
        "btts_medio": "55% (BTTS médio entre os 2 times; precisa ser > 50%)",
        "razao": "Por que esse jogo NÃO termina em 1×0 (perfil de gols, visitante competitivo, etc.)",
        "odd_alvo": "10.50",
        "regra_saida": "Cash-out se 0-1, 1-1 ou após 60min sem gol",
        "stake_recomendada": "2%"
      }},
      "lay_0x1": {{
        "aplicavel": true,
        "criterios_atendidos": ["nome_curto_critério_1","nome_curto_critério_2"],
        "criterios_total": 5,
        "modo": "pre_jogo",
        "prob_0_1_estimada": "8% (sua estimativa baseada nos dados do PDF; precisa ser < 12% para aplicar)",
        "mandante_over_0_5": "70% (% de jogos em que o mandante marcou ao menos 1 gol; precisa ser > 65%)",
        "mandante_marca_pct": "65% (% de jogos em que mandante marca; precisa ser > 60%)",
        "media_gols_total": "2.8 (média de gols total entre os 2 times; precisa ser >= 2.5)",
        "btts_medio": "55% (BTTS médio entre os 2 times; precisa ser > 50%)",
        "razao": "Por que esse jogo NÃO termina em 0×1 (perfil de gols, mandante produtivo, etc.)",
        "odd_alvo": "11.00",
        "regra_saida": "Cash-out se 1-0, 1-1 ou após 60min sem gol",
        "stake_recomendada": "2%"
      }},
      "confirmacao_visual": {{
        "aplicavel": true,
        "perfil_tatico": "Perfil tático esperado",
        "gatilhos_aceleracao": "Encaixe defensivo, subida de linhas, velocidade de passes",
        "alerta_armadilha": "Sinais de armadilha",
        "mercado_recomendado": "Qual mercado dos 5 entrar quando confirmar",
        "momento_observacao": "Janela típica"
      }}
    }}
  ],
  "evitar": [
    {{
      "horario": "HH:MM",
      "jogo": "Time A x Time B",
      "liga": "Nome da liga",
      "motivo": "Resumo curto em 1 linha (ex: 'Sem favoritismo claro e dados de gols insuficientes')",
      "motivos_por_metodo": {{
        "back_favorito": "Por que NÃO se aplica (ex: 'prob estimada 52% — precisa ≥60%' ou 'jogo fora das ligas permitidas')",
        "lay_zebra": "Por que NÃO se aplica (ex: 'zebra com odd estimada 3.80 — precisa ≥5.00')",
        "over_limite_70": "Por que NÃO se aplica (ex: 'sem dados de gols por período no PDF')",
        "back_2x2": "Por que NÃO se aplica (ex: 'Over 2.5 média 48% — precisa ≥60%')",
        "back_goleada": "Por que NÃO se aplica (ex: 'favoritismo insuficiente — prob 58%, precisa ≥70%')",
        "lay_1x0": "Por que NÃO se aplica (ex: 'P(1-0) estimada 18% — precisa <12%')",
        "lay_0x1": "Por que NÃO se aplica (ex: 'mandante marca em 50% — precisa >60%')"
      }}
    }}
  ]
}}

REGRAS CRÍTICAS:
1. APENAS o JSON. Sem ```json, sem texto antes ou depois. Gere UM ÚNICO objeto
   JSON e PARE imediatamente após o "}}" final. NÃO repita o JSON, NÃO gere um
   segundo objeto, NÃO adicione comentários ou explicações após o fechamento.
   O JSON DEVE começar com "{{" e ter as chaves "entradas" e "evitar" no nível
   raiz. NUNCA retorne um array no nível raiz (não comece com "["). Mesmo se
   houver só 1 jogo, o formato é sempre {{ "entradas": [...], "evitar": [...] }}.
2. Use APENAS os 7 métodos listados. NUNCA invente mercados fora dessa lista.
3. "metodos_aplicados" é OBRIGATÓRIO — liste TODOS os métodos que se encaixam,
   não apenas o "melhor". Se 3 métodos atendem aos critérios, liste os 3.
   Valores válidos: "back_favorito", "lay_zebra", "over_limite_70", "back_2x2", "back_goleada", "lay_1x0", "lay_0x1".
   IMPORTANTE — coexistência: vários métodos podem se aplicar à MESMA partida.
   Exemplos comuns:
   - Jogo de favoritismo extremo: Back Favorito + Back Goleada + (talvez Lay 1×0)
   - Jogo equilibrado com muitos gols: Back 2x2 + Lay 1×0 + Lay 0×1
   - Zebra ruim com favorito mediano: Back Favorito + Lay Zebra
   Pense em CADA método independentemente. Se atende os critérios, INCLUA.
   NÃO seja conservador — listar mais métodos NÃO é "chutar", é refletir a
   realidade do jogo. O site mostrará o principal + 2 secundários no card.
4. Para CADA método na lista "metodos_aplicados", você DEVE preencher o
   objeto correspondente com "aplicavel": true e TODOS os campos do objeto
   (incluindo criterios_atendidos e criterios_total). Para métodos que NÃO
   estão em metodos_aplicados, use null no objeto (sem detalhar).
5. "mercado_principal" deve refletir o método MAIS forte aplicável (o de maior confiança).
6. "confirmacao_visual" é opcional — preencha quando houver leitura tática clara,
   senão use null.
7. Todos os valores são strings (mesmo odds: "1.85", não 1.85).
8. Cada partida vai para "entradas" OU "evitar", nunca em ambos.
9. Em TODAS as entradas (independente do método), o campo "explicacao_curta"
   é OBRIGATÓRIO. NÃO deixe vazio NEM null:
   - "explicacao_curta": 1-2 frases curtas (máx ~200 caracteres) explicando
     POR QUE essa entrada faz sentido. Específica do jogo. É o resumo que
     aparece no card principal antes dos detalhes.
10. O campo "alerta_geral" SÓ é preenchido em entradas que tenham
    "over_limite_70" em metodos_aplicados. Para essas, use o texto FIXO literal:
    "Evitar jogos empatados, com goleada já consolidada (3+ gols de diferença)
    ou após expulsão." Para entradas SEM Over Limite, deixe "alerta_geral" como null.

---

DADOS DO LOTE:

{conteudo}
"""


def _extrair_json(texto: str) -> dict:
    """Extrai JSON da resposta do Gemini, mesmo se vier com texto extra,
    ```json, ou MAIS DE UM objeto JSON colado (pega o primeiro válido)."""
    import json
    import re

    if not texto:
        print("     ⚠ Gemini retornou texto VAZIO")
        return {"entradas": [], "evitar": []}

    # Remove blocos ```json``` ou ``` se existirem
    texto = re.sub(r"^```(?:json)?\s*", "", texto.strip(), flags=re.IGNORECASE)
    texto = re.sub(r"\s*```\s*$", "", texto.strip())

    inicio = texto.find("{")
    if inicio == -1:
        print(f"     ⚠ Resposta do Gemini sem JSON. Primeiros 300 chars: {texto[:300]!r}")
        return {"entradas": [], "evitar": []}

    # ESTRATÉGIA 1: raw_decode extrai o PRIMEIRO objeto JSON válido,
    # ignorando qualquer "Extra data" que venha depois (lixo, JSON duplicado, etc.)
    decoder = json.JSONDecoder()
    try:
        obj, _idx = decoder.raw_decode(texto[inicio:])
        if isinstance(obj, dict) and ("entradas" in obj or "evitar" in obj):
            return obj
    except json.JSONDecodeError:
        pass

    # ESTRATÉGIA 1.5: o Gemini às vezes retorna um ARRAY raiz com objetos
    # de entrada/evitar misturados em vez do schema {entradas:[], evitar:[]}.
    # Detecta isso e converte pro formato correto.
    inicio_array = texto.find("[")
    if inicio_array != -1 and (inicio == -1 or inicio_array < inicio or inicio_array < texto.find("{")):
        # Array começa antes do primeiro objeto isolado → é array raiz
        try:
            arr, _ = decoder.raw_decode(texto[inicio_array:])
            if isinstance(arr, list):
                entradas, evitar = [], []
                for item in arr:
                    if not isinstance(item, dict):
                        continue
                    # Heurística: tem "motivos_por_metodo" ou "motivo" mas SEM
                    # método aplicável real → é "evitar"; senão é "entrada"
                    tem_metodo_aplicavel = bool(item.get("metodos_aplicados"))
                    if tem_metodo_aplicavel:
                        entradas.append(item)
                    else:
                        evitar.append(item)
                print(f"     ⚠ Gemini retornou ARRAY raiz; convertido p/ schema esperado "
                      f"({len(entradas)} entradas, {len(evitar)} evitar).")
                return {"entradas": entradas, "evitar": evitar}
        except json.JSONDecodeError:
            pass

    # Também trata o caso de `raw_decode` ter extraído um objeto SEM "entradas"/"evitar"
    # (ou seja, retornou o PRIMEIRO objeto do array, achando que era o JSON principal)
    # Aqui tentamos parsear como array envolvendo o trecho extraído.
    try:
        # tenta extrair como array procurando o primeiro [
        if inicio_array != -1:
            arr_str = texto[inicio_array:]
            # acha o ] correspondente
            arr, _ = decoder.raw_decode(arr_str)
            if isinstance(arr, list) and arr:
                entradas, evitar = [], []
                for item in arr:
                    if not isinstance(item, dict):
                        continue
                    if item.get("metodos_aplicados"):
                        entradas.append(item)
                    else:
                        evitar.append(item)
                if entradas or evitar:
                    print(f"     ⚠ Recuperado array raiz: {len(entradas)} entradas, {len(evitar)} evitar.")
                    return {"entradas": entradas, "evitar": evitar}
    except Exception:
        pass

    # ESTRATÉGIA 2: pega do primeiro { ao último } e tenta parsear
    fim = texto.rfind("}")
    candidato = texto[inicio:fim + 1] if fim > inicio else texto[inicio:]
    try:
        return json.loads(candidato)
    except json.JSONDecodeError as e:
        # ESTRATÉGIA 3: limpa quebras de linha problemáticas dentro de strings
        try:
            limpo = re.sub(r'(?<!\\)\n', ' ', candidato)
            return json.loads(limpo)
        except Exception:
            pass

        # ESTRATÉGIA 4: tenta reparar JSON truncado fechando chaves/colchetes abertos
        try:
            reparado = _reparar_json_truncado(candidato)
            if reparado:
                resultado = json.loads(reparado)
                print(f"     ⚠ JSON estava truncado/quebrado, mas foi REPARADO parcialmente.")
                return resultado
        except Exception:
            pass

        # Falhou em tudo: loga e salva
        print(f"     ⚠ JSON inválido do Gemini. Erro: {e}")
        print(f"     ⚠ Primeiros 500 chars: {candidato[:500]!r}")
        print(f"     ⚠ Últimos 200 chars: {candidato[-200:]!r}")
        try:
            debug_path = DEBUG_DIR / f"gemini_resposta_quebrada_{datetime.now().strftime('%H%M%S')}.txt"
            DEBUG_DIR.mkdir(exist_ok=True)
            debug_path.write_text(texto, encoding="utf-8")
            print(f"     ⚠ Resposta completa salva em: {debug_path}")
        except Exception:
            pass
        return {"entradas": [], "evitar": []}


def _reparar_json_truncado(s: str) -> str:
    """Tenta reparar um JSON cortado no meio, fechando strings/colchetes/chaves
    que ficaram abertos. Última linha de defesa pra não perder o lote inteiro."""
    import json
    # Remove vírgula final solta antes de tentar fechar
    s = s.rstrip()
    # Conta aberturas vs fechamentos fora de strings
    em_string = False
    escapou = False
    pilha = []
    ultimo_valido = 0
    for i, ch in enumerate(s):
        if escapou:
            escapou = False
            continue
        if ch == "\\":
            escapou = True
            continue
        if ch == '"':
            em_string = not em_string
            continue
        if em_string:
            continue
        if ch in "{[":
            pilha.append(ch)
        elif ch in "}]":
            if pilha:
                pilha.pop()
            if not pilha:
                ultimo_valido = i + 1
    # Se há um ponto onde tudo fechou, usa até ali
    if ultimo_valido > 0:
        try:
            json.loads(s[:ultimo_valido])
            return s[:ultimo_valido]
        except Exception:
            pass
    # Senão, fecha o que ficou aberto
    fechamento = ""
    if em_string:
        fechamento += '"'
    for ch in reversed(pilha):
        fechamento += "}" if ch == "{" else "]"
    return s + fechamento


def chamar_gemini(client, modelo: str, prompt: str, max_tentativas: int = 5) -> str:
    """Chama o Gemini com retry em caso de rate limit ou sobrecarga do serviço."""
    # Config MÁXIMA determinística: temperatura ZERO = sempre a resposta mais
    # provável, sem criatividade. Mesmo input → mesmo output (o mais fiel possível).
    gen_config = genai_types.GenerateContentConfig(
        temperature=0,     # zero = totalmente determinístico, sem "criatividade"
        top_p=0,           # zero = só considera o token mais provável (greedy)
        top_k=1,           # 1 = escolhe sempre o melhor token (sem amostragem)
        seed=42,           # seed fixo = reforça a reprodutibilidade
        candidate_count=1,
        # IMPORTANTE: aumentamos pra 32k pra acomodar relatórios com vários
        # jogos detalhados (cada jogo tem ~1.5k tokens com 7 métodos + campos).
        # Default é 8192, que TRUNCA respostas de lotes >= 5 jogos.
        max_output_tokens=32768,
    )
    for tentativa in range(max_tentativas):
        try:
            resp = client.models.generate_content(
                model=modelo, contents=prompt, config=gen_config
            )
            return resp.text or ""
        except Exception as e:
            msg = str(e).lower()
            # Erro de cota / rate limit
            if "quota" in msg or "rate" in msg or "429" in msg or "resource_exhausted" in msg:
                espera = 35 * (tentativa + 1)
                print(f"     ⏳ Limite de cota. Aguardando {espera}s...")
                time.sleep(espera)
                continue
            # Erro de sobrecarga do Google (503) — esperar e tentar de novo
            if "503" in msg or "unavailable" in msg or "high demand" in msg or "overloaded" in msg:
                espera = 20 * (tentativa + 1)
                print(f"     ⏳ Gemini sobrecarregado. Aguardando {espera}s...")
                time.sleep(espera)
                continue
            # Erro de servidor (500/502/504)
            if "500" in msg or "502" in msg or "504" in msg or "internal" in msg:
                espera = 15 * (tentativa + 1)
                print(f"     ⏳ Erro temporário do Gemini. Aguardando {espera}s...")
                time.sleep(espera)
                continue
            # Outros erros: propaga
            raise
    raise RuntimeError(f"Falhou após {max_tentativas} tentativas. Tente trocar 'modelo' no config.json para 'gemini-2.5-flash-lite' ou 'gemini-2.0-flash'.")


def _norm_liga(s):
    """Normaliza nome de liga: minúsculas, sem acento, espaços colapsados."""
    import unicodedata
    s = (s or "").lower()
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = " ".join(s.split())
    return s.strip()


def aplicar_trava_ligas(entradas: list, ligas_diretos: list) -> tuple:
    """TRAVA DE SEGURANÇA (pós-processamento): remove Back Favorito e Lay Zebra
    de entradas cuja liga NÃO está na lista de ligas permitidas, mesmo que o
    Gemini tenha sugerido. Não confia só na obediência do modelo.

    Retorna (entradas_corrigidas, n_remocoes).
    Se uma entrada ficar SEM nenhum método após a remoção, ela é descartada
    (vira candidata a 'evitar', mas aqui só removemos da lista de entradas).
    """
    if not ligas_diretos:
        return entradas, 0  # sem lista = sem restrição

    ligas_norm = [_norm_liga(x) for x in ligas_diretos if x]
    METODOS_RESTRITOS = ["back_favorito", "lay_zebra"]
    n_remocoes = 0
    saida = []

    for e in entradas:
        liga_norm = _norm_liga(e.get("liga", ""))
        # A liga está permitida pra métodos diretos?
        permitida = any(termo in liga_norm or liga_norm in termo for termo in ligas_norm)

        if not permitida:
            # Remove os métodos restritos desta entrada
            metodos = e.get("metodos_aplicados", []) or []
            metodos_limpos = [m for m in metodos if m not in METODOS_RESTRITOS]

            if len(metodos_limpos) != len(metodos):
                removidos = [m for m in metodos if m in METODOS_RESTRITOS]
                n_remocoes += len(removidos)
                print(f"     🔒 Trava de liga: removido {removidos} de '{e.get('jogo','?')}' "
                      f"(liga '{e.get('liga','?')}' fora da lista)")
                e["metodos_aplicados"] = metodos_limpos
                # Zera os objetos dos métodos removidos
                for m in removidos:
                    e[m] = None
                # Recalcula o mercado_principal se ele era de um método removido
                if metodos_limpos:
                    # mantém — o primeiro método restante vira referência
                    pass
                else:
                    # Sem método nenhum: marca pra descarte
                    e["_descartar"] = True

        if not e.get("_descartar"):
            saida.append(e)
        else:
            print(f"     🔒 '{e.get('jogo','?')}' descartada (só tinha métodos restritos "
                  f"e a liga não é permitida)")

    return saida, n_remocoes


def analisar_em_lotes(client, modelo: str, blocos: list, tamanho_lote: int = 10, ligas_diretos_txt: str = "", ligas_diretos_lista: list = None) -> dict:
    """Divide em lotes, analisa cada um e retorna um dict {entradas: [...], evitar: [...]}."""
    total_lotes = (len(blocos) + tamanho_lote - 1) // tamanho_lote
    print(f"→ Dividindo em {total_lotes} lote(s) de até {tamanho_lote} partidas")

    todas_entradas = []
    todos_evitar = []

    for i in range(0, len(blocos), tamanho_lote):
        lote = blocos[i:i + tamanho_lote]
        num_lote = i // tamanho_lote + 1
        print(f"\n  [Lote {num_lote}/{total_lotes}] Analisando {len(lote)} partidas...")

        conteudo_lote = "\n".join(lote)
        prompt = PROMPT_LOTE.format(conteudo=conteudo_lote[:400000], ligas_metodos_diretos=ligas_diretos_txt)
        try:
            resultado_texto = chamar_gemini(client, modelo, prompt)
            resultado = _extrair_json(resultado_texto)
            n_ent = len(resultado.get("entradas", []))
            n_ev = len(resultado.get("evitar", []))
            todas_entradas.extend(resultado.get("entradas", []))
            todos_evitar.extend(resultado.get("evitar", []))
            print(f"     ✓ lote {num_lote}: {n_ent} entrada(s), {n_ev} evitar")
        except Exception as e:
            print(f"     ✗ erro no lote {num_lote}: {e}")

        if num_lote < total_lotes:
            print(f"     ⏸  Aguardando 8s antes do próximo lote...")
            time.sleep(8)

    # Ordena por horário
    def horario_key(item):
        h = item.get("horario", "99:99")
        try:
            return tuple(int(x) for x in h.split(":"))
        except Exception:
            return (99, 99)

    todas_entradas.sort(key=horario_key)
    todos_evitar.sort(key=horario_key)

    # TRAVA DE SEGURANÇA: remove Back Favorito/Lay Zebra de ligas fora da lista
    # (não confia só na obediência do Gemini ao prompt)
    if ligas_diretos_lista:
        todas_entradas, n_rem = aplicar_trava_ligas(todas_entradas, ligas_diretos_lista)
        if n_rem > 0:
            print(f"  🔒 Trava de ligas: {n_rem} método(s) restrito(s) removido(s) de ligas não permitidas")

    return {"entradas": todas_entradas, "evitar": todos_evitar}


# ============================================================
# Fluxo principal
# ============================================================
async def fluxo_principal(config, dia: str = "hoje", data_referencia: str = None):
    DEBUG_DIR.mkdir(exist_ok=True)
    PDF_DIR.mkdir(exist_ok=True)
    if not data_referencia:
        data_referencia = datetime.now().strftime("%Y-%m-%d")
    pasta_dia = PDF_DIR / data_referencia
    pasta_dia.mkdir(exist_ok=True)

    async with async_playwright() as p:
        # ============================================================
        # PERFIL PERSISTENTE — necessário pra bypassar anti-bot do site
        # ============================================================
        # O site usa proteção tipo "Aguarde enquanto verificamos...".
        # Com perfil persistente (cookies + impressão digital salva), o site
        # te reconhece como humano e libera o acesso sem captcha.
        #
        # NA PRIMEIRA EXECUÇÃO:
        #   - Abre o Chrome
        #   - Aguarda a verificação anti-bot terminar (10-20s)
        #   - Você faz login MANUALMENTE (clique no botão "YouTube membro"
        #     ou preenche email/senha como preferir)
        #   - O script detecta que está logado e segue
        #   - Os cookies ficam salvos em ./browser_profile/
        #
        # PRÓXIMAS EXECUÇÕES:
        #   - Abre o Chrome com os cookies já salvos
        #   - Anti-bot reconhece e libera direto
        #   - Login automático (sessão ainda válida)
        # ============================================================
        perfil_dir = BASE_DIR / "browser_profile"
        perfil_dir.mkdir(exist_ok=True)

        # User-agent realista (mesmo do Chrome desktop padrão)
        user_agent = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/130.0.0.0 Safari/537.36"
        )

        context = await p.chromium.launch_persistent_context(
            str(perfil_dir),
            headless=False,  # Forçado False — anti-bot detecta headless
            user_agent=user_agent,
            viewport={"width": 1366, "height": 768},
            locale="pt-BR",
            timezone_id="America/Sao_Paulo",
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-features=site-per-process",
                "--no-sandbox",
            ],
        )
        browser = context.browser  # pra usar no fim
        page = context.pages[0] if context.pages else await context.new_page()

        # Login (faz manual na primeira vez, depois é automático)
        await fazer_login(page, config)

        # Coleta partidas
        partidas = await coletar_partidas(page, dia=dia, config=config)
        # NÃO fechar a página principal — se for a única, o contexto inteiro fecha
        # e perdemos a sessão. Só fechamos no final.

        if not partidas:
            print("⚠ Nenhuma partida encontrada na lista do dia.")
            await context.close()
            return [], []

        # Gera PDF de cada partida (sequencial pra não sobrecarregar o site)
        # Pausas adaptativas: 3s entre PDFs + pausa maior a cada 5 (anti rate limit)
        token_fb = (config.get("token_fallback") or "").strip()
        print(f"\n→ Gerando PDFs ({len(partidas)} partidas)...")
        pdfs_gerados = []
        for i, partida in enumerate(partidas, 1):
            try:
                print(f"  [{i}/{len(partidas)}] {partida['nome'][:60]}")
                caminho = await gerar_pdf_partida(context, partida, pasta_dia, i, token_fallback=token_fb, config=config)
                pdfs_gerados.append((partida, caminho))
            except Exception as e:
                print(f"     ✗ erro: {e}")
            # Respiro entre partidas (anti rate limit do clube)
            # A cada 5 PDFs, pausa maior pra deixar o servidor respirar
            if i % 5 == 0 and i < len(partidas):
                print(f"     ⏸  pausa anti rate limit (15s)...")
                await asyncio.sleep(15)
            else:
                await asyncio.sleep(3)

        await context.close()
        return partidas, pdfs_gerados


def main():
    config = load_config()

    # Parse de argumentos da linha de comando: python main.py [hoje|amanha]
    dia = "hoje"
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower().strip()
        if arg in ("hoje", "amanha", "amanhã"):
            dia = "amanha" if arg in ("amanha", "amanhã") else "hoje"
        else:
            print(f"⚠ Argumento desconhecido: '{sys.argv[1]}'. Usando 'hoje'.")

    # Data de referência para pasta/arquivo (hoje real ou amanhã real)
    if dia == "amanha":
        from datetime import timedelta
        data_ref = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        print(f"📅 Modo: AMANHÃ ({data_ref})\n")
    else:
        data_ref = datetime.now().strftime("%Y-%m-%d")
        print(f"📅 Modo: HOJE ({data_ref})\n")

    print("=" * 60)
    print("ETAPA 1+2: Login, coleta e geração de PDFs")
    print("=" * 60)
    partidas, pdfs_gerados = asyncio.run(
        fluxo_principal(config, dia=dia, data_referencia=data_ref)
    )

    if not pdfs_gerados:
        print("\nNenhum PDF gerado. Encerrando.")
        return

    print(f"\n✓ {len(pdfs_gerados)} PDF(s) gerado(s)")

    print("\n" + "=" * 60)
    print("ETAPA 3: Análise consolidada com Gemini")
    print("=" * 60)

    # Junta texto de todos os PDFs num blob só pra análise consolidada
    print("→ Extraindo texto dos PDFs...")
    blocos = []
    for partida, caminho in pdfs_gerados:
        texto = extrair_texto_pdf(caminho)
        if not texto.strip():
            print(f"  ⚠ sem texto: {caminho.name}")
            continue
        cabecalho = f"\n\n========================================\n"
        cabecalho += f"PARTIDA: {partida['nome']}\n"
        if partida.get("liga"):
            cabecalho += f"LIGA: {partida['liga']}\n"
        if partida.get("horario"):
            cabecalho += f"HORÁRIO: {partida['horario']}\n"
        cabecalho += f"========================================\n\n"
        blocos.append(cabecalho + texto)

    if not blocos:
        print("✗ Nenhum PDF teve texto extraível. Encerrando.")
        return

    conteudo_total = "\n".join(blocos)
    print(f"→ {len(blocos)} partidas com texto extraído ({len(conteudo_total):,} caracteres)")

    print("→ Enviando para o Gemini (análise em lotes)...")
    client = genai.Client(api_key=config["gemini_api_key"])
    modelo = config.get("modelo", "gemini-2.0-flash")
    tamanho_lote = config.get("tamanho_lote", 10)

    # Monta a lista de ligas permitidas para Back Favorito / Lay Zebra
    ligas_diretos = config.get("ligas_metodos_diretos", [])
    if ligas_diretos:
        ligas_diretos_txt = "\n".join(f"- {liga}" for liga in ligas_diretos)
    else:
        # Sem lista definida: permite em todas (não restringe)
        ligas_diretos_txt = "(qualquer liga — sem restrição definida)"

    try:
        analise = analisar_em_lotes(client, modelo, blocos, tamanho_lote, ligas_diretos_txt, ligas_diretos)
    except Exception as e:
        print(f"✗ Erro no Gemini: {e}")
        if enviar_erro:
            enviar_erro(config, "Falha na análise do Gemini", str(e))
        return

    OUTPUT_DIR.mkdir(exist_ok=True)
    relatorio = OUTPUT_DIR / f"relatorio_{data_ref}.json"

    import json as _json
    dados_relatorio = {
        "data": data_ref,
        "dia_consultado": dia,
        "gerado_em": datetime.now().isoformat(),
        "total_partidas_analisadas": len(pdfs_gerados),
        "entradas": analise.get("entradas", []),
        "evitar": analise.get("evitar", []),
        "pdfs": [
            {"jogo": p["nome"], "arquivo": c.relative_to(BASE_DIR).as_posix()}
            for p, c in pdfs_gerados
        ],
    }
    with open(relatorio, "w", encoding="utf-8") as f:
        _json.dump(dados_relatorio, f, ensure_ascii=False, indent=2)

    print(f"\n✓ Relatório salvo em: {relatorio}")
    print(f"  • {len(dados_relatorio['entradas'])} entradas com valor")
    print(f"  • {len(dados_relatorio['evitar'])} jogos a evitar")
    print(f"✓ PDFs em: {PDF_DIR / data_ref}")

    # Publicação automática no site (se configurado)
    try:
        from publicar import publicar
        publicar(config, relatorio)
    except ImportError:
        pass  # publicar.py não está disponível, ignora silenciosamente
    except Exception as e:
        print(f"⚠ Falha na publicação automática: {e}")
        if enviar_erro:
            enviar_erro(config, "Falha na publicação no GitHub", str(e))

    # Notificação Telegram: relatório pronto
    if enviar_relatorio_pronto:
        # Conta métodos aplicados
        metodos_count = {
            "back_favorito": 0, "lay_zebra": 0, "over_limite_70": 0,
            "back_2x2": 0, "back_goleada": 0,
            "lay_1x0": 0, "lay_0x1": 0,
            "confirmacao_visual": 0,
        }
        for entrada in dados_relatorio["entradas"]:
            for m_key in metodos_count:
                obj = entrada.get(m_key)
                if obj and (obj.get("aplicavel") or obj.get("elegivel")):
                    metodos_count[m_key] += 1

        url_site = config.get(
            "site_publico_url",
            "https://analisefb.pages.dev"
        )
        try:
            enviar_relatorio_pronto(
                config,
                data=data_ref,
                total_entradas=len(dados_relatorio["entradas"]),
                total_evitar=len(dados_relatorio["evitar"]),
                metodos_count=metodos_count,
                url_site=url_site,
            )
        except Exception as e:
            print(f"⚠ Falha na notificação Telegram: {e}")


if __name__ == "__main__":
    main()
