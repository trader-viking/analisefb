"""
Análise de Jogadores — Radar de Jogadores
Loga em radardejogadores.com.br, abre cada jogo, baixa o PDF de estatísticas
de jogadores, analisa com Gemini, e publica relatório consolidado no formato
de planilha (lista única de jogador + método + mercado + odd mínima).

Reutiliza utilidades do main.py original (parser robusto, helpers, etc.).
"""
import json
import re
import sys
import time
import asyncio
from pathlib import Path
from datetime import datetime, timedelta

import pdfplumber
from playwright.async_api import async_playwright

# Reutiliza funções comuns do main.py
from main import (
    load_config,
    slug,
    extrair_texto_pdf,
    _extrair_json,
    chamar_gemini,
)

try:
    from telegram_helper import enviar_relatorio_pronto, enviar_erro
except ImportError:
    enviar_relatorio_pronto = None
    enviar_erro = None

from google import genai

BASE_DIR = Path(__file__).parent
PDF_DIR = BASE_DIR / "pdfs_jogadores"
OUTPUT_DIR = BASE_DIR / "relatorios_jogadores"
DEBUG_DIR = BASE_DIR / "debug"

# URLs do radardejogadores.com.br (preencha conforme o site real)
RADAR_LOGIN_URL = "https://radardejogadores.com.br/login"
RADAR_AREA_URL = "https://radardejogadores.com.br/member"

# Seletores prováveis (ajuste conforme o HTML real do site)
SELETORES_EMAIL_ALT = [
    "#email", "input[name='email']", "input[type='email']",
    "input[placeholder*='mail' i]",
]
SELETORES_SENHA_ALT = [
    "#password", "input[name='password']", "input[type='password']",
]


# ============================================================
# Login no radardejogadores.com.br
# ============================================================
async def fazer_login_radar(page, config):
    """Login no Radar de Jogadores. Usa credenciais radar_usuario/radar_senha do config."""
    print(f"→ Acessando {RADAR_LOGIN_URL}")
    await page.goto(RADAR_LOGIN_URL)
    await page.wait_for_load_state("networkidle", timeout=15000)
    await page.wait_for_timeout(2000)

    # Já logado?
    if "/member" in page.url or "/area" in page.url or "/dashboard" in page.url:
        print(f"✓ Já estava logado ({page.url})")
        return

    # Tenta os campos de email
    sel_email_usado = None
    for sel in SELETORES_EMAIL_ALT:
        try:
            await page.wait_for_selector(sel, timeout=3000)
            sel_email_usado = sel
            break
        except Exception:
            continue

    if not sel_email_usado:
        # Login manual de fallback
        print("")
        print("=" * 60)
        print("⚠ FORMULÁRIO DE LOGIN NÃO APARECEU AUTOMATICAMENTE (RADAR)")
        print("=" * 60)
        print("👉 NA JANELA DO CHROME QUE ABRIU:")
        print("   Faça login MANUALMENTE no radardejogadores.com.br")
        print("   Os cookies ficam salvos em browser_profile/")
        print("Aguardando você logar... (timeout: 5 minutos)")
        for i in range(300):
            await page.wait_for_timeout(1000)
            if "/member" in page.url or "/area" in page.url:
                print(f"✓ Login manual detectado! URL: {page.url}")
                return
        raise RuntimeError(f"Timeout aguardando login no radar. URL: {page.url}")

    # Senha
    sel_senha_usado = None
    for sel in SELETORES_SENHA_ALT:
        try:
            elem = await page.query_selector(sel)
            if elem:
                sel_senha_usado = sel
                break
        except Exception:
            continue
    if not sel_senha_usado:
        raise RuntimeError("Campo de senha não encontrado no radar.")

    usuario = (config.get("radar_usuario") or config.get("usuario") or "").strip()
    senha = (config.get("radar_senha") or config.get("senha") or "").strip()
    if not usuario or not senha:
        raise RuntimeError(
            "Credenciais 'radar_usuario'/'radar_senha' (ou 'usuario'/'senha') "
            "vazias no config.json"
        )

    print(f"→ Preenchendo credenciais radar")
    await page.fill(sel_email_usado, usuario)
    await page.fill(sel_senha_usado, senha)

    # Submit
    try:
        async with page.expect_navigation(timeout=20000, wait_until="networkidle"):
            btn = await page.query_selector("button[type='submit']")
            if btn:
                await btn.click()
            else:
                await page.press(sel_senha_usado, "Enter")
    except Exception:
        await page.wait_for_load_state("networkidle", timeout=10000)

    if "/login" in page.url:
        raise RuntimeError(f"Login no radar falhou. URL: {page.url}")
    print(f"✓ Login OK no radar ({page.url})")


# ============================================================
# Coletar partidas do radar
# ============================================================
async def coletar_partidas_radar(page, dia: str = "hoje"):
    """Vai pra área de membros do radar e retorna lista de partidas com link p/ PDF."""
    print(f"→ Indo para área do radar")
    await page.goto(RADAR_AREA_URL)
    await page.wait_for_load_state("networkidle")
    await page.wait_for_timeout(3000)

    # IMPORTANTE: o seletor abaixo é uma TENTATIVA inicial. Pode precisar
    # ajustar quando você rodar pela primeira vez e me mandar print do HTML.
    # A ideia: pegar todos os links pra páginas de jogos.
    partidas = await page.evaluate("""
        () => {
            const out = [];
            // Tenta vários seletores comuns
            const candidatos = [
                ...document.querySelectorAll('a[href*="/jogo/"]'),
                ...document.querySelectorAll('a[href*="/partida/"]'),
                ...document.querySelectorAll('a[href*="/match/"]'),
                ...document.querySelectorAll('.jogo a, .partida a, .match a'),
            ];
            const vistos = new Set();
            for (const a of candidatos) {
                if (vistos.has(a.href)) continue;
                vistos.add(a.href);
                const texto = (a.textContent || '').trim().replace(/\\s+/g, ' ');
                out.push({
                    url: a.href,
                    nome: texto.slice(0, 200),
                });
            }
            return out;
        }
    """)

    if not partidas:
        # Fallback: pega TODOS os links da página pro usuário ver o que tem
        print("⚠ Nenhuma partida encontrada com seletores padrão.")
        print("→ Listando links presentes na página (debug):")
        links_debug = await page.evaluate(
            "() => Array.from(document.querySelectorAll('a')).map(a => ({url: a.href, txt: (a.textContent||'').trim().slice(0,80)})).filter(l => l.url && !l.url.includes('javascript:'))"
        )
        for l in links_debug[:30]:
            print(f"     • {l['url']} — '{l['txt']}'")
        return []

    print(f"→ {len(partidas)} partida(s) encontrada(s) no radar")
    return partidas


# ============================================================
# Gerar PDF de cada partida do radar
# ============================================================
async def gerar_pdf_partida_radar(context, partida, pasta_dia, indice):
    """Abre a página da partida no radar e salva como PDF."""
    page = await context.new_page()
    try:
        await page.goto(partida["url"], wait_until="networkidle", timeout=60000)
        await page.wait_for_timeout(2000)

        # Se caiu na tela de login, sessão expirou
        if "/login" in page.url:
            raise RuntimeError("sessão do radar expirou — relogar manualmente")

        nome_arq = f"{indice:03d}_{slug(partida['nome'], 60)}.pdf"
        caminho = pasta_dia / nome_arq
        await page.pdf(
            path=str(caminho),
            format="A4",
            print_background=True,
            margin={"top": "10mm", "right": "10mm", "bottom": "10mm", "left": "10mm"},
        )
        return caminho
    finally:
        await page.close()


# ============================================================
# PROMPT da análise de jogadores
# ============================================================
PROMPT_JOGADORES = """Você é um analista esportivo profissional, especialista em mercados de
jogadores individuais (player props).

Analise o PDF do "Radar de Jogadores" abaixo e retorne APENAS um JSON válido,
sem texto antes ou depois, sem markdown, sem ```json. APENAS o JSON cru.

=====================================================================
PRINCÍPIO FUNDAMENTAL: FIDELIDADE AOS DADOS
=====================================================================
- Use EXCLUSIVAMENTE os dados do PDF. NUNCA invente estatísticas, médias,
  posições ou retrospectos.
- Se um dado não está no PDF, deixe o campo vazio ou não aplique o método.
- A coluna "X.X/90 min." é a média NORMALIZADA pra 90 minutos — é o número
  que importa pra projetar performance no próximo jogo.
- A coluna "minutos" mostra o total jogado nas últimas partidas analisadas.

=====================================================================
FILTRO DE AMOSTRA MÍNIMA (OBRIGATÓRIO)
=====================================================================
SÓ considere um jogador como candidato a entrada se ele tem:
- Pelo menos 180 minutos jogados (2 jogos completos como referência mínima)
Jogadores com menos minutos = amostra insuficiente. Ignore-os.

=====================================================================
OS 6 MÉTODOS DE ANÁLISE DE JOGADOR
=====================================================================

1. MARCA GOL ("marca_gol")
   - Apostar que o jogador marca a qualquer momento.
   - CRITÉRIO: Chutes no Alvo /90min >= 1.5 (jogador finaliza muito).
   - Bônus: adversário com defesa frágil (sofre 2.0+ gols/jogo) ou jogador
     em ótima fase recente reforça a entrada.
   - Mercado típico: "Anytime Goalscorer" / "Marca a qualquer momento"

2. CARTÃO AMARELO ("cartao_amarelo")
   - Apostar que o jogador leva cartão.
   - CRITÉRIO (AMBOS): Cartões Amarelos /90min >= 0.4 E Faltas Cometidas /90min >= 2.0.
   - Bônus: jogador disciplinar (volantes, zagueiros) em jogo importante/clássico.
   - Mercado típico: "Jogador leva cartão"

3. CHUTES — OVER ("chutes")
   - Apostar Over X.5 chutes do jogador.
   - CRITÉRIO: Chutes /90min >= 2.0.
   - Calcule X = floor(Chutes /90min). Se /90min = 2.8, sugira "Over 1.5 chutes".
     Se /90min = 3.5+, sugira "Over 2.5 chutes".
   - Mercado típico: "Over X.5 chutes do jogador"

4. DESARMES — OVER ("desarmes")
   - Apostar Over X.5 desarmes (roubos de bola) do jogador.
   - CRITÉRIO: Roubos de Bola /90min >= 2.0.
   - Calcule X igual ao método anterior (floor da média - 1 pra ser conservador).
   - Mercado típico: "Over X.5 desarmes"

5. FALTAS COMETIDAS — OVER ("faltas_cometidas")
   - Apostar Over X.5 faltas cometidas pelo jogador.
   - CRITÉRIO: Faltas Cometidas /90min >= 2.0.
   - Calcule X de forma análoga aos métodos acima.

6. FALTAS SOFRIDAS — OVER ("faltas_sofridas")
   - Apostar Over X.5 faltas sofridas pelo jogador.
   - CRITÉRIO: Faltas Sofridas /90min >= 2.5 (jogadores driblando muito).
   - Calcule X de forma análoga.

=====================================================================
CÁLCULO DE ODDS (PROBABILIDADE → FAIR ODD → ODD MÍNIMA)
=====================================================================
Pra cada candidato, ESTIME:
1. Probabilidade do evento: baseado em /90min, minutos jogados, partidas
   analisadas, e adversário (se inferível do PDF).
2. Fair odd = 1 / (probabilidade / 100)
3. Odd mínima = fair odd × (1 + margem):
   - Eventos com prob >50%: margem 10-15%
   - Eventos com prob 30-50%: margem 15-25%
   - Eventos com prob <30%: margem 25-35%

=====================================================================
PRIORIZAR JOGADORES TITULARES
=====================================================================
Jogadores com mais minutos jogados nas últimas partidas têm mais chance de
serem titulares. Prefira jogadores com 300+ minutos (3+ jogos completos).
Para jogadores com 180-300 minutos, registre no campo "modo" o aviso de
incerteza sobre escalação.

=====================================================================
SCHEMA DO JSON
=====================================================================

{{
  "entradas": [
    {{
      "jogador": "Nome do jogador (exatamente como aparece no PDF)",
      "time": "Time do jogador (Croatia, Belgium, etc.)",
      "posicao": "Posição se inferível, senão vazio",
      "jogo": "Time A x Time B",
      "liga": "Nome da liga / competição (ex: 'Friendly International')",
      "horario": "HH:MM (se aparecer no PDF, senão vazio)",
      "metodo": "marca_gol | cartao_amarelo | chutes | desarmes | faltas_cometidas | faltas_sofridas",
      "mercado": "Descrição clara do mercado (ex: 'Over 2.5 chutes do Lukaku')",
      "odd_minima": "1.85 (com 2 casas)",
      "probabilidade_estimada": "55% (sua estimativa baseada no PDF)",
      "fair_odd": "1.82 (= 1 ÷ probabilidade)",
      "stake_recomendada": "1%",
      "modo": "pre_jogo",
      "estatistica_chave": "O número exato do PDF que justifica (ex: '4.5 chutes/90min em 241 min jogados')",
      "minutos_jogados": 241,
      "partidas_analisadas": 3,
      "adversario": "Nome do adversário",
      "contexto_adversario": "Curta observação sobre o adversário (defesa frágil, etc.) — só se inferível do PDF",
      "motivacao": "Contexto do jogo se relevante (vazio se não tiver)",
      "explicacao_curta": "1-2 frases curtas (até 200 caracteres) explicando POR QUE essa entrada faz sentido. Ex: 'Lukaku com 4.5 chutes/90min em 3 jogos. Atacante titular contra defesa que sofre muitos chutes.'"
    }}
  ],
  "evitar": [
    {{
      "jogador": "Nome",
      "jogo": "Time A x Time B",
      "motivo": "Por que nenhum método se aplica (ex: 'amostra insuficiente — só 90min')"
    }}
  ]
}}

REGRAS CRÍTICAS:
1. APENAS o JSON. Sem ```json, sem texto antes ou depois. Gere UM ÚNICO objeto
   JSON e PARE imediatamente após o "}}" final. NÃO gere array no nível raiz —
   sempre comece com "{{" e tenha "entradas" e "evitar" como chaves.
2. Use APENAS os 6 métodos listados ("marca_gol", "cartao_amarelo", "chutes",
   "desarmes", "faltas_cometidas", "faltas_sofridas").
3. Um jogador PODE aparecer em mais de uma entrada (se cumpre 2+ métodos).
4. Todas as odds são strings ("1.85", não 1.85).
5. NUNCA force entradas. Qualidade > quantidade. Se o PDF é pobre, retorne
   poucas entradas.

---

CONTEÚDO DO PDF:

{conteudo}
"""


def analisar_pdf_jogadores(client, modelo, texto_pdf):
    """Analisa um PDF de jogadores e retorna {entradas, evitar}."""
    prompt = PROMPT_JOGADORES.format(conteudo=texto_pdf[:400000])
    try:
        resposta = chamar_gemini(client, modelo, prompt)
        return _extrair_json(resposta)
    except Exception as e:
        print(f"     ✗ Erro no Gemini: {e}")
        return {"entradas": [], "evitar": []}


# ============================================================
# Fluxo principal
# ============================================================
async def fluxo_principal_jogadores(config, dia: str = "hoje", data_referencia: str = None):
    DEBUG_DIR.mkdir(exist_ok=True)
    PDF_DIR.mkdir(exist_ok=True)
    if not data_referencia:
        data_referencia = datetime.now().strftime("%Y-%m-%d")
    pasta_dia = PDF_DIR / data_referencia
    pasta_dia.mkdir(exist_ok=True)

    async with async_playwright() as p:
        perfil_dir = BASE_DIR / "browser_profile_radar"
        perfil_dir.mkdir(exist_ok=True)
        user_agent = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/130.0.0.0 Safari/537.36"
        )

        context = await p.chromium.launch_persistent_context(
            str(perfil_dir),
            headless=False,
            user_agent=user_agent,
            viewport={"width": 1366, "height": 768},
            locale="pt-BR",
            timezone_id="America/Sao_Paulo",
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
            ],
        )
        page = context.pages[0] if context.pages else await context.new_page()

        # Login
        await fazer_login_radar(page, config)

        # Coleta partidas
        partidas = await coletar_partidas_radar(page, dia=dia)
        if not partidas:
            await context.close()
            return [], []

        # Gera PDFs
        print(f"\n→ Gerando PDFs ({len(partidas)} partidas)...")
        pdfs_gerados = []
        for i, partida in enumerate(partidas, 1):
            try:
                print(f"  [{i}/{len(partidas)}] {partida['nome'][:60]}")
                caminho = await gerar_pdf_partida_radar(context, partida, pasta_dia, i)
                pdfs_gerados.append((partida, caminho))
            except Exception as e:
                print(f"     ✗ erro: {e}")
            # Pausa anti rate limit
            if i % 5 == 0 and i < len(partidas):
                print(f"     ⏸  pausa anti rate limit (10s)...")
                await asyncio.sleep(10)
            else:
                await asyncio.sleep(2)

        await context.close()
        return partidas, pdfs_gerados


def main():
    config = load_config()

    dia = "hoje"
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower().strip()
        if arg in ("amanha", "amanhã"):
            dia = "amanha"

    if dia == "amanha":
        data_ref = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        print(f"📅 Modo: AMANHÃ ({data_ref})\n")
    else:
        data_ref = datetime.now().strftime("%Y-%m-%d")
        print(f"📅 Modo: HOJE ({data_ref})\n")

    print("=" * 60)
    print("RADAR DE JOGADORES — coleta e geração de PDFs")
    print("=" * 60)
    partidas, pdfs_gerados = asyncio.run(
        fluxo_principal_jogadores(config, dia=dia, data_referencia=data_ref)
    )

    if not pdfs_gerados:
        print("\nNenhum PDF gerado. Encerrando.")
        return

    print(f"\n✓ {len(pdfs_gerados)} PDF(s) gerado(s)")

    print("\n" + "=" * 60)
    print("ANÁLISE COM GEMINI (1 PDF por vez)")
    print("=" * 60)

    client = genai.Client(api_key=config["gemini_api_key"])
    modelo = config.get("modelo", "gemini-2.5-flash-lite")

    todas_entradas = []
    todos_evitar = []
    for i, (partida, caminho) in enumerate(pdfs_gerados, 1):
        print(f"\n  [{i}/{len(pdfs_gerados)}] Analisando: {partida['nome'][:60]}")
        texto = extrair_texto_pdf(caminho)
        if not texto.strip():
            print(f"     ⚠ sem texto extraído")
            continue
        resultado = analisar_pdf_jogadores(client, modelo, texto)
        n_ent = len(resultado.get("entradas", []))
        n_ev = len(resultado.get("evitar", []))
        print(f"     ✓ {n_ent} entrada(s), {n_ev} evitar")
        todas_entradas.extend(resultado.get("entradas", []))
        todos_evitar.extend(resultado.get("evitar", []))
        # Pausa entre PDFs (rate limit Gemini)
        if i < len(pdfs_gerados):
            time.sleep(6)

    OUTPUT_DIR.mkdir(exist_ok=True)
    relatorio = OUTPUT_DIR / f"relatorio_jogadores_{data_ref}.json"

    dados = {
        "data": data_ref,
        "dia_consultado": dia,
        "gerado_em": datetime.now().isoformat(),
        "total_pdfs_analisados": len(pdfs_gerados),
        "entradas": todas_entradas,
        "evitar": todos_evitar,
        "pdfs": [
            {"jogo": p["nome"], "arquivo": c.relative_to(BASE_DIR).as_posix()}
            for p, c in pdfs_gerados
        ],
    }
    with open(relatorio, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)

    print(f"\n✓ Relatório salvo em: {relatorio}")
    print(f"  • {len(todas_entradas)} entradas")
    print(f"  • {len(todos_evitar)} a evitar")

    # Publicação automática (reutiliza o publicar.py existente,
    # adaptando pra apontar pra pasta relatorios_jogadores)
    site_path = config.get("site_path")
    if site_path:
        try:
            import shutil
            destino_dir = Path(site_path) / "relatorios_jogadores"
            destino_dir.mkdir(exist_ok=True)
            destino = destino_dir / f"relatorio_jogadores_{data_ref}.json"
            shutil.copy(relatorio, destino)
            print(f"→ Copiado para o site: {destino.name}")

            import subprocess
            cwd = str(site_path)
            subprocess.run(["git", "add", "."], cwd=cwd, check=False)
            subprocess.run(
                ["git", "commit", "-m", f"Relatório jogadores: {data_ref}"],
                cwd=cwd, check=False
            )
            subprocess.run(["git", "pull", "--rebase"], cwd=cwd, check=False)
            res = subprocess.run(["git", "push"], cwd=cwd, capture_output=True, text=True)
            if res.returncode == 0:
                print(f"✓ Publicado! Cloudflare Pages vai atualizar em 1-2 min.")
            else:
                print(f"⚠ Falha no push: {res.stderr[:200]}")
        except Exception as e:
            print(f"⚠ Falha na publicação: {e}")


if __name__ == "__main__":
    main()
