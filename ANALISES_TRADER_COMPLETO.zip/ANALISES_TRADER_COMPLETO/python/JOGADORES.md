# Análise de Jogadores (Radar de Jogadores)

Módulo paralelo ao `main.py`, voltado para análise de **jogadores individuais**
(mercado de cartões, chutes, gols, desarmes, faltas).

## Pré-requisitos

1. Conta no [radardejogadores.com.br](https://radardejogadores.com.br/member)
2. As mesmas dependências do `main.py` (Playwright, Gemini, etc.) já instaladas
3. Adicionar credenciais no `config.json`:
   ```json
   "radar_usuario": "seu_email_do_radar",
   "radar_senha": "sua_senha_do_radar"
   ```
   Se o login do radar for o mesmo do clube principal, você pode omitir esses
   campos — o programa cai pra `usuario`/`senha` como fallback.

## Como usar

```powershell
cd C:\ANALISES_TRADER
.\.venv\Scripts\Activate.ps1
python main_jogadores.py          # analisa hoje
python main_jogadores.py amanha   # analisa amanhã
```

O que acontece:

1. Abre Chrome com perfil persistente em `browser_profile_radar/`
2. Loga em `radardejogadores.com.br/login` (ou manual na 1ª vez)
3. Coleta partidas listadas na área de membros
4. Baixa o PDF de **cada jogo** (com estatísticas de jogadores)
5. Envia cada PDF pro Gemini com prompt específico de jogadores
6. Gera `relatorios_jogadores/relatorio_jogadores_AAAA-MM-DD.json`
7. Publica no site (na pasta `relatorios_jogadores/` do repo)
8. Cloudflare Pages atualiza o site → aparece em `/jogadores`

## Os 6 métodos

| Método | Critério (/90 min) | Mercado típico |
|---|---|---|
| 🎯 Marca Gol | Chutes no Alvo ≥ 1.5 | "Anytime goalscorer" |
| 🟨 Cartão Amarelo | Cartões ≥ 0.4 E Faltas ≥ 2.0 | "Jogador leva cartão" |
| 🎯 Chutes (Over) | Chutes ≥ 2.0 | "Over X.5 chutes" |
| 🛡 Desarmes (Over) | Roubos ≥ 2.0 | "Over X.5 desarmes" |
| ⚠️ Faltas Cometidas (Over) | Faltas Cometidas ≥ 2.0 | "Over X.5 faltas" |
| 🆘 Faltas Sofridas (Over) | Faltas Sofridas ≥ 2.5 | "Over X.5 faltas sofridas" |

Filtros aplicados:

- **Amostra mínima**: 180 minutos jogados (2 jogos completos como base)
- **Preferência por titulares**: jogadores com 300+ min têm prioridade

## Estrutura de pastas

```
C:\ANALISES_TRADER\
├── main.py                          ← análise de partidas (já existente)
├── main_jogadores.py                ← análise de jogadores (NOVO)
├── browser_profile/                 ← cookies do clube principal
├── browser_profile_radar/           ← cookies do radar (NOVO)
├── pdfs/                            ← PDFs de partidas
├── pdfs_jogadores/                  ← PDFs do radar (NOVO)
├── relatorios/                      ← JSONs de partidas
├── relatorios_jogadores/            ← JSONs de jogadores (NOVO)
└── config.json
```

## No site

- **Aba "Partidas"** (`/`) → análise de jogos (atual)
- **Aba "Jogadores"** (`/jogadores`) → tabela única estilo planilha:
  - Filtros: método, liga, data, busca por texto
  - Colunas: Jogador, Time, Jogo, Método, Mercado, Odd mín, Data
  - Clique em qualquer linha → página de detalhe

## Importante

Os seletores do radar usados em `main_jogadores.py` são uma **tentativa
inicial** baseada em padrões comuns. Se ao rodar a primeira vez o programa
não encontrar as partidas, ele imprime no terminal os links que **existem** na
página — me manda esse output que eu ajusto os seletores certos.
