"""
Publicação automática de relatórios no site (Cloudflare Pages via GitHub).

Quando você roda main.py ou analisar.py, esse módulo é chamado no final.
Ele copia o relatório .md gerado para a pasta do site e faz git push,
o que dispara o deploy automático no Cloudflare Pages.

Configure o caminho do site em config.json:
    "site_path": "C:\\\\ANALISES_TRADER_SITE",
    "publicar_automaticamente": true
"""
import shutil
import subprocess
import sys
from pathlib import Path
from datetime import datetime


def _rodar(cmd: list, cwd: Path) -> tuple[bool, str]:
    """Executa um comando e retorna (sucesso, saida)."""
    try:
        r = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
        )
        ok = r.returncode == 0
        saida = (r.stdout or "") + (r.stderr or "")
        return ok, saida.strip()
    except FileNotFoundError:
        return False, f"comando não encontrado: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return False, "tempo esgotado (mais de 2 minutos)"
    except Exception as e:
        return False, f"erro: {e}"


def publicar(config: dict, relatorio_path: Path) -> bool:
    """
    Copia o relatório para a pasta do site e faz git push.
    Retorna True se publicou, False se pulou ou deu erro (sem travar o programa).
    """
    if not config.get("publicar_automaticamente"):
        return False

    site_path_str = config.get("site_path", "").strip()
    if not site_path_str:
        print("\n⚠ 'site_path' não definido no config.json. Pulando publicação.")
        return False

    site_path = Path(site_path_str)
    if not site_path.exists():
        print(f"\n⚠ Pasta do site não existe: {site_path}")
        return False

    pasta_relatorios_site = site_path / "relatorios"
    if not pasta_relatorios_site.exists():
        print(f"\n⚠ Pasta 'relatorios' não existe em {site_path}")
        return False

    if not relatorio_path.exists():
        print(f"\n⚠ Relatório não existe: {relatorio_path}")
        return False

    print("\n" + "=" * 60)
    print("PUBLICAÇÃO NO SITE")
    print("=" * 60)

    # 1. Copiar relatório
    destino = pasta_relatorios_site / relatorio_path.name
    try:
        shutil.copy2(relatorio_path, destino)
        print(f"→ Copiado para o site: {destino.name}")
    except Exception as e:
        print(f"✗ Erro ao copiar: {e}")
        return False

    # 2. Verificar se o Git está instalado
    ok, _ = _rodar(["git", "--version"], site_path)
    if not ok:
        print("✗ Git não encontrado. Instale em https://git-scm.com/download/win")
        return False

    # 3. Verificar se a pasta é um repositório Git
    ok, _ = _rodar(["git", "rev-parse", "--git-dir"], site_path)
    if not ok:
        print(f"✗ {site_path} não é um repositório Git.")
        print("  Faça o setup inicial conforme as instruções da Fase 3.")
        return False

    # 4. Adicionar
    ok, saida = _rodar(["git", "add", "relatorios/"], site_path)
    if not ok:
        print(f"✗ Falha em 'git add': {saida}")
        return False

    # 5. Verificar se há mudanças
    ok, status = _rodar(["git", "status", "--porcelain"], site_path)
    if not status.strip():
        print("→ Nenhuma mudança detectada (relatório igual ao publicado).")
        return False

    # 6. Commit
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    mensagem = f"Relatório: {relatorio_path.stem} ({timestamp})"
    ok, saida = _rodar(["git", "commit", "-m", mensagem], site_path)
    if not ok:
        print(f"✗ Falha em 'git commit': {saida}")
        return False
    print(f"→ Commit criado: {mensagem}")

    # 6.5. Pull antes do push pra evitar conflito com mudanças remotas
    # (ex: Worker da auditoria pode ter editado trades.json em paralelo)
    print("→ Sincronizando com GitHub (git pull)...")
    ok, saida = _rodar(
        ["git", "pull", "--rebase", "--autostash"],
        site_path,
    )
    if not ok:
        # Se rebase falhou, tenta merge simples
        print(f"⚠ Rebase falhou, tentando merge: {saida}")
        ok, saida = _rodar(
            ["git", "pull", "--no-rebase", "--strategy-option=theirs"],
            site_path,
        )
        if not ok:
            print(f"✗ Falha em 'git pull': {saida}")
            print("  Resolva manualmente: 'cd' na pasta do site, rode 'git pull' e depois 'git push'")
            return False

    # 7. Push
    print("→ Enviando para o GitHub (pode demorar ~10s)...")
    ok, saida = _rodar(["git", "push"], site_path)
    if not ok:
        print(f"✗ Falha em 'git push': {saida}")
        print("  Verifique sua conexão e suas credenciais do GitHub.")
        return False

    print("✓ Publicado! Cloudflare Pages vai atualizar o site em 1-2 minutos.")
    print(f"  Acompanhe em: https://dash.cloudflare.com")
    return True


def publicar_se_configurado(config: dict, data: str = None):
    """
    Versão tolerante: tenta publicar TODOS os relatórios da data
    (útil quando o analisar.py gerou múltiplos arquivos).
    """
    if not config.get("publicar_automaticamente"):
        return

    pasta_local = Path(__file__).parent / "relatorios"
    if not pasta_local.exists():
        return

    if data:
        padrao = f"relatorio_{data}*"
    else:
        padrao = "relatorio_*"

    relatorios = [
        r for r in sorted(pasta_local.glob(padrao))
        if r.suffix in (".md", ".json")
    ]
    if not relatorios:
        return

    for r in relatorios:
        try:
            publicar(config, r)
        except Exception as e:
            print(f"⚠ Erro ao publicar {r.name}: {e}")
