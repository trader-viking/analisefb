# Instalação do Zero — Análises Trader Viking

Guia completo pra instalar o sistema inteiro numa máquina nova, sem nada
pré-instalado. Estimativa: **45-90 min** se for fazer tudo (incluindo Cloudflare).
Se a maioria já estiver pronta, **15-20 min** só pra copiar e configurar.

## Visão geral

O sistema tem **3 partes** que precisam ser configuradas:

| Parte | Onde roda | Quando configurar |
|-------|-----------|-------------------|
| **Python** | Seu PC (Windows) | Sempre — é o que você roda no dia a dia |
| **Worker** | Cloudflare (nuvem) | Uma vez só |
| **Site** | Cloudflare Pages (nuvem) | Uma vez só |

**Se você já tem o Worker e o Site funcionando**, e está só migrando o PC,
pode pular direto pra **Parte A** e ignorar B e C.

---

## Pré-requisitos

- **Windows 10 ou 11** (o script automático é pra Windows)
- **Conta no GitHub** (gratuita)
- **Conta no Cloudflare** (gratuita)
- **Chave da API do Gemini** ([criar aqui](https://aistudio.google.com/apikey))
- **Chave da API-Football** ([criar aqui](https://www.api-football.com/) — plano grátis basta)
- **Conta no clube.theoborges.com** (você já tem)

---

# PARTE A — Configurar o PC (Python)

## A1. Instalar dependências do sistema

**Opção 1: Script automático (RECOMENDADO)**

1. Abra o **PowerShell como Administrador**:
   - Tecla Windows → digita "powershell" → clica com botão direito → "Executar como administrador"

2. Permita execução de scripts (só dessa sessão):
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
   ```

3. Vai até a pasta do pacote e roda o instalador:
   ```powershell
   cd C:\Users\SEU_USUARIO\Downloads\ANALISES_TRADER_COMPLETO
   .\instalar.ps1
   ```

   O script instala automaticamente o que estiver faltando:
   - Python 3.11 (via winget)
   - Git
   - Node.js (precisa pra rodar o site localmente, se quiser)
   - Cria o ambiente, instala pacotes Python, configura Playwright

4. **Importante:** se o Python for instalado pelo script, **feche e reabra o PowerShell** antes de continuar.

**Opção 2: Manual**

Se preferir instalar à mão:

- **Python 3.11** — baixar em https://www.python.org/downloads/ e **marcar "Add Python to PATH"** durante a instalação
- **Git** — https://git-scm.com/download/win
- **Node.js 20+** (opcional, só se quiser rodar o site local) — https://nodejs.org/

Confirma que tudo está acessível:
```powershell
python --version    # deve mostrar Python 3.11.x
git --version       # qualquer versão recente
node --version      # v20 ou superior (opcional)
```

## A2. Copiar a pasta `python/` pra o PC

1. Crie a pasta principal:
   ```powershell
   New-Item -ItemType Directory -Force -Path C:\ANALISES_TRADER
   ```

2. Copie o conteúdo de `python/` (do pacote) pra `C:\ANALISES_TRADER\`. Estrutura final:

   ```
   C:\ANALISES_TRADER\
   ├── main.py
   ├── analisar.py
   ├── publicar.py
   ├── telegram_helper.py
   ├── monitor_ao_vivo.py
   ├── requirements.txt
   ├── config.example.json
   └── COMANDOS.md
   ```

## A3. Criar o ambiente Python

```powershell
cd C:\ANALISES_TRADER
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install --upgrade pip
pip install -r requirements.txt
python -m playwright install chromium
```

**Se o `Activate.ps1` der erro de execução**, rode antes:
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

## A4. Criar o `config.json`

```powershell
Copy-Item config.example.json config.json
notepad config.json
```

Edite os campos:

```json
{
  "usuario": "SEU_EMAIL@gmail.com",
  "senha": "SUA_SENHA_DO_CLUBE",
  "gemini_api_key": "AIzaSy...SUA_CHAVE_GEMINI",
  "modelo": "gemini-2.5-flash-lite",
  "tamanho_lote": 10,
  "headless": false,
  "site_path": "C:\\ANALISES_TRADER_SITE",
  "publicar_automaticamente": true,
  "api_football_key": "sua_chave_api_sports_io",
  "site_publico_url": "https://SEU-SITE.pages.dev",
  "token_fallback": "TOKEN_DO_YOUTUBE_DO_THEO_BORGES",
  "ligas_permitir": [
    "brazil serie a", "brazil serie b", "spain la liga", "italy serie a",
    "england premier league", "uefa champions league", "uefa europa league",
    "france ligue 1", "germany bundesliga", "turkey",
    "fifa club world cup", "world cup", "copa do brasil",
    "copa libertadores", "copa sudamericana"
  ],
  "ligas_metodos_diretos": [
    "brazil serie a", "brazil serie b", "spain la liga", "italy serie a",
    "saudi arabia professional league", "england premier league",
    "uefa champions league", "uefa europa league", "france ligue 1",
    "germany bundesliga", "turkey", "fifa club world cup", "world cup",
    "copa do brasil", "copa libertadores", "copa sudamericana"
  ],
  "telegram": {
    "ativado": true,
    "bot_token": "TOKEN_DO_BOT_TELEGRAM",
    "chat_id": "SEU_CHAT_ID",
    "notificar": {
      "relatorio": true,
      "auditoria": true,
      "erro": true,
      "ao_vivo": true
    }
  }
}
```

**Como pegar cada campo:**

| Campo | Onde pegar |
|-------|------------|
| `gemini_api_key` | https://aistudio.google.com/apikey → Create API key |
| `api_football_key` | https://dashboard.api-football.com → Account → API Key |
| `token_fallback` | Link no YouTube do Theo Borges (`clube.theoborges.com/matches?t=XXX` — copie a parte depois do `t=`) |
| `telegram.bot_token` | Telegram → falar com @BotFather → criar bot → copiar token |
| `telegram.chat_id` | Telegram → falar com @userinfobot — ele responde com seu chat_id |
| `site_publico_url` | Você vai descobrir na **Parte C** (deixe `https://analisefb.pages.dev` por enquanto) |

**Confere se o JSON é válido:**
```powershell
python -c "import json; print('OK' if json.load(open('config.json')) else 'FALHOU')"
```
Tem que mostrar `OK`.

## A5. Configurar Git (pra publicar relatórios)

Você precisa de um repositório no GitHub onde os relatórios serão publicados.

```powershell
git config --global user.name "Seu Nome"
git config --global user.email "seu_email@gmail.com"
```

Crie no GitHub um repositório novo (privado é ok):
1. https://github.com/new
2. Nome: `analisefb` (ou outro — você vai usar isso depois)
3. **Privado** ou Público (sua escolha)
4. NÃO marque "Add README" (deixa vazio)
5. Cria.

Clona o site no PC (vai servir tanto pra rodar local quanto pra ele puxar/empurrar relatórios):

```powershell
cd C:\
git clone https://github.com/SEU_USUARIO/analisefb.git ANALISES_TRADER_SITE
```

> Se for a primeira vez usando Git no PC, ele vai pedir login. Use um **Personal Access Token** em vez de senha:
> 1. GitHub → Settings → Developer settings → Personal access tokens (classic)
> 2. Generate new token → marca o escopo **`repo`** → Generate
> 3. Cola o token quando o Git pedir senha (guarda em algum lugar; ele só aparece uma vez)

Copie a pasta `site/` (do pacote) pra dentro de `C:\ANALISES_TRADER_SITE`:

```powershell
# (copie o conteúdo de site/ do pacote pra C:\ANALISES_TRADER_SITE)
cd C:\ANALISES_TRADER_SITE
git add .
git commit -m "Setup inicial do site"
git push origin main
```

## A6. Teste local do Python

```powershell
cd C:\ANALISES_TRADER
.\.venv\Scripts\Activate.ps1
python main.py
```

**Primeira execução:** vai abrir uma janela do Chrome. Faça login manualmente
no clube (e-mail/senha ou botão "YouTube membro"). O programa detecta e segue.
Os cookies ficam salvos em `browser_profile/` — próximas execuções entram sozinhas.

Se tudo der certo, no fim aparece:
```
✓ Relatório salvo em: relatorios/relatorio_AAAA-MM-DD.json
  • X entradas com valor
  • Y jogos a evitar
```

**Se quiser parar aqui** (sem publicar no site/Worker), já está funcional —
você tem o relatório JSON e PDFs locais. As partes B e C são pra ter o **site
público** e a **auditoria automática**.

---

# PARTE B — Configurar o Cloudflare Worker

O Worker é a API que: busca placares na API-Football, grava status/vereditos
nos relatórios via API do GitHub, e atende às chamadas do site.

## B1. Criar o Worker no Cloudflare

1. Entra em https://dash.cloudflare.com
2. Workers & Pages → Create application → **Create Worker**
3. Nome: `analises-trader-api` (ou outro — anota a URL final)
4. Clica em **Deploy**
5. Depois, **Edit code**
6. Apaga TODO o código padrão
7. Cola o conteúdo de `worker/index.js` do pacote
8. **Save and Deploy**

## B2. Configurar variáveis e secrets do Worker

No painel do Worker → **Settings** → **Variables and Secrets** → **Add**

Adicione (uma por uma):

| Nome | Tipo | Valor | Como pegar |
|------|------|-------|------------|
| `GITHUB_OWNER` | Plaintext | seu usuário do GitHub | ex: `joao-silva` |
| `GITHUB_REPO` | Plaintext | `analisefb` (ou o nome que você usou) | — |
| `GITHUB_BRANCH` | Plaintext | `main` | — |
| `GITHUB_TOKEN` | **Secret** | token classic com escopo `repo` | GitHub → Settings → Developer settings → PAT (classic) → criar com escopo `repo` |
| `API_FOOTBALL_KEY` | **Secret** | chave da api-sports.io | https://dashboard.api-football.com |
| `ALLOWED_ORIGIN` | Plaintext | `https://SEU-SITE.pages.dev` | **SEM barra `/` no final!** Você descobre na Parte C |
| `TELEGRAM_BOT_TOKEN` | **Secret** | token do bot (opcional) | mesmo do `config.json` |
| `TELEGRAM_CHAT_ID` | Plaintext | seu chat_id (opcional) | mesmo do `config.json` |

> **MUITO importante**: o `GITHUB_TOKEN` precisa ser **classic** com escopo `repo`
> (que dá leitura e escrita). Fine-grained tokens dão problema. O escopo `repo`
> permite ao Worker gravar os vereditos GREEN/RED nos relatórios.

> **MUITO importante**: o `ALLOWED_ORIGIN` **não pode ter barra `/` no final**.
> Se tiver, o navegador bloqueia tudo por CORS. Ex: `https://analisefb.pages.dev` ✅,
> não `https://analisefb.pages.dev/` ❌

## B3. Configurar o Cron Trigger (auditoria automática)

Painel do Worker → **Settings** → **Triggers** → **Cron Triggers** → **Add Cron Trigger**

- Cron expression: `*/10 * * * *` (a cada 10 minutos)
- Save

Isso faz a auditoria rodar sozinha, buscando placares e atualizando os relatórios.

## B4. Testar o Worker

No PowerShell:

```powershell
curl.exe -X POST https://analises-trader-api.SEU-USUARIO.workers.dev/auditar
```

Resposta esperada (se já houver relatório no GitHub):
```json
{"status":"...","diagnostico":{"datas":{"AAAA-MM-DD":{"relatorio_existe":true,...}}}}
```

Se vier `"relatorio nao existe"`: precisa rodar `python main.py` primeiro pra
gerar um relatório, depois testar de novo.

Se vier erro 403 ao gravar: o `GITHUB_TOKEN` não tem permissão. Gere um novo
classic com escopo `repo`.

---

# PARTE C — Configurar o Cloudflare Pages (site)

## C1. Criar o projeto Pages

1. Cloudflare → Workers & Pages → Create application → **Pages** → **Connect to Git**
2. Autoriza o Cloudflare a acessar seu GitHub
3. Seleciona o repositório `analisefb`
4. **Begin setup**:
   - Production branch: `main`
   - Framework preset: **None**
   - Build command: `npm run build`
   - Build output directory: `out`
5. **Environment variables**:
   - `NODE_VERSION` = `20`
   - `NEXT_PUBLIC_API_URL` = URL do Worker (ex: `https://analises-trader-api.felipebenicio09.workers.dev`)
6. **Save and Deploy**

Espera o build (~2-3 min). No fim, ele te dá uma URL tipo `https://analisefb.pages.dev`.

## C2. Atualizar o `ALLOWED_ORIGIN` no Worker

Agora que você sabe a URL final do site:

1. Volta no Worker → Settings → Variables
2. Edita `ALLOWED_ORIGIN` pra `https://analisefb.pages.dev` (a sua URL real, sem barra)
3. Save

## C3. Atualizar o `config.json` do PC

```powershell
notepad C:\ANALISES_TRADER\config.json
```

Atualiza:
```json
"site_publico_url": "https://analisefb.pages.dev"
```

## C4. Teste end-to-end

```powershell
cd C:\ANALISES_TRADER
.\.venv\Scripts\Activate.ps1
python main.py
```

O que deve acontecer:
1. ✓ Baixa PDFs
2. ✓ Analisa com Gemini
3. ✓ Salva `relatorios/relatorio_AAAA-MM-DD.json`
4. ✓ Copia pro site (`C:\ANALISES_TRADER_SITE`)
5. ✓ `git commit` + `git push`
6. ✓ Telegram envia notificação (se configurado)
7. Cloudflare Pages detecta o push e refaz o site (~1-2 min)
8. Worker roda auditoria a cada 10min, atualiza placares

Acessa `https://analisefb.pages.dev` e veja seu relatório lá. 🎉

---

# Troubleshooting

## Python

**"python não é reconhecido como comando"**
→ Não marcou "Add to PATH" durante instalação. Reinstala marcando, ou adiciona
o caminho manualmente em Variáveis de Ambiente do Windows.

**"Activate.ps1 cannot be loaded"**
→ Rode: `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`

**"playwright install failed"**
→ Rode separadamente: `python -m playwright install chromium`

**Análise vazia (0 entradas, 0 evitar) sem erro**
→ Confere no terminal se aparece "⚠ JSON inválido do Gemini". Se sim, abre o
arquivo em `debug/` e me mostra. Pode ser prompt quebrado ou Gemini retornando
em formato errado.

**PDFs caem na tela de login no meio**
→ Rate limit do clube. O `main.py` atual já tem pausas adaptativas e relogin
automático. Garanta que `usuario` e `senha` estão preenchidos no `config.json`.

## Git

**"fatal: not currently on a branch"**
→ Rode na pasta do site:
```powershell
cd C:\ANALISES_TRADER_SITE
git checkout main
git pull origin main
git push origin main
```

**Senha do GitHub não funciona**
→ GitHub não aceita mais senha desde 2021. Use Personal Access Token classic
com escopo `repo` como senha.

## Cloudflare Worker

**Erro CORS no navegador**
→ `ALLOWED_ORIGIN` está errado. Confere se é EXATAMENTE igual à URL do site,
sem barra `/` no final.

**`/auditar` retorna "relatorio nao existe"**
→ Confere `GITHUB_OWNER`, `GITHUB_REPO`, `GITHUB_BRANCH`. Acessa
`https://github.com/OWNER/REPO/tree/BRANCH/relatorios` no navegador — se não
abrir, é variável errada.

**`/auditar` retorna 403 "Resource not accessible"**
→ `GITHUB_TOKEN` sem permissão de escrita. Gere um novo classic com `repo`.

**Botão "Rolando agora" sempre em 0**
→ Limitação da API-Football grátis. Ela retorna pouco dado ao vivo, e só pra
ligas grandes. Não tem como contornar sem plano pago.

## Cloudflare Pages

**Build falhando**
→ Confere `NODE_VERSION=20` e que a pasta `relatorios/` tem pelo menos um JSON
(mesmo o exemplo de 2026-05-17).

**Site não atualiza depois do git push**
→ Vai em Cloudflare → Pages → seu projeto → Deployments — vê se está rodando.
Se está com erro, abre o log e me manda.

---

# Manutenção contínua

## Atualizando o `token_fallback`

Quando expirar (sinal: "Token expirado" no terminal):
1. Vai no YouTube do Theo Borges, vídeo mais recente
2. Procura na descrição/comentário fixado o link `clube.theoborges.com/matches?t=NOVO_TOKEN`
3. Copia só a parte depois de `t=`
4. Cola em `config.json` no campo `token_fallback`

## Backup do `browser_profile/`

A pasta `C:\ANALISES_TRADER\browser_profile/` guarda os cookies do login.
**Não deleta!** Se trocar de PC, copia inteira pra preservar a sessão.

## Atualizando o sistema

Quando receber uma versão nova:
- **Só o `main.py`**: substitui em `C:\ANALISES_TRADER\`
- **Só o site**: substitui em `C:\ANALISES_TRADER_SITE\` (preservando `.git/`) e dá `git push`
- **Só o Worker**: copia `index.js` no editor do Cloudflare → Save and Deploy

---

## Estimativa de custos (todos têm plano grátis)

| Serviço | Plano | O que faz |
|---------|-------|-----------|
| **Cloudflare Workers** | Grátis | 100k requisições/dia. Você usa ~144 (cron a cada 10min) + chamadas do site. Sobra muito. |
| **Cloudflare Pages** | Grátis | Builds + bandwidth ilimitados |
| **GitHub** | Grátis | Repos privados ilimitados |
| **Gemini API** | Grátis | 15 req/min, 1500 req/dia (modelo flash-lite). Você usa ~3-10 por dia. |
| **API-Football** | Grátis | 100 req/dia. Cron de 10min = 144/dia. **Talvez precise plano pago se cobrir várias ligas.** Ajuste o cron se for o caso. |
| **Telegram Bot** | Grátis | Ilimitado |

---

Pronto. Se algo der errado nesse caminho, anota o passo exato e me chama —
diagnóstico é mais rápido com o erro específico.
