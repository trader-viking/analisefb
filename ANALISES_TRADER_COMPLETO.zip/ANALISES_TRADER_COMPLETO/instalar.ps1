﻿# =====================================================================
# ANALISES TRADER VIKING - Instalador automatico (Windows)
# =====================================================================
# Roda este script no PowerShell COMO ADMINISTRADOR.
# Antes de rodar, libere a execucao na sessao:
#   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
# =====================================================================

$ErrorActionPreference = "Stop"

function Escrever-Titulo($texto) {
    Write-Host ""
    Write-Host ("=" * 60) -ForegroundColor Cyan
    Write-Host "  $texto" -ForegroundColor Cyan
    Write-Host ("=" * 60) -ForegroundColor Cyan
}

function Escrever-Passo($texto) {
    Write-Host ""
    Write-Host "==> $texto" -ForegroundColor Yellow
}

function Escrever-OK($texto) {
    Write-Host "  [OK] $texto" -ForegroundColor Green
}

function Escrever-Aviso($texto) {
    Write-Host "  [AVISO] $texto" -ForegroundColor DarkYellow
}

function Existe-Comando($cmd) {
    $null = Get-Command $cmd -ErrorAction SilentlyContinue
    return $?
}

# ---------------------------------------------------------------------
# Confere admin
# ---------------------------------------------------------------------
$ehAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent() `
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $ehAdmin) {
    Write-Host ""
    Write-Host "ERRO: Este script precisa ser executado como ADMINISTRADOR." -ForegroundColor Red
    Write-Host "Feche o PowerShell, clique com botao direito e 'Executar como administrador'." -ForegroundColor Red
    Write-Host ""
    exit 1
}

Escrever-Titulo "ANALISES TRADER VIKING - Instalador"
Write-Host "Este script instala automaticamente o que estiver faltando" -ForegroundColor Gray
Write-Host "(Python, Git, Node) e prepara o ambiente Python." -ForegroundColor Gray
Write-Host ""
Write-Host "Tempo estimado: 5-10 minutos." -ForegroundColor Gray
Write-Host ""
Read-Host "Pressione ENTER para comecar (ou Ctrl+C para cancelar)"

# ---------------------------------------------------------------------
# Confere winget
# ---------------------------------------------------------------------
Escrever-Passo "Verificando winget (gerenciador de pacotes do Windows)..."
if (-not (Existe-Comando "winget")) {
    Write-Host "  [ERRO] winget nao encontrado." -ForegroundColor Red
    Write-Host "  Atualize o Windows ou instale 'App Installer' pela Microsoft Store:" -ForegroundColor Red
    Write-Host "  https://apps.microsoft.com/detail/9NBLGGH4NNS1" -ForegroundColor Red
    exit 1
}
Escrever-OK "winget disponivel"

# ---------------------------------------------------------------------
# Instala Python
# ---------------------------------------------------------------------
Escrever-Passo "Verificando Python 3.11..."
$temPython = $false
if (Existe-Comando "python") {
    $versao = & python --version 2>&1
    if ($versao -match "Python 3\.(\d+)") {
        $minor = [int]$Matches[1]
        if ($minor -ge 10) {
            Escrever-OK "Python ja instalado: $versao"
            $temPython = $true
        }
    }
}

if (-not $temPython) {
    Write-Host "  Instalando Python 3.11 via winget..." -ForegroundColor Gray
    try {
        winget install -e --id Python.Python.3.11 --accept-source-agreements --accept-package-agreements --silent
        Escrever-OK "Python 3.11 instalado"
        Escrever-Aviso "Voce DEVE fechar e reabrir o PowerShell antes de continuar!"
        Write-Host ""
        Read-Host "Pressione ENTER para sair. Depois reabra o PowerShell como ADMIN e rode este script de novo"
        exit 0
    } catch {
        Write-Host "  [ERRO] Falha ao instalar Python via winget. Instale manualmente:" -ForegroundColor Red
        Write-Host "  https://www.python.org/downloads/" -ForegroundColor Red
        Write-Host "  IMPORTANTE: marque 'Add Python to PATH' durante a instalacao." -ForegroundColor Red
        exit 1
    }
}

# ---------------------------------------------------------------------
# Instala Git
# ---------------------------------------------------------------------
Escrever-Passo "Verificando Git..."
if (Existe-Comando "git") {
    $versao = & git --version 2>&1
    Escrever-OK "$versao"
} else {
    Write-Host "  Instalando Git via winget..." -ForegroundColor Gray
    try {
        winget install -e --id Git.Git --accept-source-agreements --accept-package-agreements --silent
        Escrever-OK "Git instalado (talvez precise reabrir o PowerShell)"
    } catch {
        Escrever-Aviso "Falha ao instalar Git. Baixe manualmente: https://git-scm.com/download/win"
    }
}

# ---------------------------------------------------------------------
# Instala Node (opcional, para rodar site local)
# ---------------------------------------------------------------------
Escrever-Passo "Verificando Node.js (opcional - so se quiser rodar site local)..."
if (Existe-Comando "node") {
    $versao = & node --version 2>&1
    Escrever-OK "Node $versao"
} else {
    $resp = Read-Host "  Node.js nao encontrado. Instalar agora? (s/N) [opcional]"
    if ($resp -match "^[sS]") {
        try {
            winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements --silent
            Escrever-OK "Node.js instalado"
        } catch {
            Escrever-Aviso "Falha ao instalar Node. Pode pular - so e necessario pra rodar o site local."
        }
    } else {
        Write-Host "  Pulando Node.js (voce pode rodar o site pelo Cloudflare Pages mesmo sem ele)" -ForegroundColor Gray
    }
}

# ---------------------------------------------------------------------
# Copia pasta python/ para C:\ANALISES_TRADER\
# ---------------------------------------------------------------------
Escrever-Passo "Preparando pasta C:\ANALISES_TRADER..."

$pastaScript = Split-Path -Parent $MyInvocation.MyCommand.Path
$pastaPython = Join-Path $pastaScript "python"
$pastaDestino = "C:\ANALISES_TRADER"

if (-not (Test-Path $pastaPython)) {
    Write-Host "  [ERRO] Pasta 'python' nao encontrada em: $pastaScript" -ForegroundColor Red
    Write-Host "  Certifique-se de rodar este script DENTRO da pasta ANALISES_TRADER_COMPLETO." -ForegroundColor Red
    exit 1
}

if (Test-Path $pastaDestino) {
    Escrever-Aviso "Pasta $pastaDestino ja existe."
    $resp = Read-Host "  Substituir arquivos Python (mantendo config.json e browser_profile)? (s/N)"
    if ($resp -notmatch "^[sS]") {
        Write-Host "  Pulando copia." -ForegroundColor Gray
    } else {
        # Copia, preservando config.json e browser_profile
        Get-ChildItem -Path $pastaPython -File | ForEach-Object {
            if ($_.Name -eq "config.example.json" -and (Test-Path "$pastaDestino\config.json")) {
                # Nao sobrescreve o config.json existente
                Copy-Item $_.FullName "$pastaDestino\config.example.json" -Force
            } else {
                Copy-Item $_.FullName $pastaDestino -Force
            }
        }
        Escrever-OK "Arquivos Python atualizados (config.json e browser_profile preservados)"
    }
} else {
    New-Item -ItemType Directory -Force -Path $pastaDestino | Out-Null
    Copy-Item "$pastaPython\*" -Destination $pastaDestino -Recurse -Force
    Escrever-OK "Arquivos copiados para $pastaDestino"
}

# ---------------------------------------------------------------------
# Cria o ambiente virtual Python e instala dependencias
# ---------------------------------------------------------------------
Escrever-Passo "Criando ambiente virtual Python..."
Set-Location $pastaDestino

if (-not (Test-Path ".venv")) {
    python -m venv .venv
    Escrever-OK "Ambiente virtual criado em .venv"
} else {
    Escrever-OK "Ambiente virtual .venv ja existe"
}

# Ativa o venv pra essa sessao
& "$pastaDestino\.venv\Scripts\Activate.ps1"

Escrever-Passo "Atualizando pip..."
python -m pip install --upgrade pip --quiet
Escrever-OK "pip atualizado"

Escrever-Passo "Instalando dependencias Python (requirements.txt)..."
pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) {
    Write-Host "  [ERRO] Falha ao instalar dependencias." -ForegroundColor Red
    exit 1
}
Escrever-OK "Dependencias instaladas"

Escrever-Passo "Instalando Chromium do Playwright (pode demorar 1-2 min)..."
python -m playwright install chromium
if ($LASTEXITCODE -ne 0) {
    Escrever-Aviso "Falha ao instalar Chromium. Tente rodar manualmente depois:"
    Write-Host "    python -m playwright install chromium" -ForegroundColor Gray
} else {
    Escrever-OK "Chromium instalado"
}

# ---------------------------------------------------------------------
# Cria config.json se nao existir
# ---------------------------------------------------------------------
Escrever-Passo "Verificando config.json..."
if (-not (Test-Path "$pastaDestino\config.json")) {
    Copy-Item "$pastaDestino\config.example.json" "$pastaDestino\config.json"
    Escrever-OK "config.json criado a partir do exemplo"
    Escrever-Aviso "Voce PRECISA editar o config.json antes de rodar o programa!"
    Write-Host "  Campos obrigatorios: usuario, senha, gemini_api_key, token_fallback" -ForegroundColor Gray
} else {
    Escrever-OK "config.json ja existe (mantido)"
}

# ---------------------------------------------------------------------
# Pasta de relatorios
# ---------------------------------------------------------------------
if (-not (Test-Path "$pastaDestino\relatorios")) {
    New-Item -ItemType Directory -Force -Path "$pastaDestino\relatorios" | Out-Null
}
if (-not (Test-Path "$pastaDestino\pdfs")) {
    New-Item -ItemType Directory -Force -Path "$pastaDestino\pdfs" | Out-Null
}
if (-not (Test-Path "$pastaDestino\debug")) {
    New-Item -ItemType Directory -Force -Path "$pastaDestino\debug" | Out-Null
}

# ---------------------------------------------------------------------
# Resumo final
# ---------------------------------------------------------------------
Escrever-Titulo "INSTALACAO CONCLUIDA"

Write-Host ""
Write-Host "Arquivos em:  $pastaDestino" -ForegroundColor White
Write-Host ""
Write-Host "PROXIMOS PASSOS:" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. EDITAR O CONFIG.JSON:" -ForegroundColor White
Write-Host "   notepad $pastaDestino\config.json" -ForegroundColor Gray
Write-Host ""
Write-Host "2. PREENCHER CAMPOS OBRIGATORIOS:" -ForegroundColor White
Write-Host "   - usuario / senha (clube.theoborges.com)" -ForegroundColor Gray
Write-Host "   - gemini_api_key (https://aistudio.google.com/apikey)" -ForegroundColor Gray
Write-Host "   - token_fallback (link no YouTube do Theo Borges)" -ForegroundColor Gray
Write-Host ""
Write-Host "3. SE QUISER PUBLICAR NO SITE: clonar o repo do site." -ForegroundColor White
Write-Host "   Veja INSTALACAO_DO_ZERO.md (parte A5 em diante)" -ForegroundColor Gray
Write-Host ""
Write-Host "4. TESTAR:" -ForegroundColor White
Write-Host "   cd $pastaDestino" -ForegroundColor Gray
Write-Host "   .\.venv\Scripts\Activate.ps1" -ForegroundColor Gray
Write-Host "   python main.py" -ForegroundColor Gray
Write-Host ""
Write-Host "Detalhes completos em: INSTALACAO_DO_ZERO.md" -ForegroundColor Cyan
Write-Host ""
